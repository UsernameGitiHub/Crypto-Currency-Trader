<?php

    //+-----------------------------------------------------------+
    //| Variablen                                                 |
    //+-----------------------------------------------------------+

	$TradevolumeBTC=0;
	if(isset($_GET['volume']))$TradevolumeBTC=$_GET['volume'];
	$lastbuyprice=0;if(isset($_GET['lastbuyprice']))$lastbuyprice=$_GET['lastbuyprice'];
	$buyholdbesitz=0;if(isset($_GET['buyholdbesitz']))$buyholdbesitz=$_GET['buyholdbesitz'];
	$buyholdprozent=0;if(isset($_GET['buyholdprozent']))$buyholdprozent=$_GET['buyholdprozent'];
	$tradesgemachtbh=0;if(isset($_GET['tradesgemachtbh']))$tradesgemachtbh=$_GET['tradesgemachtbh'];
	$BitcoinName="BTCUSDT";
	$CMCId="";
	$symbol="";
	$symbol2="";
	$id=0;
	$allcoinsfile="allcoins_binance.txt";
	if(isset($_GET['name']))
	{
	    $str=file_get_contents($allcoinsfile);
		$Pairs = json_decode($str, true);
		if(gettype($Pairs)=="array")
		{
		if(count($Pairs["Coins"])<=0){echo 'Error in Updates.php no coin names downloaded'; exit();}
		for($i=0; $i<count($Pairs["Coins"]); $i++)
		{
			$name_str=str_replace(' ', '', $Pairs["Coins"][$i]["name"]);
			if($name_str==$_GET['name'])
			{
				$symbol=$Pairs["Coins"][$i]["symbol"]."BTC";
				$symbol2=$Pairs["Coins"][$i]["symbol"];
				$CMCId=$Pairs["Coins"][$i]["cmcid"];
				break;
			}
		}
		}
		if($_GET['name']=="Bitcoin")$symbol=$BitcoinName;
     //--
	 if(isset($_GET['id']))$id=$_GET['id'];
	 $Tradevolume="";
	 $TradevolumeEinh="";
	 if(isset($_GET['volumebtc']))
	 {
		 if($_GET['volumebtc']>0){$Tradevolume=$_GET['volumebtc'];$TradevolumeEinh="BTC";} 
		 else 
		 if($_GET['volumeusd']>0){$Tradevolume=$_GET['volumeusd'];$TradevolumeEinh="USD";}
		 else 
		 if($_GET['volumecoin']>0){$Tradevolume=$_GET['volumecoin'];$TradevolumeEinh="Coin";}
	 }
     //--
	 if($TradevolumeBTC<=0 && $TradevolumeEinh=="USD")
	 {
		 $str=curl_get_file_contents("https://api.coinmarketcap.com/v1/ticker/".$CMCId."/");
		 $CMCInfo = json_decode($str, true);
		 if(gettype($CMCInfo)=="array")
		 {
			 //echo $CMCInfo[0]["price_usd"]."    ".$CMCInfo[0]["price_btc"];
			 $TradevolumeBTC = $CMCInfo[0]["price_btc"]*($Tradevolume/$CMCInfo[0]["price_usd"]);
			 echo " ----   ".$TradevolumeBTC."  ------- ";
		 }
	 }
	 if($TradevolumeBTC<=0 && $TradevolumeEinh=="BTC")$TradevolumeBTC=$Tradevolume;
	 //--
	 if(isset($_GET['buyorsell']))echo 'Binance API ==> '.$_GET['name'].'  '.$symbol.'  || '.$symbol2.'  || '.$_GET['buyorsell'].' || id: '.$id.'   Tradevolumemysql '.$Tradevolume.' <==';
    }//isset get name


	
	
	

  //+-----------------------------------------------------------+
  //| File get content mit curl                                 |
  //+-----------------------------------------------------------+

	function curl_get_file_contents($URL)
    {
        $c = curl_init();
        curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($c, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($c, CURLOPT_URL, $URL);
        $contents = curl_exec($c);
        curl_close($c);

        if ($contents) return $contents;
        else return FALSE;
    }

	
	
	
  //+-----------------------------------------------------------+
  //| Binance Price lesen                                       |
  //+-----------------------------------------------------------+

    function ReadBinancePrice($Coin,$Price)
	{
	  $str="";

	  $url = "https://api.binance.com/api/v1/ticker/24hr?symbol=".$Coin;
	  $page = json_decode(curl_get_file_contents($url),true);
	  
	  if($Price=="Ask")$str = number_format($page["askPrice"],8);
	  else
	  if($Price=="Bid")$str = number_format($page["bidPrice"],8);

      $str=(float)str_replace(",","",$str);
	  
	  return $str;
	}



	//+-----------------------------------------------------------+
    //| Lotsize Decimals Filterung                                |
    //+-----------------------------------------------------------+
	
	function LotsizeFilter($symbol)
	{
	  $str="";
	  $url = "https://www.binance.com/api/v1/exchangeInfo";
	  $page = json_decode(curl_get_file_contents($url),true);
	  for($i=0; $i<count($page["symbols"]); $i++)
	  {
		  if($page["symbols"][$i]["symbol"]==$symbol)
		  {
		   $stelle=strpos($page["symbols"][$i]["filters"][1]["minQty"],"1",0); 
		   if($stelle==0) return 0;
		   $stelle=$stelle-1; return $stelle;
		  }
	  }
	}

	
    //+-----------------------------------------------------------+
    //| Tradevolumen pruefen                                      |
    //+-----------------------------------------------------------+

	function cutNum($num, $precision = 2)
	{
		return floor($num).substr($num-floor($num),1,$precision+1);
	}

    function CheckTradevolume($Price)
	{
		$TradeVolumeCoin=number_format($GLOBALS['TradevolumeBTC']/$Price,4);
		if($_GET['name']=="Bitcoin")$TradeVolumeCoin=number_format($GLOBALS['TradevolumeBTC'],8);
		$TradeVolumeCoin=(float)str_replace(",","",$TradeVolumeCoin);
		if($GLOBALS['TradevolumeEinh']=="Coin")$TradeVolumeCoin=$GLOBALS['Tradevolume'];
		$TradeVolumeCoin=cutNum($TradeVolumeCoin, LotsizeFilter($GLOBALS['symbol']));
		$TradeVolumeCoin=sprintf('%f',$TradeVolumeCoin);
		return $TradeVolumeCoin;
	}

	

	//+-----------------------------------------------------------+
    //| Function API Rueckgabe Bearbeiten                         |
    //+-----------------------------------------------------------+
	
	function RueckgabeBearbeiten(&$Auftrag, $id, $Price)
	{
	  if(isset($Auftrag["clientOrderId"]) && $Auftrag["clientOrderId"]!="")
		{
		  UpdateTraderequest("1", "Successful", $id, $Price);echo "alles klar";
		}
		else
		if(isset($Auftrag["code"]))
		{
		  if($Auftrag["msg"]=="Invalid quantity."){UpdateTraderequest("1", "Error volume to small", $id);echo "volume zu klein";}
		  else
		  if($Auftrag["msg"]=="Invalid quantity."){UpdateTraderequest("1", "Error volume to small", $id);echo "volume zu klein";}
		  else
		  if($Auftrag["msg"]=="Account has insufficient balance for requested action."){UpdateTraderequest("1", "Error volume to big", $id);echo "volume zu gros";}
		  else
		  if($Auftrag["msg"]=="Invalid symbol."){UpdateTraderequest("1", "Error Invalid currencyPair", $id);echo "falsche symbol";}
		  else
		  { UpdateTraderequest("0", "Pending", $id); echo "auftrag pending";}
		}
	}


	
	
	
	
	
	//--Function Update Request
	function InsertTradedBuyAndHoldTraderequest($broker, $symbol, $coin, $volumebtc, $volumeusd, $volumecoin, $result, $v1="leer")
	{
	    //+-----------------------------------------------------------+
        //| Datenbank Verbindung aufrufen                             |
        //+-----------------------------------------------------------+

        include('dbcon.php');
		
		$code=time().'_BuyAndHold_'.$coin;
		$typ="BuyAndHold";
		if($v1=="tpsl"){$volumeusd=0;$volumebtc=0;}

		 //-- Datenbank Query bilden
		 
		 $sql="INSERT INTO ".$Database.".`tradingrequest` (`code`,
														   `typ`,
														   `broker`,
														   `symbol`,
														   `coin`,
														   `market_or_limit`,
														   `limitusdprice`,
														   `limitbtcprice`,
														   `volumeusd`,
														   `volumebtc`,
														   `volumecoin`,
														   `buyholdpercent`,
														   `brokersarbitrage`,
														   `arbitragepercententry`,
														   `arbitragepercentexit`,
														   `tpusdprice`, 
														   `tpusdvalue`, 
														   `tpbtcprice`, 
														   `slusdprice`, 
														   `slusdvalue`, 
														   `slbtcprice`,
														   `sended`,
														   `result`,
														   `createdtimestamp`,
														   `btcpricemysql`,`tpsltraded`,`tradesignalnow`,`signalrichtung`)
														   
			VALUES 
					   ('".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$code))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$typ))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$broker))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$symbol))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$coin))."',
						'',
						'',
						'',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$volumeusd))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$volumebtc))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$volumecoin))."',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'1',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$result))."',
						'".time()."',
						'','1','1','0')

						ON DUPLICATE KEY UPDATE code=VALUES(code);";

						if(!mysqli_query($DatabasePointer,$sql)) 
						{
						  die('Save Traderequest Error: ' . mysqli_error($DatabasePointer)); 
						} 
						else echo 'saved';
	}

	
	
	//+-----------------------------------------------------------+
    //| Function Update Request                                   |
    //+-----------------------------------------------------------+

	function UpdateTraderequest($sended, $res, $id, $OpenPrice="", $BuyHoldBesitz="", $tradesgemachtbh="")
	{
        include('dbcon.php');
		
		if($BuyHoldBesitz!="")$sended=0;
		$sql="UPDATE ".$Database.".`tradingrequest` SET `sended`='".$sended."',`result`='".$res."',`createdtimestamp`='".time()."',`ausfuehrungsprice`='".$OpenPrice."',`buyholdbesitz`='".$BuyHoldBesitz."',`tradesgemachtbh`='".$tradesgemachtbh."' WHERE `id`='".$id."'";
		if(!mysqli_query($DatabasePointer,$sql)) 
		  {
			die('Update Traderequest Error: ' . mysqli_error($DatabasePointer)); 
		  }
	}


	
	//+-----------------------------------------------------------+
    //| Function Update Request Time                              |
    //+-----------------------------------------------------------+
	
	function UpdateTraderequestTime($id)
	{
        include('dbcon.php');
		
		$sql="UPDATE ".$Database.".`tradingrequest` SET `createdtimestamp`='".time()."' WHERE `id`='".$id."'";
		if(!mysqli_query($DatabasePointer,$sql)) 
		  {
			die('Update Traderequest Error: ' . mysqli_error($DatabasePointer)); 
		  }
	}


	
    //+-----------------------------------------------------------+
    //| Function Update Request All                               |
    //+-----------------------------------------------------------+
	
	function UpdateTraderequestAll($id,$res)
	{
        include('dbcon.php');
		
		$sql="UPDATE ".$Database.".`tradingrequest` SET `sended`='1',`result`='".$res."',`tpsltraded`='1' WHERE `id`='".$id."'";
		if(!mysqli_query($DatabasePointer,$sql)) 
		  {
			die('Update Traderequest Error: ' . mysqli_error($DatabasePointer)); 
		  }
	}


	

	

	
	
	
	
	
	//+-----------------------------------------------------------+
    //|  API Zugangsdaten impotieren                              |
    //+-----------------------------------------------------------+

		$str=file_get_contents("apis.txt");
		$Apis = json_decode($str, true);
		$apikey="";
        $apisecret="";
        //--
		if(gettype($Apis)=="array")
		{
		for($i=0; $i<count($Apis["Api"]); $i++)
		{
			if($Apis["Api"][$i]["exchange"]=="Binance")
			{
				$apikey=$Apis["Api"][$i]["tradingkey"];
				$apisecret=$Apis["Api"][$i]["tradingsec"];
			}
		}
		}

		
		





	//+-----------------------------------------------------------+
    //| Buy                                                       |
    //+-----------------------------------------------------------+
	
	if(isset($_GET['buyorsell']) && $_GET['buyorsell']=="buy")
	{
		//--Aktuelle preis lesen
		$Ask=ReadBinancePrice($symbol,"Ask");
		//--Volume
		$TradeVolumeCoin=CheckTradevolume($Ask);
		//--API Call machen
        $nonce=time();
		//--
		$url='symbol='.$symbol.'&side=BUY&type=MARKET&quantity='.$TradeVolumeCoin.'&recvWindow=10000000000000000&timestamp='.$nonce;
		//--
		$sign=hash_hmac('SHA256',$url,$apisecret);
		$url=$url.'&signature='.$sign;
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('X-MBX-APIKEY:'.$apikey));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_URL, "https://api.binance.com/api/v3/order");
		curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$url);
		$execResult = curl_exec($ch);
		$Auftrag = json_decode($execResult, true);
		//--Rueckgabe verarbeiten
		echo 'Buy Auftrag  '.$symbol.'  '.$TradeVolumeCoin.'  '.var_dump($Auftrag);
		UpdateTraderequestTime($id);
		RueckgabeBearbeiten($Auftrag, $id, $Ask);
	}//buy




	//+-----------------------------------------------------------+
    //| Sell                                                      |
    //+-----------------------------------------------------------+

	if(isset($_GET['buyorsell']) && $_GET['buyorsell']=="sell")
	{
        //--Aktuelle preis lesen
		$Bid=ReadBinancePrice($symbol,"Bid");
		//--Volume
		$TradeVolumeCoin=CheckTradevolume($Bid);
		//--API Call machen
        $nonce=time();
		//--
		$url='symbol='.$symbol.'&side=SELL&type=MARKET&quantity='.$TradeVolumeCoin.'&recvWindow=10000000000000000&timestamp='.$nonce;
		//--
		$sign=hash_hmac('SHA256',$url,$apisecret);
		$url=$url.'&signature='.$sign;
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('X-MBX-APIKEY:'.$apikey));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_URL, "https://api.binance.com/api/v3/order");
		curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$url);
		$execResult = curl_exec($ch);
		$Auftrag = json_decode($execResult, true);
		//--Rueckgabe verarbeiten
		echo 'Sell Auftrag  '.$symbol.'  '.number_format($TradeVolumeCoin,8).'  '.var_dump($Auftrag);
		UpdateTraderequestTime($id);
		RueckgabeBearbeiten($Auftrag, $id, $Bid);
	}//sell



	
	//+-----------------------------------------------------------+
    //| Buylimit                                                  |
    //+-----------------------------------------------------------+

	if(isset($_GET['buyorsell']) && $_GET['buyorsell']=="buylimit")
	{
		//--Aktuelle preis lesen
		$Ask=ReadBinancePrice($symbol,"Ask");
		$entryprice=0; 
		if($_GET['limitbtc']>0){$entryprice=number_format($_GET['limitbtc'],8);} 
		else 
		if($_GET['limitusd']>0)
		  {
			$aa=(double)$_GET['limitusd'];
			$Btcprice=ReadBinancePrice($BitcoinName,"Bid");
			$Btcprice=(float)str_replace(",","",$Btcprice);
			$entryprice=number_format($aa/$Btcprice,8);
		  }
	 	else if($_GET['limitbtc']=="" && $_GET['limitusd']=="")UpdateTraderequestAll($id,"Error no limitprice");
		//--
		$prozentunterschied=$Ask/100;
		$abstand=abs($Ask-$entryprice);
		$unterschied=$abstand/$prozentunterschied;
		UpdateTraderequestTime($id);

		echo 'Buylimit  '.$symbol.'  '.$entryprice;
		//--
        if($unterschied<=0.5)
		{
		//--Volume
		$TradeVolumeCoin=CheckTradevolume($Ask);
		//--API Call machen
        $nonce=time();
		//--
		$url='symbol='.$symbol.'&side=BUY&type=MARKET&quantity='.$TradeVolumeCoin.'&recvWindow=10000000000000000&timestamp='.$nonce;
		//--
		$sign=hash_hmac('SHA256',$url,$apisecret);
		$url=$url.'&signature='.$sign;
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('X-MBX-APIKEY:'.$apikey));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_URL, "https://api.binance.com/api/v3/order");
		curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$url);
		$execResult = curl_exec($ch);
		$Auftrag = json_decode($execResult, true);
		//--Rueckgabe verarbeiten
		echo 'Buylimit Auftrag  '.$symbol.'  '.$TradeVolumeCoin.'  '.var_dump($Auftrag);
		UpdateTraderequestTime($id);
		RueckgabeBearbeiten($Auftrag, $id, $Ask);
		}//$unterschied<=0.5
	}//buylimit


	
	
		
	//+-----------------------------------------------------------+
    //| Selllimit                                                 |
    //+-----------------------------------------------------------+

	if(isset($_GET['buyorsell']) && $_GET['buyorsell']=="selllimit")
	{
		//--Aktuelle preis lesen
		$Bid=ReadBinancePrice($symbol,"Bid");
		$entryprice=0; 
		if($_GET['limitbtc']>0){$entryprice=number_format($_GET['limitbtc'],8);} 
		else 
		if($_GET['limitusd']>0)
		  {
			$aa=(double)$_GET['limitusd'];
			$Btcprice=ReadBinancePrice($BitcoinName,"Bid");
			$Btcprice=(float)str_replace(",","",$Btcprice);
			$entryprice=number_format($aa/$Btcprice,8);
		  }
	 	else if($_GET['limitbtc']=="" && $_GET['limitusd']=="")UpdateTraderequestAll($id,"Error no limitprice");
		//--
		$prozentunterschied=$Bid/100;
		$abstand=abs($Bid-$entryprice);
		$unterschied=$abstand/$prozentunterschied;
		UpdateTraderequestTime($id);

		echo 'Selllimit  '.$symbol.'   '.$entryprice;
		//--
        if($unterschied<=0.5)
		{
		//--Volume
		$TradeVolumeCoin=CheckTradevolume($Bid);
		//--API Call machen
        $nonce=time();
		//--
		$url='symbol='.$symbol.'&side=SELL&type=MARKET&quantity='.$TradeVolumeCoin.'&recvWindow=10000000000000000&timestamp='.$nonce;
		//--
		$sign=hash_hmac('SHA256',$url,$apisecret);
		$url=$url.'&signature='.$sign;
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('X-MBX-APIKEY:'.$apikey));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_URL, "https://api.binance.com/api/v3/order");
		curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$url);
		$execResult = curl_exec($ch);
		$Auftrag = json_decode($execResult, true);
		//--Rueckgabe verarbeiten
		echo 'Selllimit Auftrag  '.$symbol.'  '.$TradeVolumeCoin.'  '.var_dump($Auftrag);
		UpdateTraderequestTime($id);
		RueckgabeBearbeiten($Auftrag, $id, $Bid);
		}//$unterschied<=0.5
	}//selllimit

	
	
	


	//+-----------------------------------------------------------+
    //| Takeprofit Stoploss                                       |
    //+-----------------------------------------------------------+
	
		if(isset($_GET['buyorsell']) && $_GET['buyorsell']=="tpsl" && isset($_GET['tp']))
		{
			//--Preise lesen
			$tpsldo="";
			$TPprice=number_format($_GET['tp'],8);
			$TPprice=(float)str_replace(",","",$TPprice);
			
			$TPEinheit=$_GET['tpein'];
			$SLprice=number_format($_GET['sl'],8);
			$SLprice=(float)str_replace(",","",$SLprice);
			$SLEinheit=$_GET['slein'];
			
			if($_GET['tpordertype']=="buy") $tpsldo="sell";
			else
			if($_GET['tpordertype']=="sell") $tpsldo="buy";
		
		    UpdateTraderequestTime($id);
			
			//--Takeprofit
			if($TPprice>0)
			{
				if($TPEinheit=="btc")
				{
					if($tpsldo=="sell") //close buytrade at tp open selltrade
					{
						$Bid=ReadBinancePrice($symbol,"Bid");
						$TradeVolumeCoin=CheckTradevolume($Bid);
						
						if($Bid>=$TPprice){echo 'tp close buytrade '.$Bid; DoSellAndSaveResponse($symbol, $Bid, $TradeVolumeCoin, $id, "Close at Takeprofit", $apikey, $apisecret); }
					}
					else
					if($tpsldo=="buy")  //close selltrade at tp open buytrade at ask price
					{
						$Ask=ReadBinancePrice($symbol,"Ask");
						$TradeVolumeCoin=CheckTradevolume($Ask);
						
						if($Ask<=$TPprice){echo 'tp close selltrade '.$Ask.'  '.$TPprice; DoBuyAndSaveResponse($symbol, $Ask, $TradeVolumeCoin, $id, "Close at Takeprofit", $apikey, $apisecret); }
					}
				}
				else
				if($TPEinheit=="usd" || $TPEinheit=="win")
				{
					$Btcprice=ReadBinancePrice($BitcoinName,"Bid");
					$Btcprice=(float)str_replace(",","",$Btcprice);
					$USValue=$TradevolumeBTC*$Btcprice; //soviel ist der trade aktuell wert in dollar
					$USValue=(float)str_replace(",","",$USValue);
					
					if($tpsldo=="sell") //close buytrade at tp open selltrade at bid
					{
					  $Bid=ReadBinancePrice($symbol,"Bid");
					  $TradeVolumeCoin=CheckTradevolume($Bid);
					  
					  $USDPriceCoinNow=$Bid*$Btcprice;
					  $USDPriceCoinNow=(float)str_replace(",","",$USDPriceCoinNow);
					  
					  if($TPEinheit=="usd" && $USDPriceCoinNow>=$TPprice){echo 'tp close at usd price '.$USDPriceCoinNow.'  '.$TPprice; DoSellAndSaveResponse($symbol, $Bid, $TradeVolumeCoin, $id, "Close at Takeprofit", $apikey, $apisecret); }
					  else
					  if($TPEinheit=="win" && $USValue>=$TPprice){echo 'tp close at win value '.$USValue.'  '.$TPprice; DoSellAndSaveResponse($symbol, $Bid, $TradeVolumeCoin, $id, "Close at Takeprofit", $apikey, $apisecret); }
					}
					else 
					if($tpsldo=="buy") //close selltrade at tp open buytrade
					{
					  $Ask=ReadBinancePrice($symbol,"Ask");
					  $TradeVolumeCoin=CheckTradevolume($Ask);
					  
					  $USDPriceCoinNow=$Ask*$Btcprice;
					  $USDPriceCoinNow=(float)str_replace(",","",$USDPriceCoinNow);
					  
					  if($TPEinheit=="usd" && $USDPriceCoinNow<=$TPprice){ echo 'tp close at usd price '.$USDPriceCoinNow.'  '.$TPprice; DoBuyAndSaveResponse($symbol, $Ask, $TradeVolumeCoin, $id, "Close at Takeprofit", $apikey, $apisecret); }
					  else
					  if($TPEinheit=="win" && $USValue<=$TPprice){echo 'tp close at win value '.$USValue.'  '.$TPprice; DoBuyAndSaveResponse($symbol, $Ask, $TradeVolumeCoin, $id, "Close at Takeprofit", $apikey, $apisecret); }
					}
				}
			}


			
			//--Stoploss
			if($SLprice>0)
			{
				if($SLEinheit=="btc")
				{
					if($tpsldo=="sell") //close buytrade at tp open sell trade at bid
					{
						$Bid=ReadBinancePrice($symbol,"Bid");
						$TradeVolumeCoin=CheckTradevolume($Bid);
						
						if($Bid<=$SLprice){echo 'sl close buytrade'.$Bid; DoSellAndSaveResponse($symbol, $Bid, $TradeVolumeCoin, $id, "Close at Stoploss", $apikey, $apisecret); }
					}
					else
					if($tpsldo=="buy")  //close selltrade at tp open buy at askprice
					{
						$Ask=ReadBinancePrice($symbol,"Ask");
						$TradeVolumeCoin=CheckTradevolume($Ask);
						
						if($Ask>=$SLprice){echo 'sl close selltrade'.$Ask.'  '.$SLprice; DoBuyAndSaveResponse($symbol, $Ask, $TradeVolumeCoin, $id, "Close at Stoploss", $apikey, $apisecret); }
					}
				}
				else
				if($SLEinheit=="usd" || $SLEinheit=="win")
				{
					$Btcprice=ReadBinancePrice($BitcoinName,"Bid");
					$Btcprice=(float)str_replace(",","",$Btcprice);
					$USValue=$TradevolumeBTC*$Btcprice;
					$USValue=(float)str_replace(",","",$USValue);
					
					
					if($tpsldo=="sell") //close buytrade at tp open sell at bidprice
					{
					  $Bid=ReadBinancePrice($symbol,"Bid");
					  $TradeVolumeCoin=CheckTradevolume($Bid);
					  
					  $USDPriceCoinNow=$Bid*$Btcprice;
					  $USDPriceCoinNow=(float)str_replace(",","",$USDPriceCoinNow);
					  
					  if($SLEinheit=="usd" && $USDPriceCoinNow<=$SLprice){echo 'sl close at usd price'.$USDPriceCoinNow.'  '.$SLprice; DoSellAndSaveResponse($symbol, $Bid, $TradeVolumeCoin, $id, "Close at Stoploss", $apikey, $apisecret); }
					  else
					  if($SLEinheit=="win" && $USValue<=$SLprice){echo 'sl close dosell at loos value'.$USValue.'  '.$SLprice; DoSellAndSaveResponse($symbol, $Bid, $TradeVolumeCoin, $id, "Close at Stoploss", $apikey, $apisecret); }
					}
					else 
					if($tpsldo=="buy") //close selltrade at tp open buyorder at askprice
					{
					  $Ask=ReadBinancePrice($symbol,"Ask");
					  $TradeVolumeCoin=CheckTradevolume($Ask);
					  
					  $USDPriceCoinNow=$Ask*$Btcprice;
					  $USDPriceCoinNow=(float)str_replace(",","",$USDPriceCoinNow);
					  
					  if($SLEinheit=="usd" && $USDPriceCoinNow>=$SLprice){echo 'sl close at usd price'.$USDPriceCoinNow.'  '.$SLprice; DoBuyAndSaveResponse($symbol, $Ask, $TradeVolumeCoin, $id, "Close at Stoploss", $apikey, $apisecret); }
					  else
					  if($SLEinheit=="win" && $USValue>=$SLprice){echo 'sl close dobuy at loos value'.$USValue.'  '.$SLprice; DoBuyAndSaveResponse($symbol, $Ask, $TradeVolumeCoin, $id, "Close at Stoploss", $apikey, $apisecret); }
					}
				}
			}
		}




		function DoBuyAndSaveResponse($symbol, $Ask, $VolumeCoin, $id, $Closeat, $apikey, $apisecret, $v1="leer")
		{
			$symbol2=$GLOBALS['symbol2'];
			//--API Call machen
			$nonce=time();
			//--
			$url='symbol='.$symbol.'&side=BUY&type=MARKET&quantity='.$VolumeCoin.'&recvWindow=10000000000000000&timestamp='.$nonce;
			//--
			$sign=hash_hmac('SHA256',$url,$apisecret);
			$url=$url.'&signature='.$sign;
			$ch = curl_init($url);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('X-MBX-APIKEY:'.$apikey));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_URL, "https://api.binance.com/api/v3/order");
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,$url);
			$execResult = curl_exec($ch);
			$Auftrag = json_decode($execResult, true);
			//--Rueckgabe verarbeiten
			echo 'DoBuy Auftrag  '.$symbol.'  '.$VolumeCoin.'  '.var_dump($Auftrag);
			UpdateTraderequestTime($id);
			if(isset($Auftrag["clientOrderId"]) && $Auftrag["clientOrderId"]!="")
			  {
				UpdateTraderequestAll($id,$Closeat); echo "alles klar";
				if($v1=="bh")InsertTradedBuyAndHoldTraderequest("Binance", $symbol2, $_GET['name'], $_GET['volumebtc'], $_GET['volumeusd'], $VolumeCoin, "Successful", "tpsl");
			  }
			else
			if(isset($Auftrag["code"]))
			  {
				if($Auftrag["msg"]=="Invalid quantity.")
				{
					UpdateTraderequestAll($id,"Error volume to small"); echo "volume zu klein";
					if($v1=="bh")InsertTradedBuyAndHoldTraderequest("Binance", $symbol2, $_GET['name'], $_GET['volumebtc'], $_GET['volumeusd'], $VolumeCoin, "Error volume to small", "tpsl");
				}
				else
				if($Auftrag["msg"]=="Invalid quantity.")
				{
					UpdateTraderequestAll($id,"Error volume to small"); echo "volume zu klein";
					if($v1=="bh")InsertTradedBuyAndHoldTraderequest("Binance", $symbol2, $_GET['name'], $_GET['volumebtc'], $_GET['volumeusd'], $VolumeCoin, "Error volume to small", "tpsl");
				}
				else
				if($Auftrag["msg"]=="Account has insufficient balance for requested action.")
				{
					UpdateTraderequestAll($id,"Error volume to big"); echo "volume zu gros";
					if($v1=="bh")InsertTradedBuyAndHoldTraderequest("Binance", $symbol2, $_GET['name'], $_GET['volumebtc'], $_GET['volumeusd'], $VolumeCoin, "Error volume to big", "tpsl");
				}
				else
				if($Auftrag["msg"]=="Invalid symbol.")
				{
					UpdateTraderequestAll($id,"Error Invalid currencyPair"); echo "falsche symbol";
					if($v1=="bh")InsertTradedBuyAndHoldTraderequest("Binance", $symbol2, $_GET['name'], $_GET['volumebtc'], $_GET['volumeusd'], $VolumeCoin, "Error Invalid currencyPair", "tpsl");
				}
				else
				{UpdateTraderequest("0", "Pending", $id); echo "auftrag pending";}
			  }
		}




		function DoSellAndSaveResponse($symbol, $Bid, $VolumeCoin, $id, $Closeat, $apikey, $apisecret, $v1="leer")
		{
			$symbol2=$GLOBALS['symbol2'];
			//--API Call machen
			$nonce=time();
			//--
			$url='symbol='.$symbol.'&side=BUY&type=MARKET&quantity='.$VolumeCoin.'&recvWindow=10000000000000000&timestamp='.$nonce;
			//--
			$sign=hash_hmac('SHA256',$url,$apisecret);
			$url=$url.'&signature='.$sign;
			$ch = curl_init($url);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('X-MBX-APIKEY:'.$apikey));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_URL, "https://api.binance.com/api/v3/order");
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,$url);
			$execResult = curl_exec($ch);
			$Auftrag = json_decode($execResult, true);
			//--Rueckgabe verarbeiten
			echo 'DoSell Auftrag  '.$symbol.'  '.$VolumeCoin.'  '.var_dump($Auftrag);
			UpdateTraderequestTime($id);
			if(isset($Auftrag["clientOrderId"]) && $Auftrag["clientOrderId"]!="")
			  {
				UpdateTraderequestAll($id,$Closeat); echo "alles klar";
				if($v1=="bh")InsertTradedBuyAndHoldTraderequest("Binance", $symbol2, $_GET['name'], $_GET['volumebtc'], $_GET['volumeusd'], $VolumeCoin, "Successful", "tpsl");
			  }
			else
			if(isset($Auftrag["code"]))
			  {
				if($Auftrag["msg"]=="Invalid quantity.")
				{
					UpdateTraderequestAll($id,"Error volume to small"); echo "volume zu klein";
					if($v1=="bh")InsertTradedBuyAndHoldTraderequest("Binance", $symbol2, $_GET['name'], $_GET['volumebtc'], $_GET['volumeusd'], $VolumeCoin, "Error volume to small", "tpsl");
				}
				else
				if($Auftrag["msg"]=="Invalid quantity.")
				{
					UpdateTraderequestAll($id,"Error volume to small"); echo "volume zu klein";
					if($v1=="bh")InsertTradedBuyAndHoldTraderequest("Binance", $symbol2, $_GET['name'], $_GET['volumebtc'], $_GET['volumeusd'], $VolumeCoin, "Error volume to small", "tpsl");
				}
				else
				if($Auftrag["msg"]=="Account has insufficient balance for requested action.")
				{
					UpdateTraderequestAll($id,"Error volume to big"); echo "volume zu gros";
					if($v1=="bh")InsertTradedBuyAndHoldTraderequest("Binance", $symbol2, $_GET['name'], $_GET['volumebtc'], $_GET['volumeusd'], $VolumeCoin, "Error volume to big", "tpsl");
				}
				else
				if($Auftrag["msg"]=="Invalid symbol.")
				{
					UpdateTraderequestAll($id,"Error Invalid currencyPair"); echo "falsche symbol";
					if($v1=="bh")InsertTradedBuyAndHoldTraderequest("Binance", $symbol2, $_GET['name'], $_GET['volumebtc'], $_GET['volumeusd'], $VolumeCoin, "Error Invalid currencyPair", "tpsl");
				}
				else
				{UpdateTraderequest("0", "Pending", $id); echo "auftrag pending";}
			  }
		}
		
		
	
	
	
	
	
	
	//+-----------------------------------------------------------+
    //| Buy And Hold                                              |
    //+-----------------------------------------------------------+

	if(isset($_GET['buyorsell']) && $_GET['buyorsell']=="buyandhold")
		{
			if($TradevolumeBTC=="")UpdateTraderequest("1", "Error volume to small", $id);
			else
			{
			$Ask=ReadBinancePrice($symbol,"Ask");
			//--
			if($lastbuyprice<=0 && $buyholdbesitz<=0)$lastbuyprice=0; else if($lastbuyprice<=0)$lastbuyprice=$Ask;//Wenn noch neu ist dann wird unterschied auf 100% gemacht damit der erste trade kommt danach wird geschaut wenn abstand wieder erreicht ist neu kaufen und wenn die variable kein wert hat wegen irgendeinen fehler dann wird der abstand auf 0 gesetzt also kein handel
			$prozentunterschied=$Ask/100;
			$abstand=abs($Ask-$lastbuyprice);
			$unterschied=$abstand/$prozentunterschied;
			UpdateTraderequestTime($id);
			//--
			echo 'Buy And Hold '.$symbol.' maxtrades '.$_GET['maxtrades'].'  lastbuy: '.$lastbuyprice.'  buyholdbesitz '.$buyholdbesitz.'   btcmysql: '.$TradevolumeBTC.' actualpr: '.$unterschied.' bh% '.$buyholdprozent.'  ';
			
			if($unterschied>=$buyholdprozent && $tradesgemachtbh<$_GET['maxtrades'])
			{
				//--Volume
				$TradeVolumeCoin=CheckTradevolume($Ask);
				//--API Call machen
				$nonce=time();
				//--
				$url='symbol='.$symbol.'&side=BUY&type=MARKET&quantity='.$TradeVolumeCoin.'&recvWindow=10000000000000000&timestamp='.$nonce;
				//--
				$sign=hash_hmac('SHA256',$url,$apisecret);
				$url=$url.'&signature='.$sign;
				$ch = curl_init($url);
				curl_setopt($ch, CURLOPT_HTTPHEADER, array('X-MBX-APIKEY:'.$apikey));
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
				curl_setopt($ch, CURLOPT_URL, "https://api.binance.com/api/v3/order");
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_POSTFIELDS,$url);
				$execResult = curl_exec($ch);
				$Auftrag = json_decode($execResult, true);
				//--Rueckgabe verarbeiten
				echo 'Buylimit Auftrag  '.$symbol.'  '.$TradeVolumeCoin.'  '.var_dump($Auftrag);
				UpdateTraderequestTime($id);
				$BuyHoldBesitz=(float)str_replace(",","",$buyholdbesitz);
				if($BuyHoldBesitz=="")$BuyHoldBesitz="0";
				if(isset($Auftrag["clientOrderId"]) && $Auftrag["clientOrderId"]!="")
				  {
					$Amount=(float)str_replace(",","",$Auftrag["executedQty"]);
					$BuyHoldBesitz=$BuyHoldBesitz+$Amount;
					$BuyHoldBesitz=(float)str_replace(",","",$BuyHoldBesitz);
					$tradesgemachtbh=$tradesgemachtbh+1;
					$tradesgemachtbh=(float)str_replace(",","",$tradesgemachtbh);
					
					echo 'voher '.$buyholdbesitz.'  nachher '.$BuyHoldBesitz.'  tradesgemachtbh '.$tradesgemachtbh;
					UpdateTraderequest("1", "Successful", $id, $Ask, $BuyHoldBesitz, $tradesgemachtbh);
					InsertTradedBuyAndHoldTraderequest("Binance", $symbol2, $_GET['name'], $_GET['volumebtc'], $_GET['volumeusd'], $_GET['volumecoin'], "Successful");
				  }
				else
				if(isset($Auftrag["code"]))
				  {
					if($Auftrag["msg"]=="Invalid quantity.")
					{
						UpdateTraderequest("1", "Error volume to small", $id, $Ask, $BuyHoldBesitz);echo "volume zu klein";
						InsertTradedBuyAndHoldTraderequest("Binance", $symbol2, $_GET['name'], $_GET['volumebtc'], $_GET['volumeusd'], $_GET['volumecoin'], "Error volume to small");
					}
					else
					if($Auftrag["msg"]=="Invalid quantity.")
					{
						UpdateTraderequest("1", "Error volume to small", $id, $Ask, $BuyHoldBesitz);echo "volume zu klein";
						InsertTradedBuyAndHoldTraderequest("Binance", $symbol2, $_GET['name'], $_GET['volumebtc'], $_GET['volumeusd'], $_GET['volumecoin'], "Error volume to small");
					}
					else
					if($Auftrag["msg"]=="Account has insufficient balance for requested action.")
					{
						UpdateTraderequest("1", "Error volume to big", $id, $Ask, $BuyHoldBesitz);echo "volume zu gros";
						InsertTradedBuyAndHoldTraderequest("Binance", $symbol2, $_GET['name'], $_GET['volumebtc'], $_GET['volumeusd'], $_GET['volumecoin'], "Error volume to big");
					}
					else
					if($Auftrag["msg"]=="Invalid symbol.")
					{
						UpdateTraderequest("1", "Error Invalid currencyPair", $id, $Ask, $BuyHoldBesitz);echo "falsche symbol";
						InsertTradedBuyAndHoldTraderequest("Binance", $symbol2, $_GET['name'], $_GET['volumebtc'], $_GET['volumeusd'], $_GET['volumecoin'], "Error Invalid currencyPair");
					}
					else
					{ UpdateTraderequest("0", "Pending", $id, $Ask, $BuyHoldBesitz); echo "auftrag pending";}
				  }
			}
			
			if(isset($_GET['tp']) && $buyholdbesitz>0)
			  {
				$tpsldo="sell"; //immer sell fuer schliessen von trades weil ist ja buy and hold
				$TPprice=number_format($_GET['tp'],8);
				$TPprice=(float)str_replace(",","",$TPprice);
				$TPEinheit=$_GET['tpein'];

				$SLprice=number_format($_GET['sl'],8);
				$SLprice=(float)str_replace(",","",$SLprice);
				$SLEinheit=$_GET['slein'];
				

				//--Takeprofit
				if($TPprice>0)
				{
					if($TPEinheit=="btc")
					{
						if($tpsldo=="sell") //close buytrade at tp open selltrade
						{
							$Bid=ReadBinancePrice($symbol,"Bid");
							$TradeVolumeCoin=(float)str_replace(",","",$buyholdbesitz);
							$TradeVolumeCoin=number_format($TradeVolumeCoin,LotsizeFilter($symbol));
							if($Bid>=$TPprice){echo 'buyhold tp btc price close buytrade '.$Bid; DoSellAndSaveResponse($symbol, $Bid, $TradeVolumeCoin, $id, "Close at Takeprofit", $apikey, $apisecret);}
						}
					}
					else
					if($TPEinheit=="usd" || $TPEinheit=="win")
					{
						$Btcprice=ReadBinancePrice($BitcoinName,"Bid");
						$Bid=ReadBinancePrice($symbol,"Bid");
						$Btcprice=(float)str_replace(",","",$Btcprice);
						$CoinsInBesitz=(float)str_replace(",","",$buyholdbesitz);
						$AktuelleDollarPriceFuerEinCoin=$Bid*$Btcprice;
						$USValue=$CoinsInBesitz*$AktuelleDollarPriceFuerEinCoin; //soviel ist der trade aktuell wert in dollar
						$USValue=(float)str_replace(",","",$USValue);
						
						if($tpsldo=="sell") //close buytrade at tp open selltrade at bid
						{
						  $TradeVolumeCoin=(float)str_replace(",","",$buyholdbesitz);
						  $TradeVolumeCoin=number_format($TradeVolumeCoin,LotsizeFilter($symbol));
						  $USDPriceCoinNow=$Bid*$Btcprice;
						  $USDPriceCoinNow=(float)str_replace(",","",$USDPriceCoinNow);
						  
						  if($TPEinheit=="usd" && $USDPriceCoinNow>=$TPprice){echo 'buyhold tp close at usd price '.$USDPriceCoinNow.'  '.$TPprice; DoSellAndSaveResponse($symbol, $Bid, $TradeVolumeCoin, $id, "Close at Takeprofit", $apikey, $apisecret); }
						  else
						  if($TPEinheit=="win" && $USValue>=$TPprice){echo 'buyhold tp close at win value '.$USValue.'  '.$TPprice; DoSellAndSaveResponse($symbol, $Bid, $TradeVolumeCoin, $id, "Close at Takeprofit", $apikey, $apisecret);}
						}
					}
				}//if TPprice>0
				
				//--Stoploss
				if($SLprice>0)
				{
					if($SLEinheit=="btc")
					{
						if($tpsldo=="sell") //close buytrade at tp open selltrade
						{
							$Bid=ReadBinancePrice($symbol,"Bid");
							$TradeVolumeCoin=(float)str_replace(",","",$buyholdbesitz);
							$TradeVolumeCoin=number_format($TradeVolumeCoin,LotsizeFilter($symbol));
							if($Bid<=$SLprice){echo 'buyhold sl btc price close buytrade '.$Bid; DoSellAndSaveResponse($symbol, $Bid, $TradeVolumeCoin, $id, "Close at Stoploss", $apikey, $apisecret); }
						}
					}
					else
					if($SLEinheit=="usd" || $SLEinheit=="win")
					{
						$Btcprice=ReadBinancePrice($BitcoinName,"Bid");
						$Bid=ReadBinancePrice($symbol,"Bid");
						$Btcprice=(float)str_replace(",","",$Btcprice);
						$CoinsInBesitz=(float)str_replace(",","",$buyholdbesitz);
						$AktuelleDollarPriceFuerEinCoin=$Bid*$Btcprice;
						$USValue=$CoinsInBesitz*$AktuelleDollarPriceFuerEinCoin; //soviel ist der trade aktuell wert in dollar
                        $USValue=(float)str_replace(",","",$USValue);

						if($tpsldo=="sell") //close buytrade at sl open selltrade at bid
						{
						  $TradeVolumeCoin=(float)str_replace(",","",$buyholdbesitz);
						  $TradeVolumeCoin=number_format($TradeVolumeCoin,LotsizeFilter($symbol));
						  $USDPriceCoinNow=$Bid*$Btcprice;
						  $USDPriceCoinNow=(float)str_replace(",","",$USDPriceCoinNow);
						  
						  if($SLEinheit=="usd" && $USDPriceCoinNow<=$SLprice){echo 'buyhold sl close at usd price '.$USDPriceCoinNow.'  '.$SLprice; DoSellAndSaveResponse($symbol, $Bid, $TradeVolumeCoin, $id, "Close at Stoploss", $apikey, $apisecret); }
						  else
						  if($SLEinheit=="win" && $USValue<=$SLprice){echo 'buyhold sl close at win value '.$USValue.'  '.$SLprice; DoSellAndSaveResponse($symbol, $Bid, $TradeVolumeCoin, $id, "Close at Stoploss", $apikey, $apisecret); }
						}
					}
				}//if SLprice>0
			  }//isset get tp
			}
		}//buyandhold





		
		
		
		
	//+-----------------------------------------------------------+
    //| Delete Pendingorder                                       |
    //+-----------------------------------------------------------+

		if(isset($_GET['DeletePending']))
		{
			$str=file_get_contents($allcoinsfile);
			$Pairs = json_decode($str, true);
			$symbol="";		    	    
			for($i2=0; $i2<count($Pairs["Coins"]); $i2++)
				{
				if($Pairs["Coins"][$i2]["name"]==$_GET['nam'])
				  {
					$symbol=$Pairs["Coins"][$i2]["symbol"];
					break;
				  }
			}
			$symbol=$symbol.''.$_GET['priceeinh'];
			//--API Call machen
			$nonce=time();
			//--
			$orid=$_GET['DeletePending'];
			$url='recvWindow=10000000000000000&symbol='.$symbol.'&origClientOrderId='.$orid.'&timestamp='.$nonce;
			//--
			$sign=hash_hmac('SHA256',$url,$apisecret);
			$url=$url.'&signature='.$sign;
			$ch = curl_init($url);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('X-MBX-APIKEY:'.$apikey));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_URL, "https://api.binance.com/api/v3/order");
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $url);
			$execResult = curl_exec($ch);
			$Auftrag = json_decode($execResult, true);
			//var_dump($Auftrag);
			//--Rueckgabe verarbeiten
			if(isset($Auftrag["clientOrderId"]) && $Auftrag["clientOrderId"]!="")
			  {
				echo "Successful";
			  }
		}

		
		
		

		
		
		
		
    //+-----------------------------------------------------------+
    //| Read Balances                                             |
    //+-----------------------------------------------------------+
	
		if(isset($_GET['OpenTrades']))
		{
			//--API Call machen
			$nonce=time();
			//--
			$url='recvWindow=10000000000000000&timestamp='.$nonce;
			//--
			$sign=hash_hmac('SHA256',$url,$apisecret);
			$url=$url.'&signature='.$sign;
			$ch = curl_init($url);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('X-MBX-APIKEY:'.$apikey));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_URL, "https://api.binance.com/api/v3/account?".$url);
			$execResult = curl_exec($ch);
			$Balances = json_decode($execResult, true);
			//var_dump($Balances);
			//--
			$str = "";
			$str = '{ "OpenTrades":[ ';
			$a=0;
			if(gettype($Balances)=="array" && count($Balances["balances"])>=1)
			{
				for($i=0; $i<count($Balances["balances"]); $i++)
				{
				    if($Balances["balances"][$i]["free"]>0)
					{
						if($a==0)$str .=  '  { "symbol":"'.$Balances["balances"][$i]["asset"].'", "balance":"'.$Balances["balances"][$i]["free"].'" }'."\r\n"; 
					    else     $str .=  ', { "symbol":"'.$Balances["balances"][$i]["asset"].'", "balance":"'.$Balances["balances"][$i]["free"].'" }'."\r\n"; 
					    $a++;
					}	
				}
				$str .= ' ] }';
				//--Json Datei erstellen
				
   				   $myfile = fopen("BinanceBalances.txt", "w"); 
				   fwrite($myfile, $str);
				   fclose($myfile);
				
			}
			//--Datei Ausgeben
			if(file_exists("BinanceBalances.txt")) echo file_get_contents("BinanceBalances.txt");
		}



		
		
		

    //+-----------------------------------------------------------+
    //| Read Pendingorders                                        |
    //+-----------------------------------------------------------+
		
		if(isset($_GET['OpenPendings']))
		{
			$str=file_get_contents($allcoinsfile);
			$Pairs = json_decode($str, true);
			
			//--API Call machen
			$nonce=time();
			//--
			$url='recvWindow=10000000000000000&timestamp='.$nonce;
			//--
			$sign=hash_hmac('SHA256',$url,$apisecret);
			$url=$url.'&signature='.$sign;
			$ch = curl_init($url);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('X-MBX-APIKEY:'.$apikey));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_URL, "https://api.binance.com/api/v3/openOrders?".$url);
			$execResult = curl_exec($ch);
			$Pendings = json_decode($execResult, true);
			//var_dump($Pendings);
			//--
			$str = "";
		    $str = '{ "OpenPendings":[ ';	
			$a=0;
			if(gettype($Pendings)=="array" && count($Pendings)>=1)
			{
				for($i=0; $i<count($Pendings); $i++)
				{
				  $waehrung="";
				  if(strpos($Pendings[$i]["symbol"],"BTC",0)>=0 && strpos($Pendings[$i]["symbol"],"BTC",0)!==false)$waehrung="BTC";
				  if(strpos($Pendings[$i]["symbol"],"ETH",0)>=0 && strpos($Pendings[$i]["symbol"],"ETH",0)!==false)$waehrung="ETH";
				  if(strpos($Pendings[$i]["symbol"],"USDT",0)>=0 && strpos($Pendings[$i]["symbol"],"USDT",0)!==false)$waehrung="USDT";
				  //--
				  $symbol=str_replace("BTC","",$Pendings[$i]["symbol"]);
				  $symbol=str_replace("USDT","",$symbol);
				  $symbol=str_replace("ETH","",$symbol);
				  //--
				  $name="";		    	    
				  for($i2=0; $i2<count($Pairs["Coins"]); $i2++)
					 {
						if($Pairs["Coins"][$i2]["symbol"]==$symbol)
						{
							$name=$Pairs["Coins"][$i2]["name"];
							break;
						}
				     }
				  $amountwr=$symbol;
				  //--	  
				  if($a==0)$str .=  '  { "tp":"", "tpein":"","sl":"", "slein":"", "speicher":"broker", "id":"'.$Pendings[$i]["clientOrderId"].'", "symbol":"'.$symbol.'", "broker":"Binance", "name":"'.$name.'", "typ":"'.$Pendings[$i]["side"].' '.$Pendings[$i]["type"].'", "price":"'.number_format($Pendings[$i]["price"],8).'", "waehrung":"'.$waehrung.'", "amount":"'.$Pendings[$i]["origQty"].'", "amountwr":"'.$amountwr.'"  }'."\r\n"; 
				  else     $str .=  ', { "tp":"", "tpein":"","sl":"", "slein":"", "speicher":"broker", "id":"'.$Pendings[$i]["clientOrderId"].'", "symbol":"'.$symbol.'", "broker":"Binance", "name":"'.$name.'", "typ":"'.$Pendings[$i]["side"].' '.$Pendings[$i]["type"].'", "price":"'.number_format($Pendings[$i]["price"],8).'", "waehrung":"'.$waehrung.'", "amount":"'.$Pendings[$i]["origQty"].'", "amountwr":"'.$amountwr.'"  }'."\r\n"; 
				  $a++;
			    }
			}//gettype==array
			

				  
				  //--Alle unausgefuehrten Auftraege von mysql
				  include('dbcon.php');
				  $sql="Select * FROM ".$Database.".`tradingrequest` WHERE `broker`='Binance' AND (`typ`='MarketBuy' OR `typ`='MarketSell') AND (`sended`='0' OR `tpsltraded`='0')";
				  $result = mysqli_query($DatabasePointer,$sql); 
				  if($error = mysqli_error($DatabasePointer)) die('Error, Read Binance Traderequest query failed with:' . $error);
				  $i=0;
				  while($row = mysqli_fetch_array($result))
					{		
						if($row['typ']=="MarketBuy" || $row['typ']=="MarketSell")
						{
							$buyorsell="";
							$price="";
							$waehrung="";
							$amount="";
							$amountwr="";
							$symbol="";
							$name="";
							$tp="";
							$tpein="";
							$sl="";
							$slein="";
							
								//--	    
							    for($i=0; $i<count($Pairs["Coins"]); $i++)
								{
									if($Pairs["Coins"][$i]["name"]==$row["coin"])
									{
										$symbol=$Pairs["Coins"][$i]["symbol"];
										$name=$Pairs["Coins"][$i]["name"];
										break;
									}
								}

					            //--

								if($row['market_or_limit']=="limitprice")
								{
									if($row['typ']=="MarketBuy")$buyorsell="Buylimit";
									else
									if($row['typ']=="MarketSell")$buyorsell="Selllimit";
								}
								else if($row['typ']=="MarketBuy")$buyorsell="Buy";
								else if($row['typ']=="MarketSell")$buyorsell="Sell";

								//--Wenn die Order schon offen ist und kein TP oder SL hat dann nicht anzeigen
							    if(($row['market_or_limit']=="limitprice" && $row['sended']==1) && ($row['typ']=="MarketBuy" || $row['typ']=="MarketSell"))
								{
								  if($row['tpusdprice']=="" && $row['tpusdvalue']=="" && $row['tpbtcprice']=="" &&
								     $row['slusdprice']=="" && $row['slusdvalue']=="" && $row['slbtcprice']=="")continue;
								}
								if(($row['market_or_limit']=="marketprice" && $row['sended']==1) && ($row['typ']=="MarketBuy" || $row['typ']=="MarketSell"))
								{
								  if($row['tpusdprice']=="" && $row['tpusdvalue']=="" && $row['tpbtcprice']=="" &&
								     $row['slusdprice']=="" && $row['slusdvalue']=="" && $row['slbtcprice']=="")continue;
								}
								
						        if(strpos($row['result'],"Error",0)>=0 && strpos($row['result'],"Error",0)!==false)continue; //Auch Eintraege mit Error ueberspringen
								//--
								if($row['tpusdprice']!=""){$tp=$row['tpusdprice'];$tpein="USD";} else if($row['tpusdvalue']!=""){$tp=$row['tpusdvalue'];$tpein="USDW";}  else if($row['tpbtcprice']!=""){$tp=$row['tpbtcprice'];$tpein="BTC";} 
								if($row['slusdprice']!=""){$sl=$row['slusdprice'];$slein="USD";} else if($row['slusdvalue']!=""){$sl=$row['slusdvalue'];$slein="USDW";}  else if($row['slbtcprice']!=""){$sl=$row['slbtcprice'];$slein="BTC";} 
								//--
								if($row['limitbtcprice']!=""){$price=$row['limitbtcprice'];$waehrung="BTC";}
								else
								if($row['limitusdprice']!=""){$price=$row['limitusdprice'];$waehrung="USD";}
								else
								if($row['market_or_limit']=="marketprice"){$price="Marketprice";$waehrung="";}
								if($row['market_or_limit']=="limitprice" && $row['sended']==1){$price="Marketprice";$waehrung="";}
							    //--
								if($row['volumeusd']!=""){$amount=$row['volumeusd'];$amountwr="USD";}
								else
								if($row['volumebtc']!=""){$amount=$row['volumebtc'];$amountwr="BTC";}
							    else
								if($row['volumecoin']!=""){$amount=$row['volumecoin'];$amountwr="COIN";}
							    //--
								if($a==0)$str .= '  { "tp":"'.$tp.'", "tpein":"'.$tpein.'","sl":"'.$sl.'", "slein":"'.$slein.'", "speicher":"mysql", "id":"'.$row["id"].'", "symbol":"'.$symbol.'", "broker":"Binance", "name":"'.$name.'", "typ":"'.$buyorsell.'", "price":"'.$price.'", "waehrung":"'.$waehrung.'", "amount":"'.$amount.'", "amountwr":"'.$amountwr.'" }'."\r\n"; 
						        else     $str .= ', { "tp":"'.$tp.'", "tpein":"'.$tpein.'","sl":"'.$sl.'", "slein":"'.$slein.'", "speicher":"mysql", "id":"'.$row["id"].'", "symbol":"'.$symbol.'", "broker":"Binance", "name":"'.$name.'", "typ":"'.$buyorsell.'", "price":"'.$price.'", "waehrung":"'.$waehrung.'", "amount":"'.$amount.'", "amountwr":"'.$amountwr.'" }'."\r\n"; 
						        $a++;
							
						}	
							
					}
				$str .= ' ] }';
				//--Json Datei erstellen
				
   				   $myfile = fopen("BinancePendings.txt", "w"); 
				   fwrite($myfile, $str);
				   fclose($myfile);
			
			//--Datei Ausgeben
			if(file_exists("BinancePendings.txt"))echo file_get_contents("BinancePendings.txt");
		}
		
		
		
		
		
	
    //+-----------------------------------------------------------+
    //| Anzahl Orders in Textdatei speichern                      |
    //+-----------------------------------------------------------+

    if(isset($_GET['OpenTrades']) || isset($_GET['OpenPendings']))
	{
      $page = json_decode(file_get_contents("BinanceBalances.txt"),true);
	  $eins = count($page["OpenTrades"]);
      $page = json_decode(file_get_contents("BinancePendings.txt"),true);
	  $zwei = count($page["OpenPendings"]);
	  $zahl = $eins+$zwei; $myfile = fopen("AnzahlOrdersBinance.txt", "w"); fwrite($myfile, $zahl); fclose($myfile);
	}
?>