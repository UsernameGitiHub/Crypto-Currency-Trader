<?php

  set_time_limit(0);

  //+-----------------------------------------------------------+
  //| Datenbank Verbindung aufrufen                             |
  //+-----------------------------------------------------------+

     include('dbcon.php');

	
	function curl_get_file_contents($URL)
    {
        $c = curl_init();
        curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($c, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($c, CURLOPT_URL, $URL);
        $contents = curl_exec($c);
        curl_close($c);

        if ($contents) return $contents;
        else return FALSE;
    }

    $Backbars=450; //Maximal Anzahl Candelsticks
	$SymbolDownloaden=$_GET['symbol'];
	$cmcid=$_GET['cmcid'];
    $Coinname="";
    if(isset($_GET['name']))$Coinname=$_GET['name'];
    

    function FormatStringToNumber($a)
    {
      $b=(float)str_replace(",","",$a);
      return($b);
    }

//----
if(strlen($SymbolDownloaden)>3 && $SymbolDownloaden!="undefined")
  {


 $forschleifeanzahl=1;
 if($SymbolDownloaden=="BTCUSDT")$forschleifeanzahl=4;

 for($ab=0; $ab<$forschleifeanzahl; $ab++)
 {
    $tmf="";
    $timeframe="";
    $CandelsPeriode=0;

    if($ab==0){ $tmf="1d"; $timeframe="D1"; $CandelsPeriode=86400; }
    else
    if($ab==1){ $tmf="2h"; $timeframe="H2"; $CandelsPeriode=7200; }
    else
    if($ab==2){ $tmf="4h"; $timeframe="H4"; $CandelsPeriode=14400; }
    else
    if($ab==3){ $tmf="30m"; $timeframe="M30"; $CandelsPeriode=1800; }



    
    $filename ="Textdateien_LastCandelDatum/AktualBar_".$SymbolDownloaden.'_'.$timeframe.".txt";

    //--

    $zeitstart=0;

    //--

    if($SymbolDownloaden=="BTCUSDT")$zeitstart=0;
    if($zeitstart<=0)$zeitstart=time()-($Backbars*$CandelsPeriode);
    $zeitende=time()+(240*3600);
    
   


    $url = "https://api.binance.com/api/v1/klines?symbol=".$SymbolDownloaden."&interval=".$tmf."&startTime=".$zeitstart."000&endTime=".$zeitende."000";
    echo $url.'<br>';
    $page = curl_get_file_contents($url);
    $page = json_decode($page,true);
    //echo var_dump($page);
    echo "Anzahl: ".count($page)."  ".$tmf."<br>";
    $NeusteKerze=0;
    $filename2="Textdateien_Charts_BTC/Binance_Chart_".$SymbolDownloaden.'_'.$timeframe.".txt";



    unset($highus);
    unset($lowus);
    unset($closeus);
    unset($openus);
    unset($dateus);

    $highus=array();
    $lowus=array();
    $closeus=array();
    $openus=array();
    $dateus=array();

//--
 
    if(count($page)>=1 && gettype($page)=="array") 
      {

         if($SymbolDownloaden=="BTCUSDT")
         {
          
          $myfile2 = fopen($filename2, "w");
          $str = '{ "Chart":[ ';
          fwrite($myfile2, $str);
         }

        for($i=0; $i<count($page); $i++)
        {
               $date=substr($page[$i][0],0,10);

               $open=$page[$i][1];
               $high=$page[$i][2];
               $low=$page[$i][3];
               $close=$page[$i][4];
               
               if($date>$NeusteKerze || $NeusteKerze==0)$NeusteKerze=$date;
               $symdate=$SymbolDownloaden.'_'.$timeframe.'_'.$date;


             if($SymbolDownloaden=="BTCUSDT")
             {
               
               if($i==0)$str = '  { "timeframe":"'.$timeframe.'", "date":"'.$date.'", "open":"'.$open.'", "high":"'.$high.'", "low":"'.$low.'", "close":"'.$close.'"  }'."\r\n"; 
               else     $str = ', { "timeframe":"'.$timeframe.'", "date":"'.$date.'", "open":"'.$open.'", "high":"'.$high.'", "low":"'.$low.'", "close":"'.$close.'"  }'."\r\n"; 
               fwrite($myfile2, $str);
             }


            $dateus[$i][1]=$date;
            $highus[$i][1]=$high;
            $lowus[$i][1]=$low;
            $closeus[$i][1]=$close;
            $openus[$i][1]=$open;

            $dateus[$i][2]=0;
            $highus[$i][2]=0;
            $lowus[$i][2]=0;
            $closeus[$i][2]=0;
            $openus[$i][2]=0;
                    
        }//for


  if($SymbolDownloaden=="BTCUSDT")
  {
   $str =  ' ] }';
   fwrite($myfile2, $str);
   fclose($myfile2);
  }





  
  
  
  
  
  









    unset($bhigh);
    unset($blow);
    unset($bclose);
    unset($bopen);
    unset($bdate);

    $bhigh=array();
    $blow=array();
    $bclose=array();
    $bopen=array();
    $bdate=array();

    $bitcoinkurse="Textdateien_Charts_BTC/Binance_Chart_BTCUSDT_".$timeframe.".txt";
    if(file_exists($bitcoinkurse))
    {

    $page = file_get_contents($bitcoinkurse);
    $page = json_decode($page,true);

    for($i=0; $i<count($page["Chart"]); $i++)
    {
      $bdate[$i]=$page["Chart"][$i]["date"];
      $bhigh[$i]=$page["Chart"][$i]["high"];
      $blow[$i]=$page["Chart"][$i]["low"];
      $bclose[$i]=$page["Chart"][$i]["close"];
      $bopen[$i]=$page["Chart"][$i]["open"];
    }







    $charthigh=0;
    $chartlow=0;
    $AverageCandelMove=0;
    if(count($dateus)>1)
    {
    $b=0;
    for($i=0; $i<count($dateus); $i++)
       {
        for($i2=0; $i2<count($bdate); $i2++)
           {
             if($dateus[$i][1]==$bdate[$i2] && $dateus[$i][1]>0 && $bdate[$i2]>0)
             {
               $dateus[$b][2]=$bdate[$i2];
               $highus[$b][2]=$bhigh[$i2] * $highus[$i][1];
               $lowus[$b][2]=$blow[$i2] * $lowus[$i][1];
               $closeus[$b][2]=$bclose[$i2] * $closeus[$i][1];
               $openus[$b][2]=$bopen[$i2] * $openus[$i][1];

               if($SymbolDownloaden=="BTCUSDT")
               {
               $highus[$b][2]=$highus[$i][1];
               $lowus[$b][2]=$lowus[$i][1];
               $closeus[$b][2]=$closeus[$i][1];
               $openus[$b][2]=$openus[$i][1];
               }

               $AverageCandelMove=$AverageCandelMove+abs($highus[$i][2]-$lowus[$i][2]);
               if($highus[$i][2]>$charthigh)$charthigh=$highus[$i][2];
               if($lowus[$i][2]<$chartlow || $chartlow<=0)$chartlow=$lowus[$i][2];
      
               $b++;
               continue;
             }
           }
       }
     }else exit();










$ExchangeName="Binance";
include('IncludeFile.php');





}
}












    if($SymbolDownloaden!="BTCUSDT" || $SymbolDownloaden!="USDT_BTC")
    {
    $filenameus="Textdateien_Charts_USD/Binance_USDChart_".$SymbolDownloaden.'_'.$timeframe.".txt";
    $myfileus = fopen($filenameus, "w");
    $str = '{ "Chart":[ ';
    fwrite($myfileus, $str);
    $a=0;
    for($i=0; $i<count($dateus); $i++)
       {
        if($dateus[$i][2]>0)
          {
            $date=$dateus[$i][2];
            $open=$openus[$i][2];
            $high=$highus[$i][2];
            $low=$lowus[$i][2];
            $close=$closeus[$i][2];
                    
            //--Textdatei erstellen code
            if($a==0)$str = '  { "timeframe":"'.$timeframe.'", "date":"'.$date.'", "open":"'.$open.'", "high":"'.$high.'", "low":"'.$low.'", "close":"'.$close.'"  }'."\r\n"; 
            else     $str = ', { "timeframe":"'.$timeframe.'", "date":"'.$date.'", "open":"'.$open.'", "high":"'.$high.'", "low":"'.$low.'", "close":"'.$close.'"  }'."\r\n"; 
            fwrite($myfileus, $str);
            $a++;
           }
       }
  $str =  ' ] }';
  fwrite($myfileus, $str);
  fclose($myfileus);
  }

usleep(1000000);

 }
}


?>