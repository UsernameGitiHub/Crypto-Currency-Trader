<?php 



   $filename2="SelectdChart.txt";

   //--
   $coin=$_GET['coin'];
   if(isset($_GET['coin']) && $_GET['coin']!="leer")
     {
      if($_GET['name']=="Bitcoin")
        {
          if($_GET['broker']=="Poloniex")$coin="USDT_BTC";
          else
          if($_GET['broker']=="Binance")$coin="BTCUSDT";
          else
          if($_GET['broker']=="Huobi")$coin="BTCUSDT";
          else
          if($_GET['broker']=="HitBTC")$coin="BTCUSD";
          else
          if($_GET['broker']=="Okex")$coin="BTC_USDT";
        }
       else
       {
       if(strpos($_GET['coin'],"BTC",0)==false && $_GET['name']!="Bitcoin")
       {
         if(isset($_GET['broker']))
           {
             if($_GET['broker']=="Binance")$coin=$_GET['coin']."BTC";
           }
       }
       }//else 
     }//isset get coin


   //--
   $timeframe="D1";
   if(isset($_GET['timeframe']))$timeframe=$_GET['timeframe'];
   //--
   $broker="Binance";
   if(isset($_GET['broker']))$broker=$_GET['broker'];
   //--
   $name="Bitcoin";
   if(isset($_GET['name']))$name=$_GET['name']; 
   //--
   $cmcid="";
   if(isset($_GET['cmcid']))$cmcid=$_GET['cmcid'];  

   if($coin=="leer")
   {
   $page = file_get_contents($filename2);
   $page = json_decode($page,true);
   $coin = $page["Selection"][0]["coin"];
   if(isset($_GET['timeframe'])==false)$timeframe = $page["Selection"][0]["timeframe"];
   $broker = $page["Selection"][0]["broker"];
   $name = $page["Selection"][0]["name"];
   $cmcid = $page["Selection"][0]["idcmc"];
   }


	function curl_get_file_contents($URL)
    {
        $c = curl_init();
        curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($c, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($c, CURLOPT_URL, $URL);
        $contents = curl_exec($c);
        curl_close($c);

        if ($contents) return $contents;
        else return FALSE;
    }


   $name2 = $file=str_replace(" ","-",$name);
   $url = "https://api.coinmarketcap.com/v1/ticker/".$cmcid."/";
   $page = curl_get_file_contents($url);
   $page = json_decode($page,true);
   $cap = 0;
   $change = 0;
   $price = 0;
   $cap = number_format($page[0]["market_cap_usd"]);
   $change = $page[0]["percent_change_7d"];
   $price = $page[0]["price_usd"];
   $pricebtc = $page[0]["price_btc"];
   $symbolcmc = $page[0]["symbol"];
   $idcmc = $page[0]["id"];



   
   $myfile2 = fopen($filename2, "w");
   $str = '{ "Selection":[ ';
   fwrite($myfile2, $str);
 
   $str = '{  "coin":"'.$coin.'", "symbol":"'.$symbolcmc.'", "idcmc":"'.$idcmc.'" , "timeframe":"'.$timeframe.'", "broker":"'.$broker.'", "name":"'.$name.'", "cap":"'.$cap.'", "change":"'.$change.'", "price":"'.$price.'", "pricebtc":"'.$pricebtc.'"  }'; 
   fwrite($myfile2, $str);

   $str =  ' ] }';
   fwrite($myfile2, $str);
   fclose($myfile2);
?>