<?php

		$url2="http://".$_SERVER['SERVER_NAME'].''.$_SERVER['SCRIPT_NAME'];
		$fnm="ReadTextFile.php?file=LastExchange.txt";
		$url=str_replace("Showexchanges.php",$fnm,$url2);
		$LastClicked=file_get_contents($url);
		echo "|| lastbroker ".$LastClicked."  Coin ".$_GET['symbol']."   ".$_GET['v2']."  || ";
		
		$page = file_get_contents("Apis.txt");
		$page = json_decode($page,true);
		$BrokerMitArbitrageAPIKey=array();
		$Ibrokers=0;
		
		for($i=0; $i<count($page["Api"]); $i++)
		{
			if($page["Api"][$i]["tradingkey"]!="" && $page["Api"][$i]["tradingsec"]!="")
			{
				$BrokerMitArbitrageAPIKey[$Ibrokers] = $page["Api"][$i]["exchange"];
				$Ibrokers++;
			}
		}
		//--
		$outp="";
		$outp2="";
		$BrokerFound=0;
		$BrokerFound2=0;
		$AnzahlBrokerHaveTheCoin=0;
		$StringSucheAnzahl="";
		$Broker2="";
	    //--
		for ($i=0; $i<count($BrokerMitArbitrageAPIKey); $i++) 
			{
				$Textfile1="";
				if($BrokerMitArbitrageAPIKey[$i]=="Poloniex")$Textfile1="allcoins_poloniex.txt";
				else
				if($BrokerMitArbitrageAPIKey[$i]=="Binance")$Textfile1="allcoins_binance.txt";
				else
				if($BrokerMitArbitrageAPIKey[$i]=="Bittrex")$Textfile1="allcoins_bittrex.txt";
				else
				if($BrokerMitArbitrageAPIKey[$i]=="HitBTC")$Textfile1="allcoins_hitbtc.txt";
				//--
				$url2="http://".$_SERVER['SERVER_NAME'].''.$_SERVER['SCRIPT_NAME'];
				$fnm=$Textfile1;
				$url=str_replace("Showexchanges.php",$fnm,$url2);
				$AllcoinsInhalt = json_decode(file_get_contents($url),true);
				
				//--
				$symbol=$_GET['symbol'];
				$v1=$_GET['v1'];
				//--
				for($i2=0; $i2<count($AllcoinsInhalt["Coins"]); $i2++)
				   {
					 if(str_replace(" ","",$AllcoinsInhalt["Coins"][$i2]["name"])==str_replace(" ","",$symbol))
					   { 
						  if($StringSucheAnzahl!=$BrokerMitArbitrageAPIKey[$i])
						  {echo $BrokerMitArbitrageAPIKey[$i]."=<br>";
							$AnzahlBrokerHaveTheCoin++;
							$StringSucheAnzahl=$BrokerMitArbitrageAPIKey[$i];
							  
											
							  if($v1=="leer")
							  {
								$outp .= "<label class='container'>".$BrokerMitArbitrageAPIKey[$i];
								if($LastClicked==$BrokerMitArbitrageAPIKey[$i])
								  {
									  $BrokerFound=1; 
									  $outp .= "<input class=\"inputcheckbroker\" id=\"trbrok".$i."\" onclick=\"TradingCheckboxes('trbrok".$i."', 'LastExchange.txt', '".$BrokerMitArbitrageAPIKey[$i]."', this.id)\" value=\"".$BrokerMitArbitrageAPIKey[$i]."\" type=\"checkbox\" checked=\"checked\">";
								  }
								else  
								  {                                                         
									  $outp .= "<input class=\"inputcheckbroker\" id=\"trbrok".$i."\" onclick=\"TradingCheckboxes('trbrok".$i."', 'LastExchange.txt', '".$BrokerMitArbitrageAPIKey[$i]."', this.id)\" value=\"".$BrokerMitArbitrageAPIKey[$i]."\" type=\"checkbox\">";
								  }
								$outp .= "<span class='checkmark'></span>";
								$outp .= "</label>";
							  }
							  
                              							  
							  //--outp2 wird benutzt um ein voreingestellten broker zu zeigen falls der letzte ausgewaehlte brokern nicht den coin hat der gerade im kauffeld steht
							  $outp2 .= "<label class='container'>".$BrokerMitArbitrageAPIKey[$i];
							  if($BrokerFound2==0 && $v1!="arbitrage")
							     {
									 $BrokerFound2=1;
									 $outp2 .= "<input class=\"inputcheckbroker\" id=\"trbrok".$i."\" onclick=\"TradingCheckboxes('trbrok".$i."', 'LastExchange.txt', '".$BrokerMitArbitrageAPIKey[$i]."', this.id)\" value=\"".$BrokerMitArbitrageAPIKey[$i]."\" type=\"checkbox\" checked=\"checked\">";
                                     $Broker2 = $BrokerMitArbitrageAPIKey[$i];
								 }
							  else 
							  if($v1!="arbitrage")
							    {                                   
							         $outp2 .= "<input class=\"inputcheckbroker\" id=\"trbrok".$i."\" onclick=\"TradingCheckboxes('trbrok".$i."', 'LastExchange.txt', '".$BrokerMitArbitrageAPIKey[$i]."', this.id)\" value=\"".$BrokerMitArbitrageAPIKey[$i]."\" type=\"checkbox\">";
								}
							  else   //if arbitrage tab
							   {
								     $outp2 .= "<input class='inputcheckbroker' id='trbrok".$i."' onclick=\"TradingCheckboxes2(this.id)\" value='".$BrokerMitArbitrageAPIKey[$i]."'  type='checkbox' checked='checked'>";
							   }
							  $outp2 .= "<span class='checkmark'></span>";
							  $outp2 .= "</label>";
						  }
					   }
				   }
		
			}
			if($BrokerFound==0 && $Broker2!=""){$filename="LastExchange.txt";$myfile = fopen($filename, "w");fwrite($myfile, $Broker2);fclose($myfile);}
			echo "<anzahl>".$AnzahlBrokerHaveTheCoin."</anzahl><output1>".$outp."</output1><output2>".$outp2."</output2><find1>".$BrokerFound."</find1><find2>".$BrokerFound2."</find2><lastbroker>".$LastClicked."</lastbroker>";

?>