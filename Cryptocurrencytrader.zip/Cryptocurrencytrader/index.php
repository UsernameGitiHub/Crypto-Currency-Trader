<!DOCTYPE html>
<html>
<head>
<title>Crypto Currency Trader</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" href="favicon.ico" type="image/x-icon">
<link rel="stylesheet" href="styles.css?a=<?php echo time();?>">
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript" src="https://www.google.com/jsapi"></script>
<script type="text/javascript">
//--Zaehler fuer setTimeout
var SetTimeoutZaehler1=0;
var FuenfSekundenZaehler=0;
var FuenfZehnSekundenZaehler=0;
var DreisichSekundenZaehler=0;
var PlayPause=0;
var SignalsCount=0;
var AktuelleSignale;
var SignaleObject = new Object();
var BrokerTabClick=0;
var BrokerIDClickedShowBalanceOrders="";

function Wiederholungen()
{
	if(FuenfSekundenZaehler==0)
	{
	  DoTrades();
	}
	FuenfSekundenZaehler++;if(FuenfSekundenZaehler>5)FuenfSekundenZaehler=0;
	
	
	
	if(FuenfZehnSekundenZaehler==0)
	{
	  DownloadCoins();
	  TradingAccounts();
	  if(PlayPause==1)PlaySignals();
	}
	FuenfZehnSekundenZaehler++;if(FuenfZehnSekundenZaehler>15)FuenfZehnSekundenZaehler=0;



	if(DreisichSekundenZaehler==0)
	{
	  drawVisualization();
	}
	DreisichSekundenZaehler++;if(DreisichSekundenZaehler>30)DreisichSekundenZaehler=0;
	
	

	if(SetTimeoutZaehler1==0)
	{
	  SignaleDateiNeuErstellen();
	  PrintSignale();
	}
	SetTimeoutZaehler1++;if(SetTimeoutZaehler1>60)SetTimeoutZaehler1=0;
	//--
	setTimeout(Wiederholungen, 1000);
	//--
}





//+-------------------------------------------------------------------+
//| Coins downloaden                                                  |
//+-------------------------------------------------------------------+
var Downloadliste_Coins_Object = new Object();
var Zaehler=0;
var ZaehlerCoinsIndex=0;

function DownloadCoins()
{
	var strurl="";
    var str="";
    var res="";
	
    //--Coins in Array Object
	if(Zaehler==0)
	{	
		//--Updates PHP Datei aufrufen
		strurl="Updates.php"; var updateshttp = new XMLHttpRequest();updateshttp.onreadystatechange = function() {if (this.readyState == 4 && this.status == 200) {console.log(this.responseText);}};updateshttp.open("GET", strurl, true);updateshttp.send();
		
		
		//-- Coinnamen into Array
		strurl="Downloadliste_CoinsToken.txt";
		var coinshttp = new XMLHttpRequest();
		coinshttp.onreadystatechange = function() 
		{
		    if (this.readyState == 4 && this.status == 200) 
			{
				res=this.responseText;
				if(isJson(res)==true)
				{
					Downloadliste_Coins_Object = JSON.parse(res);
				}//json Check
				else alert("Download Liste json synatx error");
			}
		};     
		coinshttp.open("GET", strurl, true);
		coinshttp.send();
	}

	//--Bitcoins Charts fuer Broker erneuern
    else if(Zaehler==1)
	{	
		//--Binance Bitcoin
	    strurl="Save_Chartdata_Binance.php?symbol=BTCUSDT&name=Bitcoin"; var bitcoinhttpb = new XMLHttpRequest();bitcoinhttpb.onreadystatechange = function() {if (this.readyState == 4 && this.status == 200) {}};bitcoinhttpb.open("GET", strurl, true);bitcoinhttpb.send();
	}
	//-- USD Charts fuer Coins
    else if(Zaehler>1)
	{
		var AnzahlCoins=Downloadliste_Coins_Object.Coins.length;
	    str=Object.keys(Downloadliste_Coins_Object);
		if(str.indexOf("Coins")>=0)
		{
			if(Downloadliste_Coins_Object.Coins[ZaehlerCoinsIndex].broker=="Binance")
			{
		      strurl="Save_Chartdata_Binance.php?symbol="+Downloadliste_Coins_Object.Coins[ZaehlerCoinsIndex].symbol+"BTC&name="+Downloadliste_Coins_Object.Coins[ZaehlerCoinsIndex].name+"&cmcid="+Downloadliste_Coins_Object.Coins[ZaehlerCoinsIndex].cmcid;
		      var bitcoinhttph3 = new XMLHttpRequest();bitcoinhttph3.onreadystatechange = function() {if (this.readyState == 4 && this.status == 200) {}};bitcoinhttph3.open("GET", strurl, true);bitcoinhttph3.send();
			}
			
			//--Zaehler Array Index
			ZaehlerCoinsIndex++;
			
			//--Zaehler zurueck setzen
			if(ZaehlerCoinsIndex>=AnzahlCoins)
			{
				Zaehler=0;
				ZaehlerCoinsIndex=0;
			}
		}
    }
	Zaehler++;
}





//+-------------------------------------------------------------------+
//| Funktion zum aufrufen der PHP Datei welche nach Tradeauftraegen   |
//| schaut in der Mysql Datenbank.                                    |
//+-------------------------------------------------------------------+

var TimeoutDoTrades=0;
function DoTrades()
{
  var xhttptr = new XMLHttpRequest();
  xhttptr.onreadystatechange = function() 
  {
     if (this.readyState == 4 && this.status == 200) 
        {
        }
  };     
  xhttptr.open("GET", "ExchangesApis.php?TraderequestDo=1", true);
  xhttptr.send();
  console.log("DoTraes");	
}




//-- google chart code
google.load('visualization', '1', {'packages':['corechart']});


//--check json syntax
function isJson(item) 
{
    item = typeof item !== "string"
        ? JSON.stringify(item)
        : item;

    try {
        item = JSON.parse(item);
    } catch (e) {
        return false;
    }

    if (typeof item === "object" && item !== null) {
        return true;
    }

    return false;
}



//--
function clearThis(target)
{
  target.value= "";
}

function putThis(target, v1, cmcid)
{
    target.value= v1;
    document.getElementById("serachoutput2").innerHTML = "";
		
		
			var Symbol=v1;
			var n = Symbol.indexOf(" (")-2;
			Symbol = Symbol.substring(0, n);
			
			var Symbol2=v1;
			var n = Symbol2.indexOf(" (")+2;
			var n2 = Symbol2.indexOf(")");
			Symbol2 = Symbol2.substring(n, n2);
			
			var strurl = "https://api.coinmarketcap.com/v1/ticker/"+cmcid+"/";
			var xhttpa = new XMLHttpRequest();
			xhttpa.onreadystatechange = function() 
			{
			if(this.readyState == 4 && this.status == 200) 
		    {
			var RueckgabeReadFile=this.responseText;

				if(isJson(RueckgabeReadFile)==true)
				{
				 var CoinnamenObject = JSON.parse(RueckgabeReadFile);
				 document.getElementById("usdlimitprice").placeholder = "USD Price..("+CoinnamenObject[0]["price_usd"]+")";
				 document.getElementById("btclimitprice").placeholder = "BTC Price..("+CoinnamenObject[0]["price_btc"]+")";	 
				 document.getElementById("usdamount").placeholder = "USD Value..("+CoinnamenObject[0]["price_usd"]+")";
				 document.getElementById("btcamount").placeholder = "BTC Value..("+CoinnamenObject[0]["price_btc"]+")";
				 document.getElementById("coinamount").placeholder = Symbol2+" Value..(1 = "+CoinnamenObject[0]["price_usd"]+" USD)";
				 document.getElementById("btcpricehidden").innerHTML = CoinnamenObject[0]["price_btc"];
				 document.getElementById("usdpricehidden").innerHTML = CoinnamenObject[0]["price_usd"];
				 
				 //--TP Preise Placeholder
				 var tpprice=(CoinnamenObject[0]["price_usd"]/100)*5;
				 tpprice=parseFloat(CoinnamenObject[0]["price_usd"])+parseFloat(tpprice);
				 tpprice=Math.round(tpprice * 100) / 100;
				 var tpbtcprice=(CoinnamenObject[0]["price_btc"]/100)*5;
				 tpbtcprice=parseFloat(CoinnamenObject[0]["price_btc"])+parseFloat(tpbtcprice);
				 tpbtcprice=Math.round(tpbtcprice * 10000000) / 10000000;
				 
				 document.getElementById("tpusdprice").placeholder = "USD if price go up to ..("+tpprice+")";
				 document.getElementById("tpusdvalue").placeholder = "If value go up to..USD";	 
				 document.getElementById("tpbtcprice").placeholder = "BTC if price..("+tpbtcprice+")";
				 
				 //--SL Preise Placeholder
				 var slprice=(CoinnamenObject[0]["price_usd"]/100)*5;
				 slprice=parseFloat(CoinnamenObject[0]["price_usd"])-parseFloat(slprice);
				 slprice=Math.round(slprice * 100) / 100;
				 var slbtcprice=(CoinnamenObject[0]["price_btc"]/100)*5;
				 slbtcprice=parseFloat(CoinnamenObject[0]["price_btc"])-parseFloat(slbtcprice);
				 slbtcprice=Math.round(slbtcprice * 10000000) / 10000000;
				 
				 document.getElementById("slusdprice").placeholder = "USD if price go down to ..("+slprice+")";
				 document.getElementById("slusdvalue").placeholder = "If value go down to..USD";	 
				 document.getElementById("slbtcprice").placeholder = "BTC if price..("+slbtcprice+")";
				 
				 //--Signal Auswahl
				 document.getElementById("usdamountsg").placeholder = "USD Value..("+CoinnamenObject[0]["price_usd"]+")";
				 document.getElementById("btcamountsg").placeholder = "BTC Value..("+CoinnamenObject[0]["price_btc"]+")";
				 document.getElementById("coinamountsg").placeholder = Symbol2+" Value..(1 = "+CoinnamenObject[0]["price_usd"]+" USD)";
				 //--
				 document.getElementById("tpusdpricesg").placeholder = "USD if price go up tp ..("+tpprice+")";
				 document.getElementById("tpusdvaluesg").placeholder = "If value go up to..USD";	 
				 document.getElementById("tpbtcpricesg").placeholder = "BTC if price..("+tpbtcprice+")";
				 document.getElementById("slusdpricesg").placeholder = "USD if price go down to ..("+slprice+")";
				 document.getElementById("slusdvaluesg").placeholder = "If value go down to..USD";	 
				 document.getElementById("slbtcpricesg").placeholder = "BTC if price..("+slbtcprice+")";
				 
				 
				 //--Buy And Hold Auswahl
				 document.getElementById("usdamountbh").placeholder = "USD Value..("+CoinnamenObject[0]["price_usd"]+")";
				 document.getElementById("btcamountbh").placeholder = "BTC Value..("+CoinnamenObject[0]["price_btc"]+")";
				 document.getElementById("coinamountbh").placeholder = Symbol2+" Value..(1 = "+CoinnamenObject[0]["price_usd"]+" USD)";
				 //--
				 document.getElementById("tpusdpricebh").placeholder = "USD if price go up to ..("+tpprice+")";
				 document.getElementById("tpusdvaluebh").placeholder = "If value go up to..USD";	 
				 document.getElementById("tpbtcpricebh").placeholder = "BTC if price..("+tpbtcprice+")";
				 document.getElementById("slusdpricebh").placeholder = "USD if price go down to ..("+slprice+")";
				 document.getElementById("slusdvaluebh").placeholder = "If value go down to..USD";	 
				 document.getElementById("slbtcpricebh").placeholder = "BTC if price..("+slbtcprice+")";
				 
				 //--
				}
			}
			};
			xhttpa.open("GET", "ReadHTTPFile.php?file="+strurl, true);
			xhttpa.send();

	//--
	CoinNamenAufButtons();
	
	ShowExchanges(Symbol, "leer","abc"); 
	
	
	if(document.getElementById("SignalButton").className == "tablinks active"){ReadTraderequests('Signal', Symbol);}
	if(document.getElementById("BuyHoldButton").className == "tablinks active"){ReadTraderequests('Buyandhold', Symbol);}
}

	
	
function TradePanelCoinChange()
{
	var Symbol = v1;
	var n = Symbol.indexOf(" (")-2;
	Symbol = Symbol.substring(0, n);
			
	ShowExchanges(Symbol, "leer","abc");
}



//--
function ShowSearchResults()
{
    var input, filter, flenght, i;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    flenght=filter.length;

    var xhttpshws = new XMLHttpRequest();
    xhttpshws.onreadystatechange = function() 
    {
    if (this.readyState == 4 && this.status == 200) 
    {
	var CoinnamenTextinhalt=this.responseText;
	
    if(isJson(CoinnamenTextinhalt)==true)
    {
		var CoinnamenObject = JSON.parse(CoinnamenTextinhalt);
		var AktuelleCoins=CoinnamenObject.Coins.length;
		var anzahl=0;
		var str="";
		var res="";
		var outp="";
		var anzahl2=0;
		for (i=0; i<AktuelleCoins; i++) {
			str = CoinnamenObject.Coins[i].symbol;
			res = str.toUpperCase();
			if(res.substring(0, flenght)==filter && flenght>0) 
			  {
			   anzahl2++;
			   if(anzahl2>5)break;
			  }
		}//for
		for (i=0; i<AktuelleCoins; i++) {
			str = CoinnamenObject.Coins[i].symbol;
			res = str.toUpperCase();
			
			if(res.substring(0, flenght)==filter && flenght>0) 
			  {
			   if(anzahl2==1 && anzahl==0)
			   {
			   outp += "<span class=\"searchresult borderradius3\" onclick=\"writeToFile('"+CoinnamenObject.Coins[i].symbol+"','D1','"+CoinnamenObject.Coins[i].broker+"','"+CoinnamenObject.Coins[i].name+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   }
			   
			   if(anzahl2==2)
			   {
			   if(anzahl==0) outp += "<span class=\"searchresult borderradius\" onclick=\"writeToFile('"+CoinnamenObject.Coins[i].symbol+"','D1','"+CoinnamenObject.Coins[i].broker+"','"+CoinnamenObject.Coins[i].name+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==1) outp += "<span class=\"searchresult borderradius2\" onclick=\"writeToFile('"+CoinnamenObject.Coins[i].symbol+"','D1','"+CoinnamenObject.Coins[i].broker+"','"+CoinnamenObject.Coins[i].name+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   }
			   
			   if(anzahl2==3)
			   {
			   if(anzahl==0) outp += "<span class=\"searchresult borderradius\" onclick=\"writeToFile('"+CoinnamenObject.Coins[i].symbol+"','D1','"+CoinnamenObject.Coins[i].broker+"','"+CoinnamenObject.Coins[i].name+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==1) outp += "<span class=\"searchresult\" onclick=\"writeToFile('"+CoinnamenObject.Coins[i].symbol+"','D1','"+CoinnamenObject.Coins[i].broker+"','"+CoinnamenObject.Coins[i].name+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==2) outp += "<span class=\"searchresult borderradius2\" onclick=\"writeToFile('"+CoinnamenObject.Coins[i].symbol+"','D1','"+CoinnamenObject.Coins[i].broker+"','"+CoinnamenObject.Coins[i].name+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   }
			   
			   if(anzahl2==4)
			   {
			   if(anzahl==0) outp += "<span class=\"searchresult borderradius\" onclick=\"writeToFile('"+CoinnamenObject.Coins[i].symbol+"','D1','"+CoinnamenObject.Coins[i].broker+"','"+CoinnamenObject.Coins[i].name+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==1) outp += "<span class=\"searchresult\" onclick=\"writeToFile('"+CoinnamenObject.Coins[i].symbol+"','D1','"+CoinnamenObject.Coins[i].broker+"','"+CoinnamenObject.Coins[i].name+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==2) outp += "<span class=\"searchresult\" onclick=\"writeToFile('"+CoinnamenObject.Coins[i].symbol+"','D1','"+CoinnamenObject.Coins[i].broker+"','"+CoinnamenObject.Coins[i].name+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==3) outp += "<span class=\"searchresult borderradius2\" onclick=\"writeToFile('"+CoinnamenObject.Coins[i].symbol+"','D1','"+CoinnamenObject.Coins[i].broker+"','"+CoinnamenObject.Coins[i].name+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   }
			   
			   if(anzahl2==5)
			   {
			   if(anzahl==0) outp += "<span class=\"searchresult borderradius\" onclick=\"writeToFile('"+CoinnamenObject.Coins[i].symbol+"','D1','"+CoinnamenObject.Coins[i].broker+"','"+CoinnamenObject.Coins[i].name+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==1) outp += "<span class=\"searchresult\" onclick=\"writeToFile('"+CoinnamenObject.Coins[i].symbol+"','D1','"+CoinnamenObject.Coins[i].broker+"','"+CoinnamenObject.Coins[i].name+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==2) outp += "<span class=\"searchresult\" onclick=\"writeToFile('"+CoinnamenObject.Coins[i].symbol+"','D1','"+CoinnamenObject.Coins[i].broker+"','"+CoinnamenObject.Coins[i].name+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==3) outp += "<span class=\"searchresult\" onclick=\"writeToFile('"+CoinnamenObject.Coins[i].symbol+"','D1','"+CoinnamenObject.Coins[i].broker+"','"+CoinnamenObject.Coins[i].name+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==4) outp += "<span class=\"searchresult borderradius2\" onclick=\"writeToFile('"+CoinnamenObject.Coins[i].symbol+"','D1','"+CoinnamenObject.Coins[i].broker+"','"+CoinnamenObject.Coins[i].name+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   }
			   
			   if(anzahl2==6)
			   {
			   if(anzahl==0) outp += "<span class=\"searchresult borderradius\" onclick=\"writeToFile('"+CoinnamenObject.Coins[i].symbol+"','D1','"+CoinnamenObject.Coins[i].broker+"','"+CoinnamenObject.Coins[i].name+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==1) outp += "<span class=\"searchresult\" onclick=\"writeToFile('"+CoinnamenObject.Coins[i].symbol+"','D1','"+CoinnamenObject.Coins[i].broker+"','"+CoinnamenObject.Coins[i].name+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==2) outp += "<span class=\"searchresult\" onclick=\"writeToFile('"+CoinnamenObject.Coins[i].symbol+"','D1','"+CoinnamenObject.Coins[i].broker+"','"+CoinnamenObject.Coins[i].name+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==3) outp += "<span class=\"searchresult\" onclick=\"writeToFile('"+CoinnamenObject.Coins[i].symbol+"','D1','"+CoinnamenObject.Coins[i].broker+"','"+CoinnamenObject.Coins[i].name+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==4) outp += "<span class=\"searchresult\" onclick=\"writeToFile('"+CoinnamenObject.Coins[i].symbol+"','D1','"+CoinnamenObject.Coins[i].broker+"','"+CoinnamenObject.Coins[i].name+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==5) outp += "<span class=\"searchresult borderradius2\" onclick=\"writeToFile('"+CoinnamenObject.Coins[i].symbol+"','D1','"+CoinnamenObject.Coins[i].broker+"','"+CoinnamenObject.Coins[i].name+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   }
			   anzahl++;
			   if(anzahl>5)break;
			  }
		}
	   document.getElementById("serachoutput").innerHTML = outp;
    }//json check
    else alert("Searchfield Hauptmenue json syntax error");
	}
    };
    xhttpshws.open("GET", "Downloadliste_CoinsToken.txt", true);
    xhttpshws.send();
}










//--
function ShowSearchResults2() 
{
    var handelspaar="";
    var input, filter, flenght, i;
    input = document.getElementById("myInput2");
    filter = input.value.toUpperCase();
    flenght=filter.length;

    var xhttpsh2 = new XMLHttpRequest();
    xhttpsh2.onreadystatechange = function() 
    {
    if(this.readyState == 4 && this.status == 200) 
    {
		var CoinnamenTextinhalt = this.responseText;
		if(isJson(CoinnamenTextinhalt)==true)
		{
		var CoinnamenObject = JSON.parse(CoinnamenTextinhalt);
		var AktuelleCoins=CoinnamenObject.Coins.length;
		var anzahl=0;
		var str="";
		var res="";
		var outp="";
		var anzahl2=0;
		for (i=0; i<AktuelleCoins; i++) {
			str = CoinnamenObject.Coins[i].symbol;
			res = str.toUpperCase();
			if(res.substring(0, flenght)==filter && flenght>0) 
			  {
			   anzahl2++;
			   if(anzahl2>5)break;
			  }
		}//for
		for (i=0; i<AktuelleCoins; i++) {
			str = CoinnamenObject.Coins[i].symbol;
			res = str.toUpperCase();
			
			if(res.substring(0, flenght)==filter && flenght>0) 
			  {
			   if(anzahl2==1 && anzahl==0)
			   {
			   handelspaar=CoinnamenObject.Coins[i].name+"   ("+CoinnamenObject.Coins[i].symbol+")";
			   outp += "<span class=\"searchresult2 borderradius3\" onclick=\"putThis(document.getElementById(\'myInput2\'),'"+handelspaar+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   }
			   
			   if(anzahl2==2)
			   {
			   handelspaar=CoinnamenObject.Coins[i].name+"   ("+CoinnamenObject.Coins[i].symbol+")";
			   if(anzahl==0) outp += "<span class=\"searchresult2 borderradius\" onclick=\"putThis(document.getElementById(\'myInput2\'),'"+handelspaar+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==1) outp += "<span class=\"searchresult2 borderradius2\" onclick=\"putThis(document.getElementById(\'myInput2\'),'"+handelspaar+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   }
			   
			   if(anzahl2==3)
			   {
			   handelspaar=CoinnamenObject.Coins[i].name+"   ("+CoinnamenObject.Coins[i].symbol+")";
			   if(anzahl==0) outp += "<span class=\"searchresult2 borderradius\" onclick=\"putThis(document.getElementById(\'myInput2\'),'"+handelspaar+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==1) outp += "<span class=\"searchresult2\" onclick=\"putThis(document.getElementById(\'myInput2\'),'"+handelspaar+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==2) outp += "<span class=\"searchresult2 borderradius2\" onclick=\"putThis(document.getElementById(\'myInput2\'),'"+handelspaar+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   }
			   
			   if(anzahl2==4)
			   {
			   handelspaar=CoinnamenObject.Coins[i].name+"   ("+CoinnamenObject.Coins[i].symbol+")";
			   if(anzahl==0) outp += "<span class=\"searchresult2 borderradius\" onclick=\"putThis(document.getElementById(\'myInput2\'),'"+handelspaar+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==1) outp += "<span class=\"searchresult2\" onclick=\"putThis(document.getElementById(\'myInput2\'),'"+handelspaar+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==2) outp += "<span class=\"searchresult2\" onclick=\"putThis(document.getElementById(\'myInput2\'),'"+handelspaar+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==3) outp += "<span class=\"searchresult2 borderradius2\" onclick=\"putThis(document.getElementById(\'myInput2\'),'"+handelspaar+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   }
			   
			   if(anzahl2==5)
			   {
			   handelspaar=CoinnamenObject.Coins[i].name+"   ("+CoinnamenObject.Coins[i].symbol+")";
			   if(anzahl==0) outp += "<span class=\"searchresult2 borderradius\" onclick=\"putThis(document.getElementById(\'myInput2\'),'"+handelspaar+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==1) outp += "<span class=\"searchresult2\" onclick=\"putThis(document.getElementById(\'myInput2\'),'"+handelspaar+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==2) outp += "<span class=\"searchresult2\" onclick=\"putThis(document.getElementById(\'myInput2\'),'"+handelspaar+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==3) outp += "<span class=\"searchresult2\" onclick=\"putThis(document.getElementById(\'myInput2\'),'"+handelspaar+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==4) outp += "<span class=\"searchresult2 borderradius2\" onclick=\"putThis(document.getElementById(\'myInput2\'),'"+handelspaar+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   }
			   
			   if(anzahl2==6)
			   {
			   handelspaar=CoinnamenObject.Coins[i].name+"   ("+CoinnamenObject.Coins[i].symbol+")";
			   if(anzahl==0) outp += "<span class=\"searchresult2 borderradius\" onclick=\"putThis(document.getElementById(\'myInput2\'),'"+handelspaar+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==1) outp += "<span class=\"searchresult2\" onclick=\"putThis(document.getElementById(\'myInput2\'),'"+handelspaar+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==2) outp += "<span class=\"searchresult2\" onclick=\"putThis(document.getElementById(\'myInput2\'),'"+handelspaar+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==3) outp += "<span class=\"searchresult2\" onclick=\"putThis(document.getElementById(\'myInput2\'),'"+handelspaar+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==4) outp += "<span class=\"searchresult2\" onclick=\"putThis(document.getElementById(\'myInput2\'),'"+handelspaar+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   if(anzahl==5) outp += "<span class=\"searchresult2 borderradius2\" onclick=\"putThis(document.getElementById(\'myInput2\'),'"+handelspaar+"','"+CoinnamenObject.Coins[i].cmcid+"')\">"+CoinnamenObject.Coins[i].name+" ("+str+")</span>";
			   }
			   anzahl++;
			   if(anzahl>5)break;
			  }
		}//for
	   document.getElementById("serachoutput2").innerHTML = outp;
	   }//json check
	   else alert("Searchfield tradepanel json syntax error");
   }
   };
   xhttpsh2.open("GET", "Downloadliste_CoinsToken.txt", true);
   xhttpsh2.send();
}









function writeToFile(v1="leer", v2="D1", v3="leer", v4="leer", cmcid="leer", vsg="leer")
{
	  //--Loading Anzeige zeigen
	  if(vsg!="signalplay")document.getElementById("loader").style.display = "block";
				
      var url = "WriteData.php?coin="+v1+"&timeframe="+v2+"&broker="+v3+"&name="+v4+"&cmcid="+cmcid;
      var xhttp2 = new XMLHttpRequest();
      xhttp2.onreadystatechange = function() 
      {
          if (this.readyState == 4 && this.status == 200) 
             {
               console.log("WriteToFile= "+vsg+"   "+this.responseText); 
               if(vsg=="leer")
			   {
				   clearThis(document.getElementById("myInput")); 
                   document.getElementById("serachoutput").innerHTML = ""; 
			   }
               drawVisualization(); 
             }
      };
      xhttp2.open("GET", url, true);
      xhttp2.send();
}






Number.prototype.formatMoney = function(c, d, t){
var n = this, 
    c = isNaN(c = Math.abs(c)) ? 2 : c, 
    d = d == undefined ? "." : d, 
    t = t == undefined ? "." : t, 
    s = n < 0 ? "-" : "", 
    i = String(parseInt(n = Math.abs(Number(n) || 0).toFixed(c))), 
    j = (j = i.length) > 3 ? j % 3 : 0;
   return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
 };

 
 
 
 
 
 
 
 
 
 
//+---------------------------------------------------------+
//| Draw Chart                                              |
//+---------------------------------------------------------+

var filestr="";
var Setting = new Object();
var Coin="";
var Timeframe="";
var Broker="";
var Name="";

var xhttp1 = new XMLHttpRequest();

//--
var options = { 
    legend: 'none',
    bar: { groupWidth: '80%' },
    selectionMode: 'multiple',
    tooltip: {trigger: 'selection'},
    aggregationTarget: 'category',
    backgroundColor: 'white',
    'chartArea': {'width': '90%', height:'100%', right:15, top:10, bottom:33},
    candlestick: {
        fallingColor: { strokeWidth: 0, fill: '#a52714' }, // red
        risingColor: { strokeWidth: 0, fill: '#0f9d58' }   // green
     }
     };




var chart=0;
var ChartStart=0;
var TimeoutPlaySignal=0;
function drawVisualization() 
{

	
  var start=0;
	  
  xhttp1.onreadystatechange = function() 
  {
   if (this.readyState == 4 && this.status == 200)
      {
         filestr=this.responseText;
         if(isJson(filestr)==true)
         {
			
            Setting = JSON.parse(filestr);
            Coin=Setting.Selection[0].coin;
            Timeframe=Setting.Selection[0].timeframe;
            Broker=Setting.Selection[0].broker;
            Name=Setting.Selection[0].name;
            start=1;
			

			if(start==1)
			{
				
                var fileurl = "getData.php?symbol="+Coin+"&timeframe="+Timeframe+"&broker="+Broker; 

				var httpchart = new XMLHttpRequest();
				httpchart.onreadystatechange = function() 
				{
				if(this.readyState == 4 && this.status == 200) 
				{
				 //--
				 document.getElementById("loader").style.display = "none";
				 
		         var jsonData=this.responseText;
	
                    if(isJson(jsonData)==true)
					{
						var array=$.parseJSON(jsonData);

					    if(typeof(array)!="object")return;

						
						var data = google.visualization.arrayToDataTable(array,true);



						if(ChartStart==0)
						{
						  ChartStart=1;
						  chart = new google.visualization.CandlestickChart(document.getElementById('chart_div'));
						}
						chart.draw(data, options);
						
						
						
						
						//--
						var strurl = "https://api.coinmarketcap.com/v1/ticker/"+Setting.Selection[0].idcmc+"/";
						var xhttpa = new XMLHttpRequest();
						xhttpa.onreadystatechange = function() 
						{
						if(this.readyState == 4 && this.status == 200) 
						{
							var RueckgabeReadFile=this.responseText;
							if(isJson(RueckgabeReadFile)==true)
							{
							 var CMCInfos = JSON.parse(RueckgabeReadFile);
							 document.getElementById("coinname").innerHTML = CMCInfos[0]["name"];
							 var num=parseFloat(CMCInfos[0]["market_cap_usd"])
							 document.getElementById("marketcap").innerHTML = "$"+(num).formatMoney(0);
							 document.getElementById("change").innerHTML = CMCInfos[0]["percent_change_7d"]+"%";
							 document.getElementById("price").innerHTML = "$"+CMCInfos[0]["price_usd"];
							}
						}
						};
						xhttpa.open("GET", "ReadHTTPFile.php?file="+strurl, true);
						xhttpa.send();


				

					 if(Setting.Selection[0].broker!="HitBTC")
					   {
						   var str  ="<span class=\"selected_timeframe\" id=\"D1\" onclick=\"writeToFile('leer','D1')\">D1</span>";
							   str +="<span class=\"selecttimeframe\" id=\"H4\" onclick=\"writeToFile('leer','H4')\">H4</span>";
							   str +="<span class=\"selecttimeframe\" id=\"H2\" onclick=\"writeToFile('leer','H2')\">H2</span>";
							   str +="<span class=\"selecttimeframem30\" id=\"M30\" onclick=\"writeToFile('leer','M30')\">M30</span>";
							   document.getElementById("timeframes_span").innerHTML = str;
					   }
					 else
					 if(Setting.Selection[0].broker=="HitBTC")
					   {
						   var str  ="<span class=\"selected_timeframe\" id=\"D1\" onclick=\"writeToFile('leer','D1')\">D1</span>";
							   str +="<span class=\"selecttimeframe\" id=\"H1\" onclick=\"writeToFile('leer','H1')\">H1</span>";
							   str +="<span class=\"selecttimeframem30\" id=\"M30\" onclick=\"writeToFile('leer','M30')\">M30</span>";
							   str +="<span class=\"selecttimeframem30\" id=\"M15\" onclick=\"writeToFile('leer','M15')\">M15</span>";
							   document.getElementById("timeframes_span").innerHTML = str;
					   }


					
					 if(Setting.Selection[0].broker!="HitBTC")
					   {
						   
						 if(Setting.Selection[0].timeframe=='D1') 
						   {
							 document.getElementById('D1').className = 'selected_timeframe';
							 document.getElementById('H4').className = 'selecttimeframe';
							 document.getElementById('H2').className = 'selecttimeframe';
							 document.getElementById('M30').className = 'selecttimeframem30';
						   }
						 if(Setting.Selection[0].timeframe=='H4') 
						   {
							 document.getElementById('D1').className = 'selecttimeframe';
							 document.getElementById('H4').className = 'selected_timeframe';
							 document.getElementById('H2').className = 'selecttimeframe';
							 document.getElementById('M30').className = 'selecttimeframem30';
						   }
						 if(Setting.Selection[0].timeframe=='H2') 
						   {
							 document.getElementById('D1').className = 'selecttimeframe';
							 document.getElementById('H4').className = 'selecttimeframe';
							 document.getElementById('H2').className = 'selected_timeframe';
							 document.getElementById('M30').className = 'selecttimeframem30';
						   }
						 if(Setting.Selection[0].timeframe=='M30') 
						   {
							 document.getElementById('D1').className = 'selecttimeframe';
							 document.getElementById('H4').className = 'selecttimeframe';
							 document.getElementById('H2').className = 'selecttimeframe';
							 document.getElementById('M30').className = 'selected_timeframem30';
						   }
					   
					   } 
					 else
					 if(Setting.Selection[0].broker=="HitBTC")
					   {
						 if(Setting.Selection[0].timeframe=='D1') 
						   {
							 document.getElementById('D1').className = 'selected_timeframe';
							 document.getElementById('H1').className = 'selecttimeframe';
							 document.getElementById('M30').className = 'selecttimeframem30';
							 document.getElementById('M15').className = 'selecttimeframem30';
						   }
						 if(Setting.Selection[0].timeframe=='H1') 
						   {
							 document.getElementById('D1').className = 'selecttimeframe';
							 document.getElementById('H1').className = 'selected_timeframe';
							 document.getElementById('M30').className = 'selecttimeframem30';
							 document.getElementById('M15').className = 'selecttimeframem30';
						   }
						 if(Setting.Selection[0].timeframe=='M30') 
						   {
							 document.getElementById('D1').className = 'selecttimeframe';
							 document.getElementById('H1').className = 'selecttimeframe';
							 document.getElementById('M30').className = 'selected_timeframem30';
							 document.getElementById('M15').className = 'selecttimeframem30';
						   }
						 if(Setting.Selection[0].timeframe=='M15') 
						   {
							 document.getElementById('D1').className = 'selecttimeframe';
							 document.getElementById('H1').className = 'selecttimeframe';
							 document.getElementById('M30').className = 'selecttimeframem30';
							 document.getElementById('M15').className = 'selected_timeframem30';
						   }
					   }
					  //--
					}
				}
				};
				httpchart.open("GET", fileurl, true);
				httpchart.send();
			}
		}
		else alert("Selected Chart json syntax error");

     }
   };
   xhttp1.open("GET", "ReadFile.php?file=SelectdChart.txt", true);
   xhttp1.send();

}










function WriteTextIntoFile(v1="leer.txt", v2="text")
{
      var url = "WriteIntoTextFile.php?file="+v1+"&text="+v2;
	  var xhttp_writefile = new XMLHttpRequest();
      xhttp_writefile.onreadystatechange = function() 
      {
      };
      xhttp_writefile.open("GET", url, true);
      xhttp_writefile.send();
}




function ShowExchanges(Symbol, v1="leer", v2="leer") 
{
	var d = new Date();var timestemp = d.getTime();
    //--
	var xhttpshw = new XMLHttpRequest();
    xhttpshw.onreadystatechange = function() 
    {
    if (this.readyState == 4 && this.status == 200) 
    {
	 var BrokerTextinhalt=this.responseText;
	 document.getElementById("exchangesbrokers").innerHTML = BrokerTextinhalt;
	 if(BrokerTextinhalt!="")
	 {
	 var list = document.getElementById("exchangesbrokers");
     var AnzahlBrokerHaveTheCoin=list.getElementsByTagName("anzahl")[0].innerHTML;
	 var BrokerFound=list.getElementsByTagName("find1")[0].innerHTML;
	 var BrokerFound2=list.getElementsByTagName("find2")[0].innerHTML;
	 if(BrokerFound==1){document.getElementById("exchangesauswahl").innerHTML = list.getElementsByTagName("output1")[0].innerHTML;}
	 if(BrokerFound==0){document.getElementById("exchangesauswahl").innerHTML = list.getElementsByTagName("output2")[0].innerHTML;}
	 }
    }
    };
    xhttpshw.open("GET", "Showexchanges.php?symbol="+Symbol+"&v1="+v1+"&timestemp="+timestemp+"&v2="+v2, true);
    xhttpshw.send();
}



function TradingCheckboxes2(id)
{
	if(document.getElementById(id).checked) document.getElementById(id).checked=false;
	else
	if(document.getElementById(id).checked==false) document.getElementById(id).checked=true;
}


//--






//--
var SignalsAboCount=1;
var PaginationSeite5=1;
//--
function Pagination5(v1)
{
  var maxpages5=1;
  if(document.getElementById("maxpages5"))maxpages5=document.getElementById("maxpages5").innerHTML;
  if(v1=="plus")PaginationSeite5++;
  else
  if(v1=="minus")PaginationSeite5--;
  if(PaginationSeite5<1)PaginationSeite5=1;
  if(PaginationSeite5>maxpages5)PaginationSeite5=maxpages5;
  console.log("PaginationSeite5 "+PaginationSeite5+"   maxpages5 "+maxpages5);
  SignalsAboCount=1;
  ShowAbonnementBox();
}
//--
function ShowAbonnementBox()
{
 if(SignalsAboCount==1) 
   {
		var d = new Date();var timestemp = d.getTime();
		//--
		var Winheight = document.getElementById('ChartBox').offsetHeight;
		document.getElementById('Abonnementbox').style.display = 'block';
		document.getElementById('Abonnementbox').style.height = Winheight+'px';
		SignalsAboCount=2;
		//--
		var xhttpa = new XMLHttpRequest();
		xhttpa.onreadystatechange = function() 
		{
		  if(this.readyState == 4 && this.status == 200) 
			{console.log(PaginationSeite5+"  "+this.responseText);
			  document.getElementById("AbonnementboxEntrys").innerHTML = this.responseText;
			}
		};
		xhttpa.open("GET", "signalssubscriptions.php?timestmp="+timestemp+"&PaginationSeite5="+PaginationSeite5, true);
		xhttpa.send();
		
		CreateSubscribtedSignalsTextfile();
   }
 else 
 if(SignalsAboCount==2)
   {
    document.getElementById('Abonnementbox').style.display = 'none';
	SignalsAboCount=1;
   }
}








//--
function PrintSignale()
{
	    var d = new Date();var timestemp = d.getTime();
		//--
		var xhttpa = new XMLHttpRequest();
		xhttpa.onreadystatechange = function() 
		{
		  if(this.readyState == 4 && this.status == 200) 
			{
			   var SignaleTextinhalt = this.responseText;
			   if(isJson(SignaleTextinhalt)==true)
				{
					SignaleObject = JSON.parse(SignaleTextinhalt);
					AktuelleSignale=SignaleObject.Signale.length;
					document.getElementById("AnzahlSignale").innerHTML = AktuelleSignale;
					var str="";
					var i2 = 0;
					for (i=0; i<AktuelleSignale; i++)
					   {
						 i2=i+1;
						 str += '<span class="SignalAusgabe" onclick="writeToFile(\''+SignaleObject.Signale[i].coin+'\',\''+SignaleObject.Signale[i].timeframe+'\',\''+SignaleObject.Signale[i].broker+'\',\''+SignaleObject.Signale[i].name+'\',\''+SignaleObject.Signale[i].cmcid+'\')"><span class="signalnumber">'+i2+'</span> <span class="signalname">'+SignaleObject.Signale[i].name+' '+SignaleObject.Signale[i].richtung+'</span><span class="clearfloat">&nbsp;</span></span>';
						 str += '<span class="clearfloat2">&nbsp;</span>';
					   }
					   document.getElementById("style3").innerHTML = str;
				}//json check
				else console.log("Read signale json syntax error");
			}
		};
		xhttpa.open("GET", "Signale.txt?timestmp="+timestemp, true);
		xhttpa.send();	
}





function SignaleDateiNeuErstellen()
{
	var d = new Date();var timestemp = d.getTime();
		//--
		var xhttpa = new XMLHttpRequest();
		xhttpa.onreadystatechange = function() 
		{
		  if(this.readyState == 4 && this.status == 200) 
			{
			}
		};
		xhttpa.open("GET", "CreateSignalsFile.php?timestmp="+timestemp, true);
		xhttpa.send();	
}



var BigDisplayCount=0;
function ShowSignalsBox(v1="leer")
{
 if(SignalsCount==1) 
   {
	
	if(v1=="save")
	{
		var d = new Date();var timestemp = d.getTime();
		//--
		var xhttpa = new XMLHttpRequest();
		xhttpa.onreadystatechange = function() 
		{
		  if(this.readyState == 4 && this.status == 200) 
			{
			 console.log("New Signalsfile Created: "+this.responseText);
			}
		};
		xhttpa.open("GET", "CreateSignalsFile.php?timestmp="+timestemp, true);
		xhttpa.send();	
	}
	var Winheight = document.getElementById('ChartBox').offsetHeight;
	document.getElementById('Signalbox').style.height = Winheight+'px';
    document.getElementById('Signalbox').style.display = 'block';
    if(BigDisplayCount==0)document.getElementById('ChartBox').style.width = "77%";
	else
    if(BigDisplayCount==1)document.getElementById('ChartBox').style.width = "81%";
    drawVisualization();
	SignalsCount=0;
	document.getElementById('coinname').style.margin = "0 10px 0 0";
   }
 else if(SignalsCount==0)
   {
    document.getElementById('Signalbox').style.display = 'none';
    document.getElementById('ChartBox').style.width = "100%";
    document.getElementById('chart_div').style.width = "100%";
	document.getElementById('coinname').style.margin = "0 10px 0 15px";
    drawVisualization();
	SignalsCount=1;
   }
}




//--

function BigDisplaySignals(v1)
{
 var Winheight = $(window).height();
 if(v1=="BigDisplayButtonSignal" && BigDisplayCount==0)
   {
    document.getElementById('trading').style.display = 'none';
    document.getElementById('buyhold').style.display = 'none';
    document.getElementById('signals').style.width = "98%";
	
	//--
	var Hoch=(Winheight/100)*86;
	document.getElementById('chart_div').style.height = Hoch+'px';
	
	if(SignalsCount==0)document.getElementById('ChartBox').style.width = "81%";
	else
	if(SignalsCount==1)document.getElementById('ChartBox').style.width = "100%";
		
    
	var Hoch2=(Winheight/100)*89;
	document.getElementById('Signalbox').style.height = Hoch2+'px';
    document.getElementById('Signalbox').style.width = '18%';
    document.getElementById('timeframes_span').style.margin = "0 0 0 55px";
    //--
	document.getElementById('BigDisplayButtonSignal').className = 'BigDisplayButton2';
	//--
	drawVisualization();
	BigDisplayCount=1;
   }
 else 
 if(v1=="BigDisplayButtonTrading" && BigDisplayCount==0)
   {
    document.getElementById('signals').style.display = 'none';
    document.getElementById('buyhold').style.display = 'none';
    document.getElementById('trading').style.width = "98%";
	//--
	if(BrokerTabClick==0)BrokerTabClick=1; else if(BrokerTabClick==1)BrokerTabClick=0;
    OpenBrokerTab(BrokerIDClickedShowBalanceOrders);
    //--
	document.getElementById('BigDisplayButtonTrading').className = 'BigDisplayButton2';
	//--
	drawVisualization();
	BigDisplayCount=1;
   }
 else 
 if(v1=="BigDisplayButtonBuyHold" && BigDisplayCount==0)
   {
    document.getElementById('signals').style.display = 'none';
    document.getElementById('buyhold').style.width = '98%';
    document.getElementById('trading').style.display = "none";
	//--
	document.getElementById('BigDisplayButtonBuyHold').className = 'BigDisplayButton2';
	//--
	BigDisplayCount=1;
   }
 else
 if(BigDisplayCount==1) 
   {
    document.getElementById('signals').style.display = "";
    document.getElementById('buyhold').style.display = "";
    document.getElementById('trading').style.display = "";
    //--
	if(v1=="BigDisplayButtonTrading")
	{
	  document.getElementById('trading').style.width = "";
	  if(BrokerTabClick==0)BrokerTabClick=1; else if(BrokerTabClick==1)BrokerTabClick=0;
      OpenBrokerTab(BrokerIDClickedShowBalanceOrders);
	}
    //--
	if(v1=="BigDisplayButtonBuyHold")
	{
	  document.getElementById('buyhold').style.width = "";
	  if(BrokerTabClick==0)BrokerTabClick=1; else if(BrokerTabClick==1)BrokerTabClick=0;
      OpenBrokerTab(BrokerIDClickedShowBalanceOrders);
	}
    //--
	if(v1=="BigDisplayButtonSignal")
	{
	  document.getElementById('chart_div').style.height = "";
	  var Hoch2 = document.getElementById('ChartBox').offsetHeight;
	  document.getElementById('Signalbox').style.height = Hoch2+'px';
	  document.getElementById('signals').style.width = "";
	  document.getElementById('Signalbox').style.width = "";
	  
	  if(SignalsCount==1)
	  {
		 document.getElementById('Signalbox').style.display = 'none';
		 document.getElementById('ChartBox').style.width = "100%";
	  }
	  else
	  {
		  document.getElementById('ChartBox').style.width = "77%";
	  }
	  document.getElementById('timeframes_span').style.margin = "0";
	}
    //--
	document.getElementById('BigDisplayButtonSignal').className = 'BigDisplayButton';
	document.getElementById('BigDisplayButtonTrading').className = 'BigDisplayButton';
	document.getElementById('BigDisplayButtonBuyHold').className = 'BigDisplayButton';
	//--
	drawVisualization();
	BigDisplayCount=0;
   }
}







var SignaleIndex=0;
//--
function ClickPlayPause()
{
 if(PlayPause==0)PlayPause=1;
 else
 if(PlayPause==1)
   {
    PlayPause=0;
    document.getElementById('playpausebutton').className = 'play';
   }

 if(PlayPause==1)
   { 
    document.getElementById('playpausebutton').className = 'pause';
   }
}



function PlaySignals()
{
   if(PlayPause==1)
   {
     writeToFile(SignaleObject.Signale[SignaleIndex].coin, SignaleObject.Signale[SignaleIndex].timeframe, SignaleObject.Signale[SignaleIndex].broker, SignaleObject.Signale[SignaleIndex].name, SignaleObject.Signale[SignaleIndex].cmcid, "signalplay");
     SignaleIndex++; if(SignaleIndex>=SignaleObject.Signale.length)SignaleIndex=0;
   }
   console.log("Platsignals "+SignaleIndex);
}



function OnLoadFunktion()
{
 Wiederholungen();
}





function OpenTradePanel(name="leer",kategorie="leer", broker="leer")
{
	document.getElementById("cost").innerHTML="";
	document.getElementById("cost2").innerHTML="";
	document.getElementById("cost3").innerHTML="";
	document.getElementById("usdamount").value="";
	document.getElementById("btcamount").value="";
	document.getElementById("coinamount").value="";
	document.getElementById("tpusdprice").value="";
	document.getElementById("tpusdvalue").value="";
	document.getElementById("tpbtcprice").value="";
	document.getElementById("slusdprice").value="";
	document.getElementById("slusdvalue").value="";
	document.getElementById("slbtcprice").value="";
	document.getElementById("usdlimitprice").value="";
	document.getElementById("btclimitprice").value="";
	document.getElementById("mrlimit").checked = false;
	document.getElementById("mrprice").checked = true;
	//--	
	document.getElementById("usdamountsg").value="";
	document.getElementById("btcamountsg").value="";
	document.getElementById("coinamountsg").value="";
	document.getElementById("tpusdpricesg").value="";
	document.getElementById("tpusdvaluesg").value="";
	document.getElementById("tpbtcpricesg").value="";
	document.getElementById("slusdpricesg").value="";
	document.getElementById("slusdvaluesg").value="";
	document.getElementById("slbtcpricesg").value="";
	document.getElementById("signalentrybh").checked = false;
	//--
    document.getElementById("usdamountbh").value="";
	document.getElementById("btcamountbh").value="";
	document.getElementById("coinamountbh").value="";
	document.getElementById("tpusdpricebh").value="";
	document.getElementById("tpusdvaluebh").value="";
	document.getElementById("tpbtcpricebh").value="";
	document.getElementById("slusdpricebh").value="";
	document.getElementById("slusdvaluebh").value="";
	document.getElementById("slbtcpricebh").value="";
	document.getElementById("buyholddistance").value="";
	document.getElementById("maxtradesbh").value="";
	//--
	var handelspaar="";
	if(name!="leer")
	{
	  var xhttpa = new XMLHttpRequest();
	  xhttpa.onreadystatechange = function() 
	  {
		if (this.readyState == 4 && this.status == 200) 
		   {
			 var res=this.responseText;
			 if(isJson(res)==true)
			 {
			   var CoinsListe = JSON.parse(res);
			   for (i=0; i<CoinsListe.Coins.length; i++) 
			   {
					if(name==CoinsListe.Coins[i].name) 
					  {
					   handelspaar=name+"   ("+CoinsListe.Coins[i].symbol+")";console.log("handelspaar "+handelspaar);
                       putThis(document.getElementById("myInput2"),handelspaar,CoinsListe.Coins[i].cmcid);
					   if(kategorie=="Signal")document.getElementById("SignalButton").click();
					   if(kategorie=="BuyHold")document.getElementById("BuyHoldButton").click();
					   break;
					  }
				}//for
			 }
		   }
	  };
	  xhttpa.open("GET", "Downloadliste_CoinsToken.txt", true);
	  xhttpa.send();
	}
	else
	{
	  handelspaar=Setting.Selection[0].name+"   ("+Setting.Selection[0].symbol+")";
      putThis(document.getElementById("myInput2"),handelspaar,Setting.Selection[0].idcmc);
	  document.getElementById("defaultOpen").click();
	}
	document.getElementById('id01').style.display='block';
	ResetCheckboxesEntryPrice();
	ResetCheckboxesSignalEntry(v1="leer");
	CoinNamenAufButtons();
	if(broker!="leer"){TradingCheckboxes('leer','LastExchange.txt', broker); console.log("TradingCheckboxes "+broker);}else TradingCheckboxes();
}

























var Balances = new Object;
var Orders = new Object;
var SeitePoloBalance=0;
var SeitePoloOrders=0;
var Anzahl=0;
var Anzahl2=0;
var BrokerVariable="";
function DrawBalanceAndOrders(Exchange)
{	
    if(typeof Exchange !== 'undefined')BrokerVariable=Exchange;

    var xhtttracc = new XMLHttpRequest();
	xhtttracc.onreadystatechange = function() 
	  {
		 if (this.readyState == 4 && this.status == 200) 
			{
			   var res=this.responseText;
			   if(isJson(res)==true)
				 {
					Balances = JSON.parse(res);
				    Anzahl=Balances.OpenTrades.length;
					if(Anzahl<=0)return;
					var list="";
					var a=0;
					var b=0;
					if(SeitePoloBalance==0)SeitePoloBalance=1;
					var Seiten=parseFloat(Anzahl/5);
					Seiten=Math.ceil(Seiten);
					if(SeitePoloBalance>Seiten)SeitePoloBalance=Seiten;
					var von=(SeitePoloBalance*5)-5; if(von<0)von=0;
					var bis=von+5;
					for(i=von; i<bis; i++)
					{
					  if(i<Anzahl && Anzahl>0 && Balances.OpenTrades[i].symbol!="")
					  {
						  b++;
						  if(a==0)
						  {
						  list += "<span class=\"balanceentryleft\">"+Balances.OpenTrades[i].symbol+"</span>";
						  list += "<span class=\"balanceentryright\">"+Balances.OpenTrades[i].balance+"</span>";
						  list += "<span class=\"clearfloat\">&nbsp;</span>";
						  a++;
						  }
						  else if(a==1)
						  {
						  list += "<span class=\"balanceentrybg\">";
						  list += "<span class=\"balanceentryleft\">"+Balances.OpenTrades[i].symbol+"</span>";
						  list += "<span class=\"balanceentryright\">"+Balances.OpenTrades[i].balance+"</span>";
						  list += "<span class=\"clearfloat\">&nbsp;</span>";
						  list += "</span>";
						  a=0;
						  }
					  }
					  else if(i<bis)
					  {
						  b++;
						  if(a==0)
						  {
						  list += "<span class=\"balanceentryleft\">&nbsp;</span>";
						  list += "<span class=\"balanceentryright\">&nbsp;</span>";
						  list += "<span class=\"clearfloat\">&nbsp;</span>";
						  a++;
						  }
						  else if(a==1)
						  {
						  list += "<span class=\"balanceentrybg\">";
						  list += "<span class=\"balanceentryleft\">&nbsp;</span>";
						  list += "<span class=\"balanceentryright\">&nbsp;</span>";
						  list += "<span class=\"clearfloat\">&nbsp;</span>";
						  list += "</span>";
						  a=0;
						  }
					  }
					  if(i==bis-1 && b<4)
					  {
					  list += "<span class=\"balanceentryleft\">&nbsp;</span>";
					  list += "<span class=\"balanceentryright\">&nbsp;</span>";
					  list += "<span class=\"clearfloat\">&nbsp;</span>";
					  break;
					  }
					}
					
					//--
					
					var IDName1="";
					var IDName2="";
					
					
					if(BrokerVariable=="Binance")
					{
						IDName1="BinanceBalancesList";
						IDName2="Binancepagenav";
					}
					
					
					//--
					
					if(document.getElementById(IDName1))document.getElementById(IDName1).innerHTML = list;
					
					if(Anzahl<=5)
					{
					 if(document.getElementById(IDName2))document.getElementById(IDName2).innerHTML = "Page 1 of 1";
					}
					else if(Anzahl>5 && SeitePoloBalance==1)
					{
					 if(document.getElementById(IDName2))document.getElementById(IDName2).innerHTML = "Page "+SeitePoloBalance+" of "+Seiten+" <span class=\"nextsitebuttonbal\" onclick=\"PaginationBal(\'plus\', \'"+BrokerVariable+"\')\">&raquo;</span>";
					}
					else if(Anzahl>5 && SeitePoloBalance>1 && SeitePoloBalance<Seiten)
					{
					 if(document.getElementById(IDName2))document.getElementById(IDName2).innerHTML = "<span class=\"nextsitebuttonbal\" onclick=\"PaginationBal(\'minus\', \'"+BrokerVariable+"\')\">&laquo;</span> Page "+SeitePoloBalance+" of "+Seiten+" <span class=\"nextsitebuttonbal\" onclick=\"PaginationBal(\'plus\', \'"+BrokerVariable+"\')\">&raquo;</span>";
					}
					else if(Anzahl>5 && SeitePoloBalance>1 && SeitePoloBalance==Seiten)
					{
					 if(document.getElementById(IDName2))document.getElementById(IDName2).innerHTML = "<span class=\"nextsitebuttonbal\" onclick=\"PaginationBal(\'minus\', \'"+BrokerVariable+"\')\">&laquo;</span> Page "+SeitePoloBalance+" of "+Seiten;
					}
				 }
			}
	  };     
	  xhtttracc.open("GET", "ExchangesApis.php?Balances=1&Exchange="+BrokerVariable, true);
	  xhtttracc.send();


  
  


      var xhtttracc2 = new XMLHttpRequest();
	  xhtttracc2.onreadystatechange = function() 
	  {
		 if (this.readyState == 4 && this.status == 200) 
			{
			   var res=this.responseText;
			   if(isJson(res)==true)
				 {
					Orders = JSON.parse(res);
					Anzahl2=Orders.OpenPendings.length;
					var list2="";
					var a2=0;
					var b2=0;
					if(SeitePoloOrders==0)SeitePoloOrders=1;
					var Seiten2=0;
					if(Anzahl2>0)Seiten2=parseFloat(Anzahl2/5);
					Seiten2=Math.ceil(Seiten2);
					if(SeitePoloOrders>Seiten2)SeitePoloOrders=Seiten2;
					var von2=(SeitePoloOrders*5)-5; if(von2<0)von2=0;
					var bis2=von2+5;
					for(i=von2; i<bis2; i++)
					{
					  if(i<Anzahl2 && Anzahl2>0 && Orders.OpenPendings[i].symbol!="")
					  {
						  b2++;
						  if(a2==0)
						  {
						  list2 += "<span class=\"balanceentryleft\">"+Orders.OpenPendings[i].symbol+"</span>";
						  list2 += "<span class=\"balanceentryright\">"+Orders.OpenPendings[i].amount+" <span class=\"balanceentryrightmodify\" onclick=\"ModifyPending(\'"+Orders.OpenPendings[i].speicher+"\','"+Orders.OpenPendings[i].id+"\','"+Orders.OpenPendings[i].name+"\',\'"+Orders.OpenPendings[i].symbol+"\',\'"+Orders.OpenPendings[i].broker+"\',\'"+Orders.OpenPendings[i].typ+"\',\'"+Orders.OpenPendings[i].amount+"\',\'"+Orders.OpenPendings[i].amountwr+"\',\'"+Orders.OpenPendings[i].price+"\',\'"+Orders.OpenPendings[i].waehrung+"\',\'"+Orders.OpenPendings[i].tp+"\',\'"+Orders.OpenPendings[i].tpein+"\',\'"+Orders.OpenPendings[i].sl+"\',\'"+Orders.OpenPendings[i].slein+"\')\">&nbsp;</span></span>";
						  list2 += "<span class=\"clearfloat\">&nbsp;</span>";
						  a2++;
						  }
						  else if(a2==1)
						  {
						  list2 += "<span class=\"balanceentrybg\">";
						  list2 += "<span class=\"balanceentryleft\">"+Orders.OpenPendings[i].symbol+"</span>";
						  list2 += "<span class=\"balanceentryright\">"+Orders.OpenPendings[i].amount+" <span class=\"balanceentryrightmodify\" onclick=\"ModifyPending(\'"+Orders.OpenPendings[i].speicher+"\','"+Orders.OpenPendings[i].id+"\','"+Orders.OpenPendings[i].name+"\',\'"+Orders.OpenPendings[i].symbol+"\',\'"+Orders.OpenPendings[i].broker+"\',\'"+Orders.OpenPendings[i].typ+"\',\'"+Orders.OpenPendings[i].amount+"\',\'"+Orders.OpenPendings[i].amountwr+"\',\'"+Orders.OpenPendings[i].price+"\',\'"+Orders.OpenPendings[i].waehrung+"\',\'"+Orders.OpenPendings[i].tp+"\',\'"+Orders.OpenPendings[i].tpein+"\',\'"+Orders.OpenPendings[i].sl+"\',\'"+Orders.OpenPendings[i].slein+"\')\">&nbsp;</span></span>";
						  list2 += "<span class=\"clearfloat\">&nbsp;</span>";
						  list2 += "</span>";
						  a2=0;
						  }
					  }
					  else if(i<bis2)
					  {
						  b2++;
						  if(a2==0)
						  {
						  list2 += "<span class=\"balanceentryleft\">&nbsp;</span>";
						  list2 += "<span class=\"balanceentryright\">&nbsp;</span>";
						  list2 += "<span class=\"clearfloat\">&nbsp;</span>";
						  a2++;
						  }
						  else if(a2==1)
						  {
						  list2 += "<span class=\"balanceentrybg\">";
						  list2 += "<span class=\"balanceentryleft\">&nbsp;</span>";
						  list2 += "<span class=\"balanceentryright\">&nbsp;</span>";
						  list2 += "<span class=\"clearfloat\">&nbsp;</span>";
						  list2 += "</span>";
						  a2=0;
						  }
					  }
					  if(i==bis2-1 && b2<4)
					  {
					  list2 += "<span class=\"balanceentryleft\">&nbsp;</span>";
					  list2 += "<span class=\"balanceentryright\">&nbsp;</span>";
					  list2 += "<span class=\"clearfloat\">&nbsp;</span>";
					  break;
					  }
					}
					
					//--
					
					var IDName1="";
					var IDName2="";
					
					if(BrokerVariable=="Binance")
					{
						IDName1="BinanceOrdersList";
						IDName2="Binancepagenav2";
					}
					
					
					
					//--
					
					if(document.getElementById(IDName1))document.getElementById(IDName1).innerHTML = list2;

					if(Anzahl2<=5)
					{
					 if(document.getElementById(IDName2))document.getElementById(IDName2).innerHTML = "Page 1 of 1";
					}
					else if(Anzahl2>5 && SeitePoloOrders==1)
					{
					 if(document.getElementById(IDName2))document.getElementById(IDName2).innerHTML = "Page "+SeitePoloOrders+" of "+Seiten2+" <span class=\"nextsitebuttonbal\" onclick=\"PaginationOrd(\'plus\', \'"+BrokerVariable+"\')\">&raquo;</span>";
					}
					else if(Anzahl2>5 && SeitePoloOrders>1 && SeitePoloOrders<Seiten2)
					{
					 if(document.getElementById(IDName2))document.getElementById(IDName2).innerHTML = "<span class=\"nextsitebuttonbal\" onclick=\"PaginationOrd(\'minus\', \'"+BrokerVariable+"\')\">&laquo;</span> Page "+SeitePoloOrders+" of "+Seiten2+" <span class=\"nextsitebuttonbal\" onclick=\"PaginationOrd(\'plus\', \'"+BrokerVariable+"\')\">&raquo;</span>";
					}
					else if(Anzahl2>5 && SeitePoloOrders>1 && SeitePoloOrders==Seiten2)
					{
					 if(document.getElementById(IDName2))document.getElementById(IDName2).innerHTML = "<span class=\"nextsitebuttonbal\" onclick=\"PaginationOrd(\'minus\', \'"+BrokerVariable+"\')\">&laquo;</span> Page "+SeitePoloOrders+" of "+Seiten2;
					}
				 }
			}
	  };     
	  xhtttracc2.open("GET", "ExchangesApis.php?Orders=1&Exchange="+BrokerVariable, true);
	  xhtttracc2.send();
	  //--	
}










//--
function OpenBrokerTab(brokerid)
{
	var offsetHeight = document.getElementById('ChartBox').offsetHeight-300;
	if(offsetHeight<10)offsetHeight=470;
	//--
	if(brokerid=="")brokerid=BrokerIDClickedShowBalanceOrders;
	BrokerIDClickedShowBalanceOrders=brokerid;

	if(BrokerTabClick==0)
	{
	  var y = document.getElementsByClassName("brokertab2");
	  var i;
	  for (i = 0; i < y.length; i++) 
		  {
		    y[i].style.borderRadius = "10px 10px 0 0";
		  }
	   y = document.getElementsByClassName("tabcont");
	   i;
	  for (i = 0; i < y.length; i++) 
		  {
		    y[i].style.display = "block";
		  }
	}
	else if(BrokerTabClick==1)
	{
	  var y = document.getElementsByClassName("brokertab2");
	  var i;
	  for (i = 0; i < y.length; i++) 
		  {
		    y[i].style.borderRadius = "10px";
		  }
	   y = document.getElementsByClassName("tabcont");
	   i;
	  for (i = 0; i < y.length; i++) 
		  {
		    y[i].style.display = "none";
		  }
	}

	
	if(brokerid=="BinancebrokerUB" && BrokerTabClick==0)
	{
	   BrokerTabClick=1;
	   document.getElementById('Binancebroker').style.height = offsetHeight+'px';
	   DrawBalanceAndOrders("Binance");
	}
	else if(BrokerTabClick==1)
	{
	   BrokerTabClick=0;
	   document.getElementById('Binancebroker').style.height = '';
	   //--
	   document.getElementById('Binancebroker').style.display = 'block';
	}  
}











function TradingAccounts()
{

  ShowBuyAndHoldEntrys();
  
  var d = new Date();var timestemp = d.getTime();
  //--
  var xhtttracc3 = new XMLHttpRequest(); xhtttracc3.onreadystatechange = function() {if (this.readyState == 4 && this.status == 200) 
  {if(this.responseText>0)document.getElementById("anzahlbinance").innerHTML = "("+this.responseText+")";}};
  xhtttracc3.open("GET", "AnzahlOrdersBinance.txt?timestemp="+timestemp, true);xhtttracc3.send();
  
  if(BrokerIDClickedShowBalanceOrders!="")
  {
	if(BrokerTabClick==0)BrokerTabClick=1; else if(BrokerTabClick==1)BrokerTabClick=0;
    OpenBrokerTab(BrokerIDClickedShowBalanceOrders);
  }
}














function PaginationBal(v1, Exchange)
{
	if(v1=="plus")SeitePoloBalance++;
	else
	if(v1=="minus")SeitePoloBalance--;
    if(SeitePoloBalance<1)SeitePoloBalance=1;
	Anzahl=Balances.OpenTrades.length;
	var list="";
	var a=0;
	var b=0;
	if(SeitePoloBalance==0)SeitePoloBalance=1;
	var Seiten=parseFloat(Anzahl/5);
	Seiten=Math.ceil(Seiten);
	if(SeitePoloBalance>Seiten)SeitePoloBalance=Seiten;
	var von=(SeitePoloBalance*5)-5; if(von<0)von=0;
	var bis=von+5;
	for(i=von; i<bis; i++)
	{
		if(i<Anzahl && Anzahl>0 && Balances.OpenTrades[i].symbol!="")
		{
			b++;
			if(a==0)
			{
			list += "<span class=\"balanceentryleft\">"+Balances.OpenTrades[i].symbol+"</span>";
			list += "<span class=\"balanceentryright\">"+Balances.OpenTrades[i].balance+"</span>";
			list += "<span class=\"clearfloat\">&nbsp;</span>";
			a++;
		}
		else if(a==1)
		{
		    list += "<span class=\"balanceentrybg\">";
			list += "<span class=\"balanceentryleft\">"+Balances.OpenTrades[i].symbol+"</span>";
			list += "<span class=\"balanceentryright\">"+Balances.OpenTrades[i].balance+"</span>";
			list += "<span class=\"clearfloat\">&nbsp;</span>";
			list += "</span>";
			a=0;
		}
		}
		else if(i<bis)
		{
		b++;
		if(a==0)
		{
		list += "<span class=\"balanceentryleft\">&nbsp;</span>";
		list += "<span class=\"balanceentryright\">&nbsp;</span>";
		list += "<span class=\"clearfloat\">&nbsp;</span>";
		a++;
		}
		else if(a==1)
		{
		list += "<span class=\"balanceentrybg\">";
		list += "<span class=\"balanceentryleft\">&nbsp;</span>";
		list += "<span class=\"balanceentryright\">&nbsp;</span>";
		list += "<span class=\"clearfloat\">&nbsp;</span>";
		list += "</span>";
		a=0;
		}
		}
		if(i==bis-1 && b<4)
		{
		list += "<span class=\"balanceentryleft\">&nbsp;</span>";
		list += "<span class=\"balanceentryright\">&nbsp;</span>";
		list += "<span class=\"clearfloat\">&nbsp;</span>";
		break;
		}
		}
		
					
					var IDName1="";
					var IDName2="";
					
					
					if(Exchange=="Binance")
					{
						IDName1="BinanceBalancesList";
						IDName2="Binancepagenav";
					}
					
					
		//--

		if(document.getElementById(IDName1))document.getElementById(IDName1).innerHTML = list;
					
		if(Anzahl<=5)
		{
		 if(document.getElementById(IDName2))document.getElementById(IDName2).innerHTML = "Page 1 of 1";
		}
		else if(Anzahl>5 && SeitePoloBalance==1)
		{
		 if(document.getElementById(IDName2))document.getElementById(IDName2).innerHTML = "Page "+SeitePoloBalance+" of "+Seiten+" <span class=\"nextsitebuttonbal\" onclick=\"PaginationBal(\'plus\', \'"+Exchange+"\')\">&raquo;</span>";
		}
		else if(Anzahl>5 && SeitePoloBalance>1 && SeitePoloBalance<Seiten)
		{
		 if(document.getElementById(IDName2))document.getElementById(IDName2).innerHTML = "<span class=\"nextsitebuttonbal\" onclick=\"PaginationBal(\'minus\', \'"+Exchange+"\')\">&laquo;</span> Page "+SeitePoloBalance+" of "+Seiten+" <span class=\"nextsitebuttonbal\" onclick=\"PaginationBal(\'plus\', \'"+Exchange+"\')\">&raquo;</span>";
		}
		else if(Anzahl>5 && SeitePoloBalance>1 && SeitePoloBalance==Seiten)
		{
		 if(document.getElementById(IDName2))document.getElementById(IDName2).innerHTML = "<span class=\"nextsitebuttonbal\" onclick=\"PaginationBal(\'minus\', \'"+Exchange+"\')\">&laquo;</span> Page "+SeitePoloBalance+" of "+Seiten;
		}
}

function PaginationOrd(v1="leer", Exchange)
{
	if(v1=="plus")SeitePoloOrders++;
	else
	if(v1=="minus")SeitePoloOrders--;
    if(SeitePoloOrders<1)SeitePoloOrders=1;
	//--
	Anzahl2=Orders.OpenPendings.length;
	var list2="";
	var a2=0;
    var b2=0;
    if(SeitePoloOrders==0)SeitePoloOrders=1;
    var Seiten2=0;
	if(Anzahl2>0)Seiten2=parseFloat(Anzahl2/5);
    Seiten2=Math.ceil(Seiten2);
    if(SeitePoloOrders>Seiten2)SeitePoloOrders=Seiten2;
    var von2=(SeitePoloOrders*5)-5; if(von2<0)von2=0;
    var bis2=von2+5;
    for(i=von2; i<bis2; i++)
    {
    if(i<Anzahl2 && Anzahl2>0 && Orders.OpenPendings[i].symbol!="")
    {
    b2++;
    if(a2==0)
    {
    list2 += "<span class=\"balanceentryleft\">"+Orders.OpenPendings[i].symbol+"</span>";
    list2 += "<span class=\"balanceentryright\">"+Orders.OpenPendings[i].amount+" <span class=\"balanceentryrightmodify\" onclick=\"ModifyPending(\'"+Orders.OpenPendings[i].speicher+"\','"+Orders.OpenPendings[i].id+"\','"+Orders.OpenPendings[i].name+"\',\'"+Orders.OpenPendings[i].symbol+"\',\'"+Orders.OpenPendings[i].broker+"\',\'"+Orders.OpenPendings[i].typ+"\',\'"+Orders.OpenPendings[i].amount+"\',\'"+Orders.OpenPendings[i].amountwr+"\',\'"+Orders.OpenPendings[i].price+"\',\'"+Orders.OpenPendings[i].waehrung+"\',\'"+Orders.OpenPendings[i].tp+"\',\'"+Orders.OpenPendings[i].tpein+"\',\'"+Orders.OpenPendings[i].sl+"\',\'"+Orders.OpenPendings[i].slein+"\')\">&nbsp;</span></span>";
    list2 += "<span class=\"clearfloat\">&nbsp;</span>";
    a2++;
    }
    else if(a2==1)
    {
    list2 += "<span class=\"balanceentrybg\">";
    list2 += "<span class=\"balanceentryleft\">"+Orders.OpenPendings[i].symbol+"</span>";
    list2 += "<span class=\"balanceentryright\">"+Orders.OpenPendings[i].amount+" <span class=\"balanceentryrightmodify\" onclick=\"ModifyPending(\'"+Orders.OpenPendings[i].speicher+"\','"+Orders.OpenPendings[i].id+"\','"+Orders.OpenPendings[i].name+"\',\'"+Orders.OpenPendings[i].symbol+"\',\'"+Orders.OpenPendings[i].broker+"\',\'"+Orders.OpenPendings[i].typ+"\',\'"+Orders.OpenPendings[i].amount+"\',\'"+Orders.OpenPendings[i].amountwr+"\',\'"+Orders.OpenPendings[i].price+"\',\'"+Orders.OpenPendings[i].waehrung+"\',\'"+Orders.OpenPendings[i].tp+"\',\'"+Orders.OpenPendings[i].tpein+"\',\'"+Orders.OpenPendings[i].sl+"\',\'"+Orders.OpenPendings[i].slein+"\')\">&nbsp;</span></span>";
    list2 += "<span class=\"clearfloat\">&nbsp;</span>";
    list2 += "</span>";
    a2=0;
    }
    }
    else if(i<bis2)
    {
    b2++;
    if(a2==0)
    {
    list2 += "<span class=\"balanceentryleft\">&nbsp;</span>";
    list2 += "<span class=\"balanceentryright\">&nbsp;</span>";
    list2 += "<span class=\"clearfloat\">&nbsp;</span>";
    a2++;
    }
    else if(a2==1)
    {
    list2 += "<span class=\"balanceentrybg\">";
    list2 += "<span class=\"balanceentryleft\">&nbsp;</span>";
    list2 += "<span class=\"balanceentryright\">&nbsp;</span>";
    list2 += "<span class=\"clearfloat\">&nbsp;</span>";
    list2 += "</span>";
    a2=0;
    }
    }
    if(i==bis2-1 && b2<4)
    {
    list2 += "<span class=\"balanceentryleft\">&nbsp;</span>";
    list2 += "<span class=\"balanceentryright\">&nbsp;</span>";
    list2 += "<span class=\"clearfloat\">&nbsp;</span>";
    break;
    }
    }
	
					
					var IDName1="";
					var IDName2="";
					
					
					if(Exchange=="Binance")
					{
						IDName1="BinanceOrdersList";
						IDName2="Binancepagenav2";
					}
					
					
					//--
	
    if(document.getElementById(IDName1))document.getElementById(IDName1).innerHTML = list2;			
    if(Anzahl2<=5)
    {
     if(document.getElementById(IDName2))document.getElementById(IDName2).innerHTML = "Page 1 of 1";
    }
    else if(Anzahl2>5 && SeitePoloOrders==1)
    {
     if(document.getElementById(IDName2))document.getElementById(IDName2).innerHTML = "Page "+SeitePoloOrders+" of "+Seiten2+" <span class=\"nextsitebuttonbal\" onclick=\"PaginationOrd(\'plus\', \'"+Exchange+"\')\">&raquo;</span>";
    }
    else if(Anzahl2>5 && SeitePoloOrders>1 && SeitePoloOrders<Seiten2)
    {
     if(document.getElementById(IDName2))document.getElementById(IDName2).innerHTML = "<span class=\"nextsitebuttonbal\" onclick=\"PaginationOrd(\'minus\', \'"+Exchange+"\')\">&laquo;</span> Page "+SeitePoloOrders+" of "+Seiten2+" <span class=\"nextsitebuttonbal\" onclick=\"PaginationOrd(\'plus\', \'"+Exchange+"\')\">&raquo;</span>";
    }
    else if(Anzahl2>5 && SeitePoloOrders>1 && SeitePoloOrders==Seiten2)
    {
     if(document.getElementById(IDName2))document.getElementById(IDName2).innerHTML = "<span class=\"nextsitebuttonbal\" onclick=\"PaginationOrd(\'minus\', \'"+Exchange+"\')\">&laquo;</span> Page "+SeitePoloOrders+" of "+Seiten2;
    }
}























function ModifyPending(speicher, id, nam, sym, broker, typ, vol, volein, price, priceein, tp, tpein, sl, slein)
{
  var con="";
  var voleinh="";if(volein=="COIN")voleinh=sym; else voleinh=volein;
  var tpeinh="";if(tpein=="USDW")tpeinh="win USD value"; else tpeinh=tpein;
  var sleinh="";if(slein=="USDW")sleinh="loos USD value"; else sleinh=slein;
  var priceusd=""; var pricebtc="";
  var entryvus="";var entryvbt="";if(priceein=="USD"){ priceusd=price; entryvus="value=\""+price+"\""; } else {pricebtc=price; entryvbt="value=\""+price+"\"";}
  var vusd=""; var vbtc=""; var vcoin="";
  var volus="";var volbtc="";var volcoin="";if(volein=="COIN"){ vcoin=vol; volcoin="value=\""+vol+"\""; } else if(volein=="USD"){vusd=vol; volus="value=\""+vol+"\""; }else if(volein=="BTC"){vbtc=vol;volbtc="value=\""+vol+"\"";}
  var tusd="";var tbtc="";var tw="";
  var tpus="";var tpw="";var tpb="";if(tpein=="USDW"){ tw=tp; tpw="value=\""+tp+"\""; } else if(tpein=="USD"){tusd=tp; tpus="value=\""+tp+"\""; }else if(tpein=="BTC"){tbtc=tp; tpb="value=\""+tp+"\"";}
  var susd="";var sbtc="";var sw="";
  var slus="";var slw="";var slb="";if(slein=="USDW"){ sw=sl; slw="value=\""+sl+"\""; } else if(slein=="USD"){susd=sl; slus="value=\""+sl+"\"";} else if(slein=="BTC"){sbtc=sl; slb="value=\""+sl+"\"";}

  con += "<div style=\"font-size:17px\">";
  con += "<p id=\"modifysymbol\"><b>Symbol:</b> "+nam+" ("+sym+")</p>";
  con += "<p id=\"modifybroker\"><b>Broker:</b> "+broker+"</p>";
  con += "<p id=\"modifytype\"><b>Type:</b> "+typ+"</p>";
  con += "<p id=\"modifytype\"><b>Price:</b> "+price+" "+priceein+"</p>";
  con += "<p id=\"modifyvolumme\"><b>Volume:</b> "+vol+" "+voleinh+"</p>";
  con += "<p id=\"modifytp\"><b>Takeprofit:</b> "+tp+" "+tpeinh+"</p>";
  con += "<p id=\"modifysl\"><b>Stoploss:</b> "+sl+" "+sleinh+"</p>";
  con += "</div>";

  if(speicher=="broker")
    {
	  con += "<div style=\"font-size:17px;color:blue;margin:15px 0 0 0\">This order have been opened in your Exchange account.</div>";
	  con += "<span class=\"clearfloat\">&nbsp;</span>";
      if(broker=="Binance")con += "<button class=\"deletepending\" style=\"width:100%\" onclick=\"DeletePendingOrder('"+id+"','"+broker+"','"+nam+"','"+priceein+"')\">Delete Pendingorder</button>";
      else                 con += "<button class=\"deletepending\" style=\"width:100%\" onclick=\"DeletePendingOrder('"+id+"','"+broker+"')\">Delete Pendingorder</button>";
      con += "<span class=\"clearfloat\">&nbsp;</span>";
	}
  
  if(price=="Marketprice" && speicher!="broker")
  {   
	  con += "  <div style=\"font-size:17px;color:blue;margin:15px 0 0 0\">This is a Marketorder, only Takeprofit and Stoploss can be changed or deleted.</div>";
	  con += "  <div style=\"display:none;margin:15px 0 5px 0px;border:1px solid #8ae9f2;background:#daf0f2;width:49%;border-radius:10px;\">";
	  con += "	<p class=\"selectTraceUeber\">Change Entry Rules</p>";
	  con += "	<p style=\"margin:10px;font-size: 19px;\">";
	  con += "	Entry Price<br>";
	  con += "	<input class=\"inpprice2\" type=\"text\"  id=\"modifyusdlimitprice\" placeholder=\"USD Price..\" value=\"\" onkeyup=\"ResetModifyEntryUSD()\"> or <br>";
	  con += "	<input class=\"inpprice2\" type=\"text\" id=\"modifybtclimitprice\" placeholder=\"BTC Price..\" value=\"\" onkeyup=\"ResetModifyEntryBTC()\">";
	  con += "	<br><br>";
	  con += "	Volume: <br><input class=\"inpprice2\" type=\"text\" id=\"modifyusdamount\" placeholder=\"USD Value..\" "+volus+" onkeyup=\"ResetModifyCostUSD()\"> or <br>";
	  con += "	                <input class=\"inpprice2\" type=\"text\" id=\"modifybtcamount\" placeholder=\"BTC Value..\" "+volbtc+" onkeyup=\"ResetModifyCostBTC()\"> or <br>";
	  con += "	                <input class=\"inpprice2\" type=\"text\" id=\"modifycoinamount\" placeholder=\""+sym+" Value..\" "+volcoin+" onkeyup=\"ResetModifyCostCoin()\">";
	  con += "	<span id=\"modifycost\"></span>";
	  con += "	</p>";
	  con += "  </div>";
	  con += "  <div style=\"float:left;margin:15px 0 5px 0px;border:1px solid #8ae9f2;background:#daf0f2;width:100%;border-radius:10px;\">";
	  con += "	<p class=\"selectTraceUeber\">Change Exit Rules</p>";
	  con += "	<p style=\"margin:10px;font-size: 19px;\">";
	  con += "	  Takeprofit: <br>";
	  con += "	              <input class=\"inpprice2\" type=\"text\" id=\"modifytpusdprice\" onkeyup=\"ResetModifyTPUSD()\" "+tpus+" placeholder=\"USD if price go up to ..\"> or <br>";
	  con += "	              <input class=\"inpprice2\" type=\"text\" id=\"modifytpusdvalue\"  onkeyup=\"ResetModifyTPUSDW()\" "+tpw+" placeholder=\"If value go up to..USD\"> or <br>";
	  con += "	              <input class=\"inpprice2\" type=\"text\" id=\"modifytpbtcprice\" onkeyup=\"ResetModifyTPBTC()\"  "+tpb+" placeholder=\"BTC if price reach ..\"> <br><br>";

	  con += "	  Stoploss: <br>";
	  con += "	            <input class=\"inpprice2\" type=\"text\" id=\"modifyslusdprice\" onkeyup=\"ResetModifySLUSD()\" "+slus+" placeholder=\"USD if price go down to ..\"> or <br>";
	  con += "	            <input class=\"inpprice2\" type=\"text\" id=\"modifyslusdvalue\" onkeyup=\"ResetModifySLUSDW()\" "+slw+" placeholder=\"If value go down to..USD\"> or <br>";
	  con += "	            <input class=\"inpprice2\" type=\"text\" id=\"modifyslbtcprice\" onkeyup=\"ResetModifySLBTC()\" "+slb+" placeholder=\"BTC if price reach ..\">";
	  con += "	 </p>";
	  con += "   </div>";
	 
	  con += "<span class=\"clearfloat\">&nbsp;</span>";
	  con += "<button class=\"modifypending\" onclick=\"ModifyTraderequests('"+id+"','"+priceusd+"','"+pricebtc+"','"+vusd+"','"+vbtc+"','"+vcoin+"','"+tusd+"','"+tw+"','"+tbtc+"','"+susd+"','"+sw+"','"+sbtc+"')\">Modify Takeprofit/Stoploss</button>";
	  con += "<button class=\"deletepending\" onclick=\"DeleteTraderequest('"+id+"','nodelete')\">Delete Takeprofit/Stoploss</button>";
	  con += "<span class=\"clearfloat\">&nbsp;</span>";
  }
  else if(speicher!="broker")
  {
  con += "  <div style=\"float:left;margin:15px 0 5px 0px;border:1px solid #8ae9f2;background:#daf0f2;width:49%;border-radius:10px;\">";
  con += "	<p class=\"selectTraceUeber\">Change Entry Rules</p>";
  con += "	<p style=\"margin:10px;font-size: 19px;\">";
  con += "	Entry Price<br>";
  con += "	<input class=\"inpprice2\" type=\"text\"  id=\"modifyusdlimitprice\" placeholder=\"USD Price..\" "+entryvus+" onkeyup=\"ResetModifyEntryUSD()\"> or <br>";
  con += "	<input class=\"inpprice2\" type=\"text\" id=\"modifybtclimitprice\" placeholder=\"BTC Price..\" "+entryvbt+" onkeyup=\"ResetModifyEntryBTC()\">";
  con += "	<br><br>";
  con += "	Volume: <br><input class=\"inpprice2\" type=\"text\" id=\"modifyusdamount\" placeholder=\"USD Value..\" "+volus+" onkeyup=\"ResetModifyCostUSD()\"> or <br>";
  con += "	                <input class=\"inpprice2\" type=\"text\" id=\"modifybtcamount\" placeholder=\"BTC Value..\" "+volbtc+" onkeyup=\"ResetModifyCostBTC()\"> or <br>";
  con += "	                <input class=\"inpprice2\" type=\"text\" id=\"modifycoinamount\" placeholder=\""+sym+" Value..\" "+volcoin+" onkeyup=\"ResetModifyCostCoin()\">";
  con += "	<span id=\"modifycost\"></span>";
  con += "	</p>";
  con += "</div>";

  con += "  <div style=\"float:right;margin:15px 0 5px 0px;border:1px solid #8ae9f2;background:#daf0f2;width:49%;border-radius:10px;\">";
  con += "	<p class=\"selectTraceUeber\">Change Exit Rules</p>";
  con += "	<p style=\"margin:10px;font-size: 19px;\">";
  con += "	  Takeprofit: <br>";
  con += "	              <input class=\"inpprice2\" type=\"text\" id=\"modifytpusdprice\" onkeyup=\"ResetModifyTPUSD()\" "+tpus+" placeholder=\"USD if price go up to ..\"> or <br>";
  con += "	              <input class=\"inpprice2\" type=\"text\" id=\"modifytpusdvalue\"  onkeyup=\"ResetModifyTPUSDW()\" "+tpw+" placeholder=\"If value go up to..USD\"> or <br>";
  con += "	              <input class=\"inpprice2\" type=\"text\" id=\"modifytpbtcprice\" onkeyup=\"ResetModifyTPBTC()\"  "+tpb+" placeholder=\"BTC if price reach ..\"> <br><br>";

  con += "	  Stoploss: <br>";
  con += "	            <input class=\"inpprice2\" type=\"text\" id=\"modifyslusdprice\" onkeyup=\"ResetModifySLUSD()\" "+slus+" placeholder=\"USD if price go down to ..\"> or <br>";
  con += "	            <input class=\"inpprice2\" type=\"text\" id=\"modifyslusdvalue\" onkeyup=\"ResetModifySLUSDW()\" "+slw+" placeholder=\"If value go down to..USD\"> or <br>";
  con += "	            <input class=\"inpprice2\" type=\"text\" id=\"modifyslbtcprice\" onkeyup=\"ResetModifySLBTC()\" "+slb+" placeholder=\"BTC if price reach ..\">";
  con += "	 </p>";
  con += " </div>";
 
  con += "<span class=\"clearfloat\">&nbsp;</span>";
  con += "<button class=\"modifypending\" onclick=\"ModifyTraderequests('"+id+"','"+priceusd+"','"+pricebtc+"','"+vusd+"','"+vbtc+"','"+vcoin+"','"+tusd+"','"+tw+"','"+tbtc+"','"+susd+"','"+sw+"','"+sbtc+"')\">Modify Pendingorder</button>";
  con += "<button class=\"deletepending\" onclick=\"DeleteTraderequest('"+id+"')\">Delete Pendingorder</button>";
  con += "<span class=\"clearfloat\">&nbsp;</span>";
  }
  //--
  document.getElementById("modifycontent").innerHTML = con;
  con  = "Modify Pendingorder Formular";
  con += "<span class=\"close\" onclick=\"document.getElementById('id02').style.display='none'\">&times;</span>";
  con += "<span class=\"valid\" id=\"valid2\">Saved</span>";
  con += "<span class=\"valid\" id=\"valid3\">Sended</span>";
  con += "<span class=\"valid\" id=\"deleted2\">Deleted</span>";
  document.getElementById("modifyformtitle").innerHTML = con;
  document.getElementById('id02').style.display='block'; 
  console.log(id+"   "+nam+" ("+sym+")");
}



var BTCPrice = new Object;
function ModifyTraderequests(id,priceusd,pricebtc,vusd,vbtc,vcoin,tusd,tw,tbtc,susd,sw,sbtc)
{
  var xhttpa = new XMLHttpRequest();
  priceusd=document.getElementById("modifyusdlimitprice").value;
  pricebtc=document.getElementById("modifybtclimitprice").value;
  vusd=document.getElementById("modifyusdamount").value;
  vbtc=document.getElementById("modifybtcamount").value;
  vcoin=document.getElementById("modifycoinamount").value;
  tusd=document.getElementById("modifytpusdprice").value;
  tw=document.getElementById("modifytpusdvalue").value;
  tbtc=document.getElementById("modifytpbtcprice").value;
  susd=document.getElementById("modifyslusdprice").value;
  sw=document.getElementById("modifyslusdvalue").value;
  sbtc=document.getElementById("modifyslbtcprice").value;
  
  //--
  var btcpricemysql=0;
  if(vbtc>0)btcpricemysql=vbtc;
  else
  if(vusd>0)
    {
	  var xhttp1 = new XMLHttpRequest();
	  xhttp1.onreadystatechange = function() 
	  {
		if(this.readyState == 4 && this.status == 200)
		{
		   var filestr=this.responseText;
		   if(isJson(filestr)==true)
		   {
			 BTCPrice = JSON.parse(filestr);
			 var anzahlbtcpreise=BTCPrice.length;
			 var lstbtcprice=0;
			 for(var i=0; i<anzahlbtcpreise; i++){if(BTCPrice[i].symbol=="BTCUSDT"){lstbtcprice=BTCPrice[i].bidPrice; break;}}
			 btcpricemysql=vusd/lstbtcprice;
             
			 var xhttp2 = new XMLHttpRequest();
			  xhttp2.onreadystatechange = function() 
			  {
				if (this.readyState == 4 && this.status == 200) 
				   {
					 var res=this.responseText;
					 console.log(this.responseText);
					 if(res=="updated")
					 {
					  TradingAccounts();
					  document.getElementById('valid2').className = 'validshow';
					  setTimeout(function(){ DeleteShowValid(); }, 1500);
					  PaginationOrd();
					 }
				   }
			  };
			  xhttp2.open("GET", "ModifyTrade.php?update=1&id="+id+"&limitusdprice="+priceusd+"&limitbtcprice="+pricebtc+"&volumeusd="+vusd+"&volumebtc="+vbtc+"&volumecoin="+vcoin+"&tpusdprice="+tusd+"&tpusdvalue="+tw+"&tpbtcprice="+tbtc+"&slusdprice="+susd+"&slusdvalue="+sw+"&slbtcprice="+sbtc+"&btcpricemysql="+btcpricemysql, true);
			  xhttp2.send();
			  //--
		   }
		 }
	   };
	   xhttp1.open("GET", "BinanceTicker.txt", true);
	   xhttp1.send();
	}
  //--
  xhttpa.onreadystatechange = function() 
  {
    if (this.readyState == 4 && this.status == 200) 
       {
		 var res=this.responseText;
		 console.log(this.responseText);
		 if(res=="updated")
		 {
		  TradingAccounts();
   		  document.getElementById('valid2').className = 'validshow';
		  setTimeout(function(){ DeleteShowValid(); }, 1500);
		  PaginationOrd();
		 }
       }
  };
  xhttpa.open("GET", "ModifyTrade.php?update=1&id="+id+"&limitusdprice="+priceusd+"&limitbtcprice="+pricebtc+"&volumeusd="+vusd+"&volumebtc="+vbtc+"&volumecoin="+vcoin+"&tpusdprice="+tusd+"&tpusdvalue="+tw+"&tpbtcprice="+tbtc+"&slusdprice="+susd+"&slusdvalue="+sw+"&slbtcprice="+sbtc+"&btcpricemysql="+btcpricemysql, true);
  xhttpa.send();	
}

function DeleteTraderequest(id, v1="leer")
{
  var xhttpa = new XMLHttpRequest();
  xhttpa.onreadystatechange = function() 
  {
    if (this.readyState == 4 && this.status == 200) 
       {
		 var res=this.responseText;
		 console.log(this.responseText);
		 if(res=="deleted")
		 {
		  TradingAccounts();
   		  document.getElementById('deleted2').className = 'validshow';
		  setTimeout(function(){ DeletedShowValid(); }, 1500);
		  PaginationOrd();
		 }
       }
  };
  xhttpa.open("GET", "ModifyTrade.php?delete=1&id="+id+"&v1="+v1, true);
  xhttpa.send();	
}

function DeletePendingOrder(id, broker, nam="leer", priceeinh="leer")
{
  var xhttpa = new XMLHttpRequest();
  xhttpa.onreadystatechange = function() 
  {
    if (this.readyState == 4 && this.status == 200) 
       {
		 var res=this.responseText;
		 console.log(this.responseText);
		 if(res=="Successful")
		 {
		  TradingAccounts();
   		  document.getElementById('valid3').className = 'validshow';
		  setTimeout(function(){ DeleteShowValid(); }, 1500);
		  PaginationOrd();
		 }
       }
  };
  xhttpa.open("GET", "ExchangesApis.php?DeletePending="+id+"&broker="+broker+"&nam="+nam+"&priceeinh="+priceeinh, true);
  xhttpa.send();
}

function ResetModifyTPUSD()
{
document.getElementById("modifytpusdvalue").value="";
document.getElementById("modifytpbtcprice").value="";	
}
function ResetModifyTPUSDW()
{
document.getElementById("modifytpusdprice").value="";
document.getElementById("modifytpbtcprice").value="";	
}
function ResetModifyTPBTC()
{
document.getElementById("modifytpusdvalue").value="";
document.getElementById("modifytpusdprice").value="";	
}
function ResetModifySLUSD()
{
document.getElementById("modifyslusdvalue").value="";
document.getElementById("modifyslbtcprice").value="";	
}
function ResetModifySLUSDW()
{
document.getElementById("modifyslusdprice").value="";
document.getElementById("modifyslbtcprice").value="";	
}
function ResetModifySLBTC()
{
document.getElementById("modifyslusdvalue").value="";
document.getElementById("modifyslusdprice").value="";	
}
function ResetModifyEntryUSD()
{
document.getElementById("modifybtclimitprice").value="";
}
function ResetModifyEntryBTC()
{
document.getElementById("modifyusdlimitprice").value="";
}
function ResetModifyCostUSD()
{
document.getElementById("modifybtcamount").value="";
document.getElementById("modifycoinamount").value="";
}
function ResetModifyCostBTC()
{
document.getElementById("modifyusdamount").value="";
document.getElementById("modifycoinamount").value="";
}
function ResetModifyCostCoin()
{
document.getElementById("modifyusdamount").value="";
document.getElementById("modifybtcamount").value="";
}






















function ModifyBuyAndHold(id, broker, symbol, coin, volumebtc, volumeusd, volumecoin, buyholdpercent, tpbtcprice, tpusdprice, tpusdvalue, slbtcprice, slusdprice, slusdvalue, tpsltraded)
{
  var con="";
  var tpusdpricevalue=""; var tpusdwinvalue=""; var tpbtpricevalue="";
  var slusdpricevalue=""; var slusdwinvalue=""; var slbtpricevalue="";
  var vlusdpricevalue=""; var vlucoinvalue=""; var vlbtpricevalue="";
  var percentvalue="value=\""+buyholdpercent+"\"";
  var vol=""; var voleinh="";if(volumebtc>0){vol=volumebtc;voleinh="BTC"; vlbtpricevalue="value=\""+volumebtc+"\"";} else if(volumeusd>0){vol=volumeusd;voleinh="USD";vlusdpricevalue="value=\""+volumeusd+"\""; } else if(volumecoin>0){vol=volumecoin;voleinh=symbol;vlucoinvalue="value=\""+volumecoin+"\"";}
  var tp=""; var tpeinh="";if(tpbtcprice>0){tp=tpbtcprice; tpeinh="BTC price"; tpbtpricevalue="value=\""+tpbtcprice+"\"";} else if(tpusdprice>0){tp=tpusdprice;tpeinh="USD price"; tpusdpricevalue="value=\""+tpusdprice+"\"";} else if(tpusdvalue>0){tp=tpusdvalue;tpeinh="win in USD"; tpusdwinvalue="value=\""+tpusdvalue+"\"";}
  var sl=""; var sleinh="";if(slbtcprice>0){sl=slbtcprice;sleinh="BTC price"; slbtpricevalue="value=\""+slbtcprice+"\"";} else if(slusdprice>0){sl=slusdprice;sleinh="USD price"; slusdpricevalue="value=\""+slusdprice+"\"";} else if(slusdvalue>0){sl=slusdvalue;sleinh="win in USD"; slusdwinvalue="value=\""+slusdvalue+"\"";}

  con += "<div style=\"font-size:17px\">";
  con += "<p id=\"modifysymbol\"><b>Symbol:</b> "+coin+" ("+symbol+")</p>";
  con += "<p id=\"modifybroker\"><b>Broker:</b> "+broker+"</p>";
  con += "<p id=\"modifytype\"><b>Type:</b> Buy And Hold</p>";
  con += "<p id=\"modifytype\"><b>Difference in %:</b> "+buyholdpercent+"</p>";
  con += "<p id=\"modifyvolumme\"><b>Volume:</b> "+vol+" "+voleinh+"</p>";
  con += "<p id=\"modifytp\"><b>Takeprofit:</b> "+tp+" "+tpeinh+"</p>";
  con += "<p id=\"modifysl\"><b>Stoploss:</b> "+sl+" "+sleinh+"</p>";
  con += "</div>";

  if(tpsltraded==1) con += "<p style=\"font-size:19px;margin:15px 0 0 0;\">This trade have been close at takeprofit. Delete this traderequest with the button below, then you can open a new one in the same crypto currency pair.</p>";
  if(tpsltraded==2) con += "<p style=\"font-size:19px;margin:15px 0 0 0;\">This trade have been close at stoploss. Delete this traderequest with the button below, then you can open a new one in the same crypto currency pair.</p>";
  if(tpsltraded==0)
  {
  con += "  <div style=\"float:left;margin:15px 0 5px 0px;border:1px solid #8ae9f2;background:#daf0f2;width:49%;border-radius:10px;\">";
  con += "	<p class=\"selectTraceUeber\">Change Entry Rules</p>";
  con += "	<p style=\"margin:10px;font-size: 19px;\">";
  con += "	Difference in %<br>";
  con += "	<input class=\"inpprice2\" type=\"text\"  id=\"modifypercentbh\" placeholder=\"If price move ..% new trade\" "+percentvalue+"> or";
  con += "	<br><br>";
  con += "	Volume: <br><input class=\"inpprice2\" type=\"text\" id=\"modifyusdamountbh\" placeholder=\"USD Value..\" "+vlusdpricevalue+" onkeyup=\"ResetModifyCostUSDBH()\"> or <br>";
  con += "	                <input class=\"inpprice2\" type=\"text\" id=\"modifybtcamountbh\" placeholder=\"BTC Value..\" "+vlbtpricevalue+" onkeyup=\"ResetModifyCostBTCBH()\"> or <br>";
  con += "	                <input class=\"inpprice2\" type=\"text\" id=\"modifycoinamountbh\" placeholder=\""+symbol+" Value..\" "+vlucoinvalue+" onkeyup=\"ResetModifyCostCoinBH()\">";
  con += "	<span id=\"modifycost\"></span>";
  con += "	</p>";
  con += "</div>";

  con += "  <div style=\"float:right;margin:15px 0 5px 0px;border:1px solid #8ae9f2;background:#daf0f2;width:49%;border-radius:10px;\">";
  con += "	<p class=\"selectTraceUeber\">Change Exit Rules</p>";
  con += "	<p style=\"margin:10px;font-size: 19px;\">";
  con += "	  Takeprofit: <br>";
  con += "	              <input class=\"inpprice2\" type=\"text\" id=\"modifytpusdpricebh\" onkeyup=\"ResetModifyTPUSDBH()\" "+tpusdpricevalue+" placeholder=\"USD if price go up to ..\"> or <br>";
  con += "	              <input class=\"inpprice2\" type=\"text\" id=\"modifytpusdvaluebh\"  onkeyup=\"ResetModifyTPUSDWBH()\" "+tpusdwinvalue+" placeholder=\"If value go up to..USD\"> or <br>";
  con += "	              <input class=\"inpprice2\" type=\"text\" id=\"modifytpbtcpricebh\" onkeyup=\"ResetModifyTPBTCBH()\"  "+tpbtpricevalue+" placeholder=\"BTC if price reach ..\"> <br><br>";

  con += "	  Stoploss: <br>";
  con += "	            <input class=\"inpprice2\" type=\"text\" id=\"modifyslusdpricebh\" onkeyup=\"ResetModifySLUSDBH()\" "+slusdpricevalue+" placeholder=\"USD if price go down to ..\"> or <br>";
  con += "	            <input class=\"inpprice2\" type=\"text\" id=\"modifyslusdvaluebh\" onkeyup=\"ResetModifySLUSDWBH()\" "+slusdwinvalue+" placeholder=\"If value go down to..USD\"> or <br>";
  con += "	            <input class=\"inpprice2\" type=\"text\" id=\"modifyslbtcpricebh\" onkeyup=\"ResetModifySLBTCBH()\" "+slbtpricevalue+" placeholder=\"BTC if price reach ..\">";
  con += "	 </p>";
  con += " </div>";
  }
  con += "<span class=\"clearfloat\">&nbsp;</span>";
  if(tpsltraded==0)
  {
	  con += "<button class=\"modifypending\" onclick=\"ModifyTraderequestsBH('"+id+"')\">Modify Buy And Hold</button>";
      con += "<button class=\"deletepending\" onclick=\"DeleteTraderequestBH('"+id+"')\">Delete Buy And Hold</button>";
  }
  else
  {
	  con += "<button class=\"deletepending\" style=\"width:100%;\" onclick=\"DeleteTraderequestBH('"+id+"')\">Delete Buy And Hold</button>";
  }
  con += "<span class=\"clearfloat\">&nbsp;</span>";
  
  //--
  document.getElementById("modifycontent").innerHTML = con;
  con  = "Modify Buy And Hold Formular";
  con += "<span class=\"close\" onclick=\"document.getElementById('id02').style.display='none'\">&times;</span>";
  con += "<span class=\"valid\" id=\"valid2\">Saved</span>";
  con += "<span class=\"valid\" id=\"valid3\">Sended</span>";
  con += "<span class=\"valid\" id=\"deleted2\">Deleted</span>";
  document.getElementById("modifyformtitle").innerHTML = con;
  document.getElementById('id02').style.display='block'; 
}






function ModifyTraderequestsBH(id)
{
  var xhttpa = new XMLHttpRequest();
  buyholdpercent=document.getElementById("modifypercentbh").value;
  vusd=document.getElementById("modifyusdamountbh").value;
  vbtc=document.getElementById("modifybtcamountbh").value;
  vcoin=document.getElementById("modifycoinamountbh").value;
  tusd=document.getElementById("modifytpusdpricebh").value;
  tw=document.getElementById("modifytpusdvaluebh").value;
  tbtc=document.getElementById("modifytpbtcpricebh").value;
  susd=document.getElementById("modifyslusdpricebh").value;
  sw=document.getElementById("modifyslusdvaluebh").value;
  sbtc=document.getElementById("modifyslbtcpricebh").value;
  //--
  var btcpricemysql=0;
  if(vbtc>0)btcpricemysql=vbtc;
  else
  if(vusd>0)
    {
	  var xhttp1 = new XMLHttpRequest();
	  xhttp1.onreadystatechange = function() 
	  {
		if(this.readyState == 4 && this.status == 200)
		{
		   var filestr=this.responseText;
		   if(isJson(filestr)==true)
		   {
			 BTCPrice = JSON.parse(filestr);
			 var lstbtcprice=BTCPrice.USDT_BTC.last;
			 btcpricemysql=vusd/lstbtcprice;
			 var xhttp2 = new XMLHttpRequest();
			 xhttp2.onreadystatechange = function() 
			 {
				if (this.readyState == 4 && this.status == 200) 
				   {
					 var res=this.responseText;
					 console.log(this.responseText);
					 if(res=="updated")
					 {
					  document.getElementById('valid2').className = 'validshow';
					  setTimeout(function(){ DeleteShowValid(); }, 1500);
					  ShowBuyAndHoldEntrys();
					 }
				   }
			 };
			 xhttp2.open("GET", "ModifyTrade.php?buyhold=1&update=1&id="+id+"&buyholdpercent="+buyholdpercent+"&volumeusd="+vusd+"&volumebtc="+vbtc+"&volumecoin="+vcoin+"&tpusdprice="+tusd+"&tpusdvalue="+tw+"&tpbtcprice="+tbtc+"&slusdprice="+susd+"&slusdvalue="+sw+"&slbtcprice="+sbtc+"&btcpricemysql="+btcpricemysql, true);
             xhttp2.send();
			 //--
		   }
		 }
	   };
	   xhttp1.open("GET", "BinanceTicker.txt", true);
	   xhttp1.send();
	}
  //--
  xhttpa.onreadystatechange = function() 
  {
    if (this.readyState == 4 && this.status == 200) 
       {
		 var res=this.responseText;
		 console.log("BuyHoldModifySave: "+this.responseText);
		 if(res=="updated")
		 {
		  document.getElementById('valid2').className = 'validshow';
		  setTimeout(function(){ DeleteShowValid(); }, 1500);
		  ShowBuyAndHoldEntrys();
		 }
       }
  };
  xhttpa.open("GET", "ModifyTrade.php?buyhold=1&update=1&id="+id+"&buyholdpercent="+buyholdpercent+"&volumeusd="+vusd+"&volumebtc="+vbtc+"&volumecoin="+vcoin+"&tpusdprice="+tusd+"&tpusdvalue="+tw+"&tpbtcprice="+tbtc+"&slusdprice="+susd+"&slusdvalue="+sw+"&slbtcprice="+sbtc+"&btcpricemysql="+btcpricemysql, true);
  xhttpa.send();	
}


function DeleteTraderequestBH(id)
{
  var xhttpa = new XMLHttpRequest();
  xhttpa.onreadystatechange = function() 
  {
    if (this.readyState == 4 && this.status == 200) 
       {
		 var res=this.responseText;
		 console.log(this.responseText);
		 if(res=="deleted")
		 {
		  document.getElementById('deleted2').className = 'validshow';
		  setTimeout(function(){ DeletedShowValid(); }, 1500);
		  ShowBuyAndHoldEntrys();
		 }
       }
  };
  xhttpa.open("GET", "ModifyTrade.php?delete=1&id="+id, true);
  xhttpa.send();	
}

function ResetModifyTPUSDBH()
{
document.getElementById("modifytpusdvaluebh").value="";
document.getElementById("modifytpbtcpricebh").value="";	
}
function ResetModifyTPUSDWBH()
{
document.getElementById("modifytpusdpricebh").value="";
document.getElementById("modifytpbtcpricebh").value="";	
}
function ResetModifyTPBTCBH()
{
document.getElementById("modifytpusdvaluebh").value="";
document.getElementById("modifytpusdpricebh").value="";	
}
function ResetModifySLUSDBH()
{
document.getElementById("modifyslusdvaluebh").value="";
document.getElementById("modifyslbtcpricebh").value="";	
}
function ResetModifySLUSDWBH()
{
document.getElementById("modifyslusdpricebh").value="";
document.getElementById("modifyslbtcpricebh").value="";	
}
function ResetModifySLBTCBH()
{
document.getElementById("modifyslusdvaluebh").value="";
document.getElementById("modifyslusdpricebh").value="";	
}
function ResetModifyCostUSDBH()
{
document.getElementById("modifybtcamountbh").value="";
document.getElementById("modifycoinamountbh").value="";
}
function ResetModifyCostBTCBH()
{
document.getElementById("modifyusdamountbh").value="";
document.getElementById("modifycoinamountbh").value="";
}
function ResetModifyCostCoinBH()
{
document.getElementById("modifyusdamountbh").value="";
document.getElementById("modifybtcamountbh").value="";
}



//--
var PaginationSeite2=1;
//--
function Pagination2(v1)
{
  var maxpages2=1;
  if(document.getElementById("maxpages2"))maxpages2=document.getElementById("maxpages2").innerHTML;
  if(v1=="plus")PaginationSeite2++;
  else
  if(v1=="minus")PaginationSeite2--;
  if(PaginationSeite2<1)PaginationSeite2=1;
  if(PaginationSeite2>maxpages2)PaginationSeite2=maxpages2;
  ShowBuyAndHoldEntrys();
}
//--
function ShowBuyAndHoldEntrys()
{
  var xhttpa = new XMLHttpRequest();
  xhttpa.onreadystatechange = function() 
  {
    if (this.readyState == 4 && this.status == 200) 
       {
		 var res=this.responseText;
		 document.getElementById("buyandholdinhalt").innerHTML = res;
       }
  };
  xhttpa.open("GET", "ReadTrade.php?ReadBuyandHold=1&PaginationSeite2="+PaginationSeite2, true);
  xhttpa.send();
}
</script>



<style>
</style>
</head>
<body onresize="drawVisualization()" onload="OnLoadFunktion()" id="bodytag">



<div id="exchangesbrokers" style="display:none"></div>

<div id="id02" class="modal2">
<div class="modal2-content2 animate2">
   <p id="modifyformtitle">&nbsp;</p>
<div style="padding:15px" id="modifycontent">
</div>  
</div>
</div>












<div class="Feld1_Signale" id="signals">
<div id="loader">&nbsp;</div>
<h1 class="Kategorie1_Ueberschrift">Signals/Charts 
  
	  <span class="abos" onclick="ShowAbonnementBox()">&nbsp;</span>

      <span class="signalsbutton" onclick="ShowSignalsBox('save')">
		 <span class="signalsbuttontext" id="AnzahlSignale">&nbsp;</span>
	   </span> 
	   
	  <span class="play" onclick="ClickPlayPause()" id="playpausebutton">&nbsp;</span>

	  <span class="searchform"><input type="text" id="myInput" onkeyup="ShowSearchResults()" placeholder="Coin/Token">
		<span class="serachboxresults" id="serachoutput">&nbsp;</span>
	  </span>

	  <button class="tradepanelbutton" onclick="OpenTradePanel()">Trade</button>
	  
	  <span id="logo">&nbsp;</span>
	  
	  <span class="BigDisplayButton" onclick="BigDisplaySignals(this.id)" id="BigDisplayButtonSignal">&nbsp;</span>
</h1>

<div id="Abonnementbox">
    <h2 class="AbonnementUb">Subscribed Signals</h2>
    <div id="AbonnementboxEntrys">&nbsp;</div>
    <span class="clearfloat">&nbsp;</span>
</div>
  
<div class="signalsbox" id="Signalbox">
    <h2 class="Kategorie2_Uberschrift">Current Signals</h2>
    <p class="signalescoll" id="style3">&nbsp;</p>
    <div id="cmcinfos">&nbsp;</div>
    <span class="clearfloat">&nbsp;</span>
</div>

<div class="chartbox" id="ChartBox">
    <span id="coinname">&nbsp;</span>
    <span id="timeframes_span">&nbsp;</span>
    <b>Marketcap:</b> <span id="marketcap"></span> &nbsp;<b>Change (7d):</b> <span id="change"></span> &nbsp;<b>Price:</b> <span id="price"></span>
    <div id="chart_div">&nbsp;</div>
    <span class="clearfloat">&nbsp;</span>
</div>
<span class="clearfloat">&nbsp;</span>
</div>









<div id="trading">
<h1 class="Kategorie1_Ueberschrift">Trading/Account
    <span class="historybutton" onclick="ShowHistory()"></span>
    <span class="accountsbutton" onclick="window.open('addexchange.php');"></span>
    <span id="tradehistorybox">
	    <span class="tradehistoryboxub">Traderequest List</span>
		<span id="tradehistoryboxlist">
	    </span>
    </span>
	<span class="BigDisplayButton" onclick="BigDisplaySignals(this.id)" id="BigDisplayButtonTrading">&nbsp;</span>
</h1>


<div id="marketbrokers">
	<p class="brokertab" id="Binancebroker">
        <span class="brokertab2" id="BinancebrokerUB" onclick="OpenBrokerTab(this.id)">Binance   <span class="balancesanzahl" id="anzahlbinance">&nbsp;</span></span>
		<span class="tabcont">
			<span class="balancelistbox" style="margin:0.9% 0 0 0">
			  <span class="balanceub">Balances
			  <span class="balancepage" id="Binancepagenav"></span>
			  </span>
			  <span class="balancelistinhalt" id="BinanceBalancesList">
			  </span>
			</span>
			
			<span class="balancelistbox" style="margin:3% 0 0 0">
			  <span class="balanceub">Pendingorders
			  <span class="balancepage" id="Binancepagenav2"></span>
			  </span>
			  <span class="balancelistinhalt" id="BinanceOrdersList">
			  </span>
			</span>
		</span>
    </p>
</div>
<span class="clearfloat">&nbsp;</span>
</div>










<div id="buyhold">
<h1 class="Kategorie1_Ueberschrift">Buy And Hold Portfolio
  <span class="BigDisplayButton" onclick="BigDisplaySignals(this.id)" id="BigDisplayButtonBuyHold">&nbsp;</span>
</h1>
<div id="buyandholdinhalt">&nbsp;</div>
<span class="clearfloat">&nbsp;</span>
</div>

<p style="clear:both;display:none;" id="ad"></p>







<div id="id01" class="modal">
<div class="modal-content animate">

   <p id="TradepanelUb">Trading Formular<span class="close" onclick="document.getElementById('id01').style.display='none'">&times;</span>
    <span class="valid" id="valid">Saved</span>
    <span class="novalid" id="novalid">Please select a tradevolume</span>
    <span class="valid" id="deleted">Deleted</span>
   </p>
   <p style="margin:20px"><span style="font-size:19px;font-weight:bold;">Currency:</span> <span class="searchform2"><input type="text" id="myInput2" onkeyup="ShowSearchResults2()" onchange="TradePanelCoinChange()">
                  <span class="serachboxresults2" id="serachoutput2"></span>
                </span>
   </p>

	<div class="tab">
	  <button class="tablinks" onclick="openTab(event, 'Market')" id="defaultOpen">Market</button>
	  <button class="tablinks" onclick="openTab(event, 'Signal')" id="SignalButton">Signal</button>
	  <button class="tablinks" onclick="openTab(event, 'BuyAndHold')" id="BuyHoldButton">Buy And Hold</button>
	</div>

	<div id="Market" class="tabcontent">


		<div class="tradepanelbox1">
			<p class="selectTraceUeber">Select a Exchange
			  <span class="selectexchangessetting" onclick="window.open('addexchange.php');">&nbsp;</span>
			</p>
			<div id="MarketShowexchanges"></div>
		</div>

		<div class="tradepanelbox2">
			<p class="selectTraceUeber">Select Entry Rules</p>
			<p style="margin:10px;font-size: 19px;">
			 <label class="container">Market Price
				<input class="inputcheck" id="mrprice" onclick="ResetCheckboxesEntryPrice('mrprice')" type="checkbox">
				<span class="checkmark"></span>
			  </label>
			  <label class="container">Limit Price
				<input class="inputcheck" id="mrlimit" onclick="ResetCheckboxesEntryPrice('mrlimit')" type="checkbox">
				<span class="checkmark"></span>
				<br><input class="inpprice" type="text"  id="usdlimitprice" placeholder="" onkeyup="CalculateCostLimitUSD()"> or <br>
				<input class="inpprice" type="text" id="btclimitprice" placeholder="" onkeyup="CalculateCostLimitBTC()">
			  </label>
			  Volume: <br><input class="inpprice" type="text" id="usdamount" placeholder="" onkeyup="CalculateCostUSD()"> or <br>
								   <input class="inpprice" type="text" id="btcamount" placeholder="" onkeyup="CalculateCostBTC()"> or <br>
								   <input class="inpprice" type="text" id="coinamount" placeholder="" onkeyup="CalculateCostCoin()">
			  <span id="cost"></span>
			</p>
		</div>

		<div class="tradepanelbox3">
			<p class="selectTraceUeber">Select Exit Rules</p>
			<p style="margin:10px;font-size: 19px;">
			
			  Takeprofit: <br><input class="inpprice" type="text" id="tpusdprice" onkeyup="ResetTP('tpusdprice')" placeholder=""> or <br>
						  <input class="inpprice" type="text" id="tpusdvalue"  onkeyup="ResetTP('tpusdvalue')" placeholder=""> or <br>
						  <input class="inpprice" type="text" id="tpbtcprice" onkeyup="ResetTP('tpbtcprice')"  placeholder=""> <br><br>
						  
			  Stoploss: <br><input class="inpprice" type="text" id="slusdprice" onkeyup="ResetSL('slusdprice')" placeholder=""> or <br>
						<input class="inpprice" type="text" id="slusdvalue" onkeyup="ResetSL('slusdvalue')" placeholder=""> or <br>
						<input class="inpprice" type="text" id="slbtcprice" onkeyup="ResetSL('slbtcprice')" placeholder="">
			 </p>
		</div>

		<span class="clearfloat">&nbsp;</span>
		<p style="margin:20px 0 0 0"><button class="buy" onclick="TradeMarket('buy')">Buy <span class="signalsymbol2"></span></button>
									<button class="sell" onclick="TradeMarket('sell')">Sell <span class="signalsymbol2"></span></button></p>
									<p style="display:none" id="btcpricehidden"></p>
									<p style="display:none" id="usdpricehidden"></p>
	</div>




	<div id="Signal" class="tabcontent">
		<div class="tradepanelbox1">
			<p class="selectTraceUeber">Select a Exchange
			  <span class="selectexchangessetting" onclick="window.open('addexchange.php');">&nbsp;</span>
			</p>
			<div id="SignalShowexchanges"></div>
		</div>

		

		<div class="tradepanelbox2">
			<p class="selectTraceUeber">Select Entry Rules</p>
			<p style="margin:10px;font-size: 19px;">
			 <label class="container">Only Buy Signals
				<input class="inputcheck" id="onlybuy" onclick="ResetCheckboxesSignalEntry('buy')" type="checkbox">
				<span class="checkmark"></span>
			  </label>
			  <label class="container">Only Sell Signals
				<input class="inputcheck" id="onlysell" onclick="ResetCheckboxesSignalEntry('sell')" type="checkbox">
				<span class="checkmark"></span>
			  </label>
			  <label class="container">Buy and Sell Signals
				<input class="inputcheck" id="buyandsell" onclick="ResetCheckboxesSignalEntry('buyandsell')" type="checkbox">
				<span class="checkmark"></span>
			  </label>
			  <br>
			  Volume: <br><input class="inpprice" type="text" id="usdamountsg" value="" placeholder="" onkeyup="ResetCheckboxesSignalEntry('usd')"> or <br>
								   <input class="inpprice" type="text" id="btcamountsg" value="" placeholder="" onkeyup="ResetCheckboxesSignalEntry('btc')"> or <br>
								   <input class="inpprice" type="text" id="coinamountsg" placeholder="" onkeyup="ResetCheckboxesSignalEntry('coin')">
			<span id="cost2"></span>
			</p>
		</div>

		<div class="tradepanelbox3">
			<p class="selectTraceUeber">Select Exit Rules</p>
			<p style="margin:10px;font-size: 19px;">
			
			  Takeprofit: <br><input class="inpprice" type="text" id="tpusdpricesg" value="" onkeyup="ResetCheckboxesSignalEntry('tpusdpricesg')" placeholder=""> or <br>
						  <input class="inpprice" type="text" id="tpusdvaluesg"  value="" onkeyup="ResetCheckboxesSignalEntry('tpusdvaluesg')" placeholder=""> or <br>
						  <input class="inpprice" type="text" id="tpbtcpricesg" value="" onkeyup="ResetCheckboxesSignalEntry('tpbtcpricesg')"  placeholder=""> <br><br>
						  
			  Stoploss: <br><input class="inpprice" type="text" id="slusdpricesg" value="" onkeyup="ResetCheckboxesSignalEntry('slusdpricesg')" placeholder=""> or <br>
						<input class="inpprice" type="text" id="slusdvaluesg" value="" onkeyup="ResetCheckboxesSignalEntry('slusdvaluesg')" placeholder=""> or <br>
						<input class="inpprice" type="text" id="slbtcpricesg" value="" onkeyup="ResetCheckboxesSignalEntry('slbtcpricesg')" placeholder="">
			 </p>
		</div>

		<span class="clearfloat">&nbsp;</span>
		<p style="margin:20px 0 0 0" id="tradesignal"><button class="buy2" onclick="TradeMarket('signal')">Trade Signals On <span class="signalsymbol2"></span></button></p>
		<p style="margin:20px 0 0 0" id="modifysignal"><button class="buy" onclick="TradeMarket('signal')">Modify Signals On <span class="signalsymbol2"></span></button>
														 <button class="delete" onclick="DeleteTraderequests('Signal')">Delete Signals On <span class="signalsymbol2"></span></button></p>
	</div>







	<div id="BuyAndHold" class="tabcontent">
		<div class="tradepanelbox1">
			<p class="selectTraceUeber">Select a Exchange
			  <span class="selectexchangessetting" onclick="window.open('addexchange.php');">&nbsp;</span>
			</p>
			<div id="BuyAndHoldShowexchanges"></div>
		</div>

		<div class="tradepanelbox2">
			<p class="selectTraceUeber">Select Entry Rules</p>
			<p style="margin:10px;font-size: 19px;">
			  Distance in %: <br><input class="inpprice" type="text" id="buyholddistance"  value="" placeholder="If price move ..% new trade">
			  <br><br> 
			  Maxtrades: <br><input class="inpprice" type="text" id="maxtradesbh"  value="" placeholder="Maximal .. new trades">
			  <br><br>
			  <label class="container">Buysignal Entry
				<input class="inputcheck" id="signalentrybh" onclick="ResetCheckboxesBuyHoldEntry('signalentry')" type="checkbox">
				<span class="checkmark"></span>
			  </label>
			  <br>
			  Volume: <br><input class="inpprice" type="text" id="usdamountbh"  value="" placeholder="" onkeyup="ResetCheckboxesBuyHoldEntry('usd')"> or <br>
								   <input class="inpprice" type="text" id="btcamountbh"  value="" placeholder="" onkeyup="ResetCheckboxesBuyHoldEntry('btc')"> or <br>
								   <input class="inpprice" type="text" id="coinamountbh"  value="" placeholder="" onkeyup="ResetCheckboxesBuyHoldEntry('coin')">
			<span id="cost3"></span>
			</p>
		</div>

		<div class="tradepanelbox3">
			<p class="selectTraceUeber">Select Exit Rules</p>
			<p style="margin:10px;font-size: 19px;">
			
			  Takeprofit: <br><input class="inpprice" type="text" id="tpusdpricebh" onkeyup="ResetCheckboxesBuyHoldEntry('tpusdpricebh')"  value="" placeholder=""> or <br>
						  <input class="inpprice" type="text" id="tpusdvaluebh"  onkeyup="ResetCheckboxesBuyHoldEntry('tpusdvaluebh')"  value="" placeholder=""> or <br>
						  <input class="inpprice" type="text" id="tpbtcpricebh" onkeyup="ResetCheckboxesBuyHoldEntry('tpbtcpricebh')"  value="" placeholder=""> <br><br>
						  
			  Stoploss: <br><input class="inpprice" type="text" id="slusdpricebh" onkeyup="ResetCheckboxesBuyHoldEntry('slusdpricebh')"  value="" placeholder=""> or <br>
						<input class="inpprice" type="text" id="slusdvaluebh" onkeyup="ResetCheckboxesBuyHoldEntry('slusdvaluebh')"  value="" placeholder=""> or <br>
						<input class="inpprice" type="text" id="slbtcpricebh" onkeyup="ResetCheckboxesBuyHoldEntry('slbtcpricebh')"  value="" placeholder="">
			 </p>
		</div>

		<span class="clearfloat">&nbsp;</span>
		<p style="margin:20px 0 0 0" id="tradebuyhold"><button class="buy2" onclick="TradeMarket('buyandhold')">Buy and Hold <span class="signalsymbol2"></span></button></p>
		<p style="margin:20px 0 0 0" id="modifybuyhold"><button class="buy" id="buyholdmodibuy" onclick="TradeMarket('buyandhold')">Modify Buy and Hold On <span class="signalsymbol2"></span></button>
														<button class="delete" id="buyholdmodibuy2"  onclick="DeleteTraderequests('Buyandhold')">Delete Buy and Hold On <span class="signalsymbol2"></span></button></p>
		<p style="margin:20px 0 0 0" id="resetbuyhold"><button class="delete2" onclick="DeleteTraderequests('Buyandhold')">TP/SL Reached, Delete And Reset Buy and Hold On <span class="signalsymbol2"></span></button></p>
														 <span class="clearfloat">&nbsp;</span>
	</div>










</div>
</div>


<script type="text/javascript">


function TradeMarket(v1)
{
 //--
 var market_orLimit="";
 var limitusdprice=0;
 var limitbtcprice=0;
 var volumeusd=0;
 var volumebtc=0;
 var volumecoin=0;
 //--
 var tpusdprice=0;
 var tpusdvalue=0;
 var tpbtcprice=0;
 //--
 var slusdprice=0;
 var slusdvalue=0;
 var slbtcprice=0;
 var buyholdpercent=0;
 var arbitragepercententry=0;
 var arbitragepercentexit=0;
 var brokersarbitrage="";
 var SignalEntryBH=0;
 var maxtrades=0;
 var LastBroker="";
 
 
 var strurl = "ReadTextFile.php?file=LastExchange.txt";
 var d = new Date();var timestemp = d.getTime();
 var readbroker = new XMLHttpRequest();
 readbroker.onreadystatechange = function() 
 {
 if(this.readyState == 4 && this.status == 200) 
 {
	 LastBroker=this.responseText;
 



	 
	 var typ="";
	 if(v1=="buy")typ="MarketBuy";
	 else
	 if(v1=="sell")typ="MarketSell";
	 else
	 if(v1=="signal")
	 {
	   if(document.getElementById("onlybuy").checked == true)typ="SignalBuy";
	   else
	   if(document.getElementById("onlysell").checked == true)typ="SignalSell";
	   else
	   if(document.getElementById("buyandsell").checked == true)typ="SignalBuyAndSell";
	 }
	 else if(v1=="buyandhold")
	 {
		 typ="BuyAndHold";
	 }

	 
	 
	 var Coinname = document.getElementById("myInput2").value;
	 var n = Coinname.indexOf(" (")-2;
	 var Coin = Coinname.substring(0, n);
	 
		 n = Coinname.indexOf(" (")+2;
	 var n2 = Coinname.indexOf(")");
	 var Symbol = Coinname.substring(n, n2);
	 

	 
	 
	 if(typ=="MarketBuy" || typ=="MarketSell")
	 {
		 market_orLimit="";
		 if(document.getElementById("mrprice").checked == true)market_orLimit="marketprice";
		 else 
		 if(document.getElementById("mrlimit").checked == true)market_orLimit="limitprice";
		 //--
		 limitusdprice=document.getElementById("usdlimitprice").value;
		 limitbtcprice=document.getElementById("btclimitprice").value;
		 volumeusd=document.getElementById("usdamount").value;
		 volumebtc=document.getElementById("btcamount").value;
		 volumecoin=document.getElementById("coinamount").value;
		 //--
		 tpusdprice=document.getElementById("tpusdprice").value;
		 tpusdvalue=document.getElementById("tpusdvalue").value;
		 tpbtcprice=document.getElementById("tpbtcprice").value;
		 //--
		 slusdprice=document.getElementById("slusdprice").value;
		 slusdvalue=document.getElementById("slusdvalue").value;
		 slbtcprice=document.getElementById("slbtcprice").value;
	 }
	 else if(v1=="signal")
	 {
		 SaveSignal=1;
		 market_orLimit="";
		 //--
		 limitusdprice="";
		 limitbtcprice="";
		 volumeusd=document.getElementById("usdamountsg").value;
		 volumebtc=document.getElementById("btcamountsg").value;
		 volumecoin=document.getElementById("coinamountsg").value;
		 //--
		 tpusdprice=document.getElementById("tpusdpricesg").value;
		 tpusdvalue=document.getElementById("tpusdvaluesg").value;
		 tpbtcprice=document.getElementById("tpbtcpricesg").value;
		 //--
		 slusdprice=document.getElementById("slusdpricesg").value;
		 slusdvalue=document.getElementById("slusdvaluesg").value;
		 slbtcprice=document.getElementById("slbtcpricesg").value;
	 }
	 else if(v1=="buyandhold")
	 {
		 buyholdpercent=document.getElementById("buyholddistance").value;
		 maxtrades=document.getElementById("maxtradesbh").value;
		 //--
		 market_orLimit="";
		 if(document.getElementById("signalentrybh").checked == true)SignalEntryBH=1;
		 //--
		 limitusdprice="";
		 limitbtcprice="";
		 volumeusd=document.getElementById("usdamountbh").value;
		 volumebtc=document.getElementById("btcamountbh").value;
		 volumecoin=document.getElementById("coinamountbh").value;
		 //--
		 tpusdprice=document.getElementById("tpusdpricebh").value;
		 tpusdvalue=document.getElementById("tpusdvaluebh").value;
		 tpbtcprice=document.getElementById("tpbtcpricebh").value;
		 //--
		 slusdprice=document.getElementById("slusdpricebh").value;
		 slusdvalue=document.getElementById("slusdvaluebh").value;
		 slbtcprice=document.getElementById("slbtcpricebh").value;
	 }

	 
	 
	 var BTCPreisMysql=0;
	 if(document.getElementsByClassName("BTCPreismysql")[0])BTCPreisMysql=document.getElementsByClassName("BTCPreismysql")[0].innerHTML;
	 console.log("buybroker "+LastBroker+"  BTCPreisMysql "+BTCPreisMysql); 


	 
	 strurl="SaveTrade.php?typ="+typ+"&broker="+LastBroker+"&symbol="+Symbol+"&coin="+Coin+"&market_orLimit="+market_orLimit+"&limitusdprice="+limitusdprice;
	 strurl+="&limitbtcprice="+limitbtcprice+"&volumeusd="+volumeusd+"&volumebtc="+volumebtc+"&volumecoin="+volumecoin+"&btcpricemysql="+BTCPreisMysql;
	 strurl+="&buyholdpercent="+buyholdpercent+"&brokersarbitrage="+brokersarbitrage+"&arbitragepercententry="+arbitragepercententry;
	 strurl+="&arbitragepercentexit="+arbitragepercentexit+"&tpusdprice="+tpusdprice+"&tpusdvalue="+tpusdvalue+"&tpbtcprice="+tpbtcprice+"&slusdprice="+slusdprice;
	 strurl+="&slusdvalue="+slusdvalue+"&slbtcprice="+slbtcprice+"&SignalEntryBH="+SignalEntryBH+"&maxtrades="+maxtrades;
	 
	 
	 
	 var savehttp = new XMLHttpRequest();
	 savehttp.onreadystatechange = function() 
	 {
	 if (this.readyState == 4 && this.status == 200) 
	 {
		 var RueckgabeTradebutton = this.responseText;
		 
		 if(RueckgabeTradebutton=="saved")
		   { 
			 document.getElementById('valid').className = 'validshow';

			 if(v1=="signal")
			 {
				CreateSubscribtedSignalsTextfile();
				Pagination5();
			 }
			 else
			 if(v1=="buyandhold")
			 {
				ShowBuyAndHoldEntrys();
			 }
			 else
			 if(v1=="arbitrage")
			 {
				CreateArbitrageSignalsTextfile();
				Pagination4();
			 }
			 
			  setTimeout(function(){ DeleteShowValid(); }, 1000);
		   }
		   else
		   if(RueckgabeTradebutton=="no volume")
		   {
			 document.getElementById('novalid').className = 'novalidshow';
			 setTimeout(function(){ DeleteNoShowValid(); }, 1000);
		   }
	  }
	  };
	  savehttp.open("GET", strurl, true);
	  savehttp.send();
  
  
  
 }};
 readbroker.open("GET", strurl, true);
 readbroker.send();
}








//--
function CreateSubscribtedSignalsTextfile()
{
  var xhttpr = new XMLHttpRequest();
  xhttpr.onreadystatechange = function() 
  {
     if (this.readyState == 4 && this.status == 200) 
        {
           console.log("CreateSubscribtedSignalsTextfile: "+this.responseText);
        }
  };     
  xhttpr.open("GET", "SubscribedSignalsTextfile.php", true);
  xhttpr.send();
}














var ShowHistoryClicked=0;
var Timeoutvar=0;
function ShowHistory()
{
	var offsetHeight = document.getElementById('ChartBox').offsetHeight;
	offsetHeight=offsetHeight-320;
	if(ShowHistoryClicked==0)
	  {
		document.getElementById("tradehistorybox").style.display = "block";
		document.getElementById('tradehistoryboxlist').style.height = offsetHeight+'px';
		//--
		if(document.getElementById("marketbrokers"))document.getElementById("marketbrokers").style.display = "none";
		//--
		PrintHistory();
		//--
		ShowHistoryClicked=1;
	  }
	else
	if(ShowHistoryClicked==1)
	  {
		document.getElementById("tradehistorybox").style.display = "none";
		//--
		if(document.getElementById("marketbrokers"))document.getElementById("marketbrokers").style.display = "block";
		//--
		clearTimeout(Timeoutvar);
		//--
		ShowHistoryClicked=0;
	  }
}


//--
var PaginationSeite=1;
//--
function PrintHistory()
{
  var xhttpr = new XMLHttpRequest();
  xhttpr.onreadystatechange = function() 
  {
     if (this.readyState == 4 && this.status == 200) 
        {
           document.getElementById("tradehistoryboxlist").innerHTML = this.responseText;
		   Timeoutvar = setTimeout(function(){ PrintHistory(); }, 5000);
        }
  };     
  xhttpr.open("GET", "ExchangesApis.php?TraderequestRead=1&PaginationSeite="+PaginationSeite, true);
  xhttpr.send();
}
//--
function Pagination(v1)
{
  var maxpages=1;
  if(document.getElementById("maxpages"))maxpages=document.getElementById("maxpages").innerHTML;
  if(v1=="plus")PaginationSeite++;
  else
  if(v1=="minus")PaginationSeite--;
  if(PaginationSeite<1)PaginationSeite=1;
  if(PaginationSeite>maxpages)PaginationSeite=maxpages;
  PrintHistory();
}











//--
function DeleteShowValid()
{
  document.getElementById('valid').className = 'valid';
  if(document.getElementById('valid2'))document.getElementById('valid2').className = 'valid';
  if(document.getElementById('valid3'))document.getElementById('valid3').className = 'valid';
  modal.style.display = "none";
  modal2.style.display = "none";
}

function DeleteNoShowValid()
{
  document.getElementById('novalid').className = 'valid';
}

function DeletedShowValid()
{
  document.getElementById('deleted').className = 'valid';
  if(document.getElementById('deleted2'))document.getElementById('deleted2').className = 'valid';
  modal.style.display = "none";
  modal2.style.display = "none";
}






function CalculateCostUSD()
{
    var USDAmount=document.getElementById("usdamount").value;
	var BTCPriceHidden=document.getElementById("btcpricehidden").innerHTML;
	var USDPriceHidden=document.getElementById("usdpricehidden").innerHTML;
	var USDPriceLimit=document.getElementById("usdlimitprice").value;
	var BTCPriceLimit=document.getElementById("btclimitprice").value;
	var Symbol=document.getElementById("myInput2").value;
	var n = Symbol.indexOf(" (")-2;
	Symbol = Symbol.substring(0, n);
	
	if(USDAmount!="")
	  {
		  var USDPriceUsing=USDPriceHidden;
		  var BTCPriceUsing=BTCPriceHidden;
		  if(USDPriceLimit>0)
		  {
			  USDPriceUsing=USDPriceLimit;
		  }
		  else if(BTCPriceLimit>0)
		  {
			  var a=BTCPriceLimit/BTCPriceHidden;
			  USDPriceUsing=USDPriceHidden*a;
			  
			  BTCPriceUsing=BTCPriceLimit;
		  }
		  else USDPriceUsing=USDPriceHidden;
		  var AmountCoinYouGet = USDAmount/USDPriceUsing;
		  if(AmountCoinYouGet<1)AmountCoinYouGet=(AmountCoinYouGet).toFixed(8);
		  if(AmountCoinYouGet>1)AmountCoinYouGet=(AmountCoinYouGet).toFixed(2);
		  
		  
		  var btccost=AmountCoinYouGet*BTCPriceUsing;
		  btccost = Math.round(btccost * 10000000) / 10000000;
		  var BTCPreisAPI="<span class=\"BTCPreismysql\">"+parseFloat(btccost).toFixed(9)+"</span>";
		  
		  
		  document.getElementById("btcamount").value= "";
		  document.getElementById("coinamount").value="";
		  document.getElementById("cost").innerHTML = "Cost USD: "+USDAmount+"<br>Coast BTC: "+parseFloat(btccost).toFixed(9)+"<br>"+Symbol+": "+AmountCoinYouGet+""+BTCPreisAPI;
	  }
}




function CalculateCostBTC()
{
	var BTCAmount=document.getElementById("btcamount").value;
	var BTCPriceHidden=document.getElementById("btcpricehidden").innerHTML;
	var USDPriceHidden=document.getElementById("usdpricehidden").innerHTML;
	var USDPriceLimit=document.getElementById("usdlimitprice").value;
	var BTCPriceLimit=document.getElementById("btclimitprice").value;
	var Symbol=document.getElementById("myInput2").value;
	var n = Symbol.indexOf(" (")-2;
	Symbol = Symbol.substring(0, n);
	
	if(BTCAmount!="")
	  {
		  var BTCPriceUsing=BTCPriceHidden;
		  var USDPriceUsing=USDPriceHidden;
		  if(USDPriceLimit>0)
		  {
			  var a=USDPriceLimit/USDPriceHidden;
			  BTCPriceUsing=BTCPriceHidden*a;
			  USDPriceUsing=USDPriceLimit;
		  }
		  else if(BTCPriceLimit>0)
		  {
			  BTCPriceUsing=BTCPriceLimit;
			  var a=BTCPriceLimit/BTCPriceHidden;
			  USDPriceUsing=USDPriceHidden*a;
		  }
		  else BTCPriceUsing=BTCPriceHidden;
		  
		  var AmountCoinYouGet = BTCAmount/BTCPriceUsing;
		  if(AmountCoinYouGet<1)AmountCoinYouGet=(AmountCoinYouGet).toFixed(8);
		  if(AmountCoinYouGet>1)AmountCoinYouGet=(AmountCoinYouGet).toFixed(2);
		  
		  
		  var usdcoast=AmountCoinYouGet*USDPriceUsing;
		  usdcoast = Math.round(usdcoast * 100) / 100;
		  
		  var BTCPreisAPI="<span class=\"BTCPreismysql\">"+parseFloat(BTCAmount).toFixed(9)+"</span>";
		  
		  document.getElementById("usdamount").value= "";
		  document.getElementById("coinamount").value= "";
		  document.getElementById("cost").innerHTML = "Cost USD: "+usdcoast+"<br>Coast BTC: "+BTCAmount+"<br>"+Symbol+": "+AmountCoinYouGet+""+BTCPreisAPI;
	  }
}




function CalculateCostCoin()
{
    var CoinAmount=document.getElementById("coinamount").value;
	var BTCPriceHidden=document.getElementById("btcpricehidden").innerHTML;
	var USDPriceHidden=document.getElementById("usdpricehidden").innerHTML;
	var USDPriceLimit=document.getElementById("usdlimitprice").value;
	var BTCPriceLimit=document.getElementById("btclimitprice").value;
	var Symbol=document.getElementById("myInput2").value;
	var n = Symbol.indexOf(" (")-2;
	Symbol = Symbol.substring(0, n);
	
	if(CoinAmount!="")
	  {
		  var USDPriceUsing=USDPriceHidden;
		  var BTCPriceUsing=BTCPriceHidden;
		  if(USDPriceLimit>0)
		  {
			  USDPriceUsing=USDPriceLimit;
			  var a=USDPriceLimit/USDPriceHidden;
			  BTCPriceUsing=BTCPriceHidden*a;
		  }
		  else if(BTCPriceLimit>0)
		  {
			  var a=BTCPriceLimit/BTCPriceUsing;
			  USDPriceUsing=USDPriceHidden*a;
			  
			  BTCPriceUsing=BTCPriceLimit;
		  }
		  else USDPriceUsing=USDPriceHidden;
		  var AmountCoinYouGet = CoinAmount;
		  if(AmountCoinYouGet<1)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(8);
		  if(AmountCoinYouGet>1)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(2);
		  
		  var btccost=AmountCoinYouGet*BTCPriceUsing;
		  btccost = Math.round(btccost * 1000000000) / 1000000000;
		  
		  var usdcoast=AmountCoinYouGet*USDPriceUsing;
		  usdcoast = Math.round(usdcoast * 100000) / 100000;
		  
		  var BTCPreisAPI="<span class=\"BTCPreismysql\">"+parseFloat(btccost).toFixed(9)+"</span>";
		  
		  document.getElementById("btcamount").value= "";
		  document.getElementById("usdamount").value="";
		  document.getElementById("cost").innerHTML = "Cost USD: "+usdcoast+"<br>Coast BTC: "+parseFloat(btccost).toFixed(9)+"<br>"+Symbol+": "+AmountCoinYouGet+""+BTCPreisAPI;
	  }
}





function CalculateCostLimitUSD()
{
    document.getElementById("btclimitprice").value="";
	var USDAmount=document.getElementById("usdamount").value;
	var BTCAmount=document.getElementById("btcamount").value;
	var BTCPriceHidden=document.getElementById("btcpricehidden").innerHTML;
	var USDPriceHidden=document.getElementById("usdpricehidden").innerHTML;
	var USDPriceLimit=document.getElementById("usdlimitprice").value;
	var BTCPriceLimit=document.getElementById("btclimitprice").value;
	var Symbol=document.getElementById("myInput2").value;
	var n = Symbol.indexOf(" (")-2;
	Symbol = Symbol.substring(0, n);
	
	if(USDAmount!="")
	  {
		  var USDPriceUsing=USDPriceHidden;
		  if(USDPriceLimit>0)
		  {
			  USDPriceUsing=USDPriceLimit;
		  }
		  else if(BTCPriceLimit>0)
		  {
			  var a=BTCPriceLimit/BTCPriceHidden;
			  USDPriceUsing=USDPriceHidden*a;
		  }
		  else USDPriceUsing=USDPriceHidden;
		  var AmountCoinYouGet = USDAmount/USDPriceUsing;
		  if(AmountCoinYouGet<1)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(8);
		  if(AmountCoinYouGet>1)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(2);
		  
		  var btccost=AmountCoinYouGet*BTCPriceHidden;
		  btccost = Math.round(btccost * 10000000) / 10000000;
		  
		  var BTCPreisAPI="<span class=\"BTCPreismysql\">"+(btccost).toFixed(9)+"</span>";
		  
		  document.getElementById("btcamount").value= "";
		  document.getElementById("coinamount").value= "";
		  document.getElementById("cost").innerHTML = "Cost USD: "+USDAmount+"<br>Coast BTC: "+btccost+"<br>"+Symbol+": "+AmountCoinYouGet+""+BTCPreisAPI;
	  }
	  if(BTCAmount!="")
	  {
		  var BTCPriceUsing=BTCPriceHidden;
		  var USDPriceUsing=USDPriceHidden;
		  if(USDPriceLimit>0)
		  {
			  var a=USDPriceLimit/USDPriceHidden;
			  BTCPriceUsing=BTCPriceHidden*a;
			  USDPriceUsing=USDPriceLimit;
		  }
		  else if(BTCPriceLimit>0)
		  {
			  BTCPriceUsing=BTCPriceLimit;
			  var a=BTCPriceLimit/BTCPriceHidden;
			  USDPriceUsing=USDPriceHidden*a;
		  }
		  else BTCPriceUsing=BTCPriceHidden;
		  
		  var AmountCoinYouGet = BTCAmount/BTCPriceUsing;
		  if(AmountCoinYouGet<1)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(8);
		  if(AmountCoinYouGet>1)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(2);
		  
		  
		  var usdcoast=AmountCoinYouGet*USDPriceUsing;
		  usdcoast = Math.round(usdcoast * 100) / 100;
		  
		  var BTCPreisAPI="<span class=\"BTCPreismysql\">"+parseFloat(BTCAmount).toFixed(9)+"</span>";
		  
		  document.getElementById("usdamount").value= "";
		  document.getElementById("coinamount").value= "";
		  document.getElementById("cost").innerHTML = "Cost USD: "+usdcoast+"<br>Coast BTC: "+BTCAmount+"<br>"+Symbol+": "+AmountCoinYouGet+""+BTCPreisAPI;
	  }
}




function CalculateCostLimitBTC()
{
	document.getElementById("usdlimitprice").value="";
    var USDAmount=document.getElementById("usdamount").value;
	var BTCAmount=document.getElementById("btcamount").value;
	var BTCPriceHidden=document.getElementById("btcpricehidden").innerHTML;
	var USDPriceHidden=document.getElementById("usdpricehidden").innerHTML;
	var USDPriceLimit=document.getElementById("usdlimitprice").value;
	var BTCPriceLimit=document.getElementById("btclimitprice").value;
	var Symbol=document.getElementById("myInput2").value;
	var n = Symbol.indexOf(" (")-2;
	Symbol = Symbol.substring(0, n);
	
	if(USDAmount!="")
	  {
		  var USDPriceUsing=USDPriceHidden;
		  if(USDPriceLimit>0)
		  {
			  USDPriceUsing=USDPriceLimit;
		  }
		  else if(BTCPriceLimit>0)
		  {
			  var a=BTCPriceLimit/BTCPriceHidden;
			  USDPriceUsing=USDPriceHidden*a;
		  }
		  else USDPriceUsing=USDPriceHidden;
		  var AmountCoinYouGet = USDAmount/USDPriceUsing;
		  if(AmountCoinYouGet<1)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(8);
		  if(AmountCoinYouGet>1)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(2);
		  
		  var btccost=AmountCoinYouGet*BTCPriceHidden;
		  btccost = Math.round(btccost * 10000000) / 10000000;
		  
		  var BTCPreisAPI="<span class=\"BTCPreismysql\">"+parseFloat(btccost).toFixed(9)+"</span>";
		  
		  document.getElementById("btcamount").value= "";
		  document.getElementById("cost").innerHTML = "Cost USD: "+USDAmount+"<br>Coast BTC: "+btccost+"<br>"+Symbol+": "+AmountCoinYouGet+""+BTCPreisAPI;
	  }
	  if(BTCAmount!="")
	  {
		  var BTCPriceUsing=BTCPriceHidden;
		  var USDPriceUsing=USDPriceHidden;
		  if(USDPriceLimit>0)
		  {
			  var a=USDPriceLimit/USDPriceHidden;
			  BTCPriceUsing=BTCPriceHidden*a;
			  USDPriceUsing=USDPriceLimit;
		  }
		  else if(BTCPriceLimit>0)
		  {
			  BTCPriceUsing=BTCPriceLimit;
			  var a=BTCPriceLimit/BTCPriceHidden;
			  USDPriceUsing=USDPriceHidden*a;
		  }
		  else BTCPriceUsing=BTCPriceHidden;
		  
		  var AmountCoinYouGet = BTCAmount/BTCPriceUsing;
		  if(AmountCoinYouGet<1)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(8);
		  if(AmountCoinYouGet>1)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(2);
		  
		  var BTCPreisAPI="<span class=\"BTCPreismysql\">"+parseFloat(BTCAmount).toFixed(9)+"</span>";
		  
		  var usdcoast=AmountCoinYouGet*USDPriceUsing;
		  usdcoast = Math.round(usdcoast * 100) / 100;
		  document.getElementById("usdamount").value= "";
		  document.getElementById("coinamount").value= "";
		  document.getElementById("cost").innerHTML = "Cost USD: "+usdcoast+"<br>Coast BTC: "+BTCAmount+"<br>"+Symbol+": "+AmountCoinYouGet+""+BTCPreisAPI;
	  }
}




function ResetCheckboxesSignalEntry(v1="leer")
{
	var Symbol=document.getElementById("myInput2").value;
	var n = Symbol.indexOf(" (")-2;
	Symbol = Symbol.substring(0, n);
	
	if(document.getElementById("onlybuy").checked == false && 
	   document.getElementById("onlysell").checked == false && 
	   document.getElementById("buyandsell").checked == false)
	{
	  document.getElementById("onlybuy").checked = true;
	  document.getElementById("onlysell").checked = false;
	  document.getElementById("buyandsell").checked = false;
	}
	else if(v1=="buy")
	{
	  document.getElementById("onlybuy").checked = true;
	  document.getElementById("onlysell").checked = false;
	  document.getElementById("buyandsell").checked = false;
	}
	else if(v1=="sell")
	{
	  document.getElementById("onlybuy").checked = false;
	  document.getElementById("onlysell").checked = true;
	  document.getElementById("buyandsell").checked = false;
	}
	else if(v1=="buyandsell")
	{
	  document.getElementById("onlybuy").checked = false;
	  document.getElementById("onlysell").checked = false;
	  document.getElementById("buyandsell").checked = true;
	}
	else if(v1=="usd")
	{
		document.getElementById("btcamountsg").value= "";
		document.getElementById("coinamountsg").value= "";
		var USDPriceHidden=document.getElementById("usdpricehidden").innerHTML;
		var BTCPriceHidden=document.getElementById("btcpricehidden").innerHTML;
		var USDamount=document.getElementById("usdamountsg").value;
		if(USDamount<=0)USDamount=0;
		var BTCPriceValue=BTCPriceHidden*(USDamount/USDPriceHidden);
		if(BTCPriceValue<=0)BTCPriceValue=0;
		var AmountCoinYouGet=parseFloat(BTCPriceValue/BTCPriceHidden);
		if(AmountCoinYouGet<1)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(9);
		if(AmountCoinYouGet>1)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(5);
		if(AmountCoinYouGet>100)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(2);
		var BTCPreisAPI="<span class=\"BTCPreismysql\">"+parseFloat(BTCPriceValue).toFixed(9)+"</span>";
		if(USDamount<1)USDamount=parseFloat(USDamount).toFixed(8);
		if(USDamount>1)USDamount=parseFloat(USDamount).toFixed(2);
		document.getElementById("cost").innerHTML = BTCPreisAPI;console.log("Signal BTCValue Mysql: "+parseFloat(BTCPriceValue).toFixed(9));
		document.getElementById("cost2").innerHTML = "Cost USD: "+USDamount+"<br>Coast BTC: "+parseFloat(BTCPriceValue).toFixed(9)+"<br>"+Symbol+": "+AmountCoinYouGet+""+BTCPreisAPI;
	}
	else if(v1=="btc")
	{
		var USDPriceHidden=document.getElementById("usdpricehidden").innerHTML;
		var BTCPriceHidden=document.getElementById("btcpricehidden").innerHTML;
		document.getElementById("usdamountsg").value= "";
		document.getElementById("coinamountsg").value= "";
		var BTCPriceValue=document.getElementById("btcamountsg").value;
		if(BTCPriceValue<=0)BTCPriceValue=0;
		var BTCPreisAPI="<span class=\"BTCPreismysql\">"+parseFloat(BTCPriceValue).toFixed(9)+"</span>";
		var USDamount=(BTCPriceValue/BTCPriceHidden)*USDPriceHidden;
		if(USDamount<=0)USDamount=0;
		var AmountCoinYouGet=parseFloat(BTCPriceValue/BTCPriceHidden);
		if(AmountCoinYouGet<1)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(9);
		if(AmountCoinYouGet>1)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(5);
		if(AmountCoinYouGet>100)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(2);
		if(USDamount<1)USDamount=parseFloat(USDamount).toFixed(8);
		if(USDamount>1)USDamount=parseFloat(USDamount).toFixed(2);
		document.getElementById("cost").innerHTML = BTCPreisAPI;console.log("Signal BTCValue Mysql: "+parseFloat(BTCPriceValue).toFixed(9));
		document.getElementById("cost2").innerHTML = "Cost USD: "+USDamount+"<br>Coast BTC: "+BTCPriceValue+"<br>"+Symbol+": "+AmountCoinYouGet+""+BTCPreisAPI;
	}
	else if(v1=="coin")
	{
		var USDPriceHidden=document.getElementById("usdpricehidden").innerHTML;
		var BTCPriceHidden=document.getElementById("btcpricehidden").innerHTML;
		document.getElementById("usdamountsg").value= "";
		document.getElementById("btcamountsg").value= "";
		var Coinamount=document.getElementById("coinamountsg").value;
		if(Coinamount<=0)Coinamount=0;
		var BTCPriceValue=BTCPriceHidden*Coinamount;
		if(BTCPriceValue<=0)BTCPriceValue=0;
		var USDamount=(BTCPriceValue/BTCPriceHidden)*USDPriceHidden;
		if(USDamount<=0)USDamount=0;
		var BTCPreisAPI="<span class=\"BTCPreismysql\">"+parseFloat(BTCPriceValue).toFixed(9)+"</span>";
		if(USDamount<1)USDamount=parseFloat(USDamount).toFixed(8);
		if(USDamount>1)USDamount=parseFloat(USDamount).toFixed(2);
		document.getElementById("cost").innerHTML = BTCPreisAPI;console.log("BuyHold BTCValue Mysql: "+parseFloat(BTCPriceValue).toFixed(9));
		document.getElementById("cost2").innerHTML = "Cost USD: "+USDamount+"<br>Coast BTC: "+parseFloat(BTCPriceValue).toFixed(9)+"<br>"+Symbol+": "+Coinamount+""+BTCPreisAPI;
	}
	else if(v1=="tpusdpricesg")
	{
		document.getElementById("tpusdvaluesg").value="";
		document.getElementById("tpbtcpricesg").value="";
	}
	else if(v1=="tpusdvaluesg")
	{
		document.getElementById("tpusdpricesg").value="";
		document.getElementById("tpbtcpricesg").value="";
	}
	else if(v1=="tpbtcpricesg")
	{
		document.getElementById("tpusdvaluesg").value="";
		document.getElementById("tpusdpricesg").value="";
	}
	else if(v1=="slusdpricesg")
	{
		document.getElementById("slusdvaluesg").value="";
		document.getElementById("slbtcpricesg").value="";
	}
	else if(v1=="slusdvaluesg")
	{
		document.getElementById("slusdpricesg").value="";
		document.getElementById("slbtcpricesg").value="";
	}
	else if(v1=="slbtcpricesg")
	{
		document.getElementById("slusdvaluesg").value="";
		document.getElementById("slusdpricesg").value="";
	}
}











function ResetCheckboxesBuyHoldEntry(v1="leer")
{
	var Symbol=document.getElementById("myInput2").value;
	var n = Symbol.indexOf(" (")-2;
	Symbol = Symbol.substring(0, n);
	
	if(v1=="usd")
	{
		document.getElementById("btcamountbh").value= "";
		document.getElementById("coinamountbh").value= "";
		var USDPriceHidden=document.getElementById("usdpricehidden").innerHTML;
		var BTCPriceHidden=document.getElementById("btcpricehidden").innerHTML;
		var USDamount=document.getElementById("usdamountbh").value;
		if(USDamount<=0)USDamount=0;
		var BTCPriceValue=BTCPriceHidden*(USDamount/USDPriceHidden);
		if(BTCPriceValue<=0)BTCPriceValue=0;
		var AmountCoinYouGet=parseFloat(BTCPriceValue/BTCPriceHidden);
		if(AmountCoinYouGet<1)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(9);
		if(AmountCoinYouGet>1)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(5);
		if(AmountCoinYouGet>100)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(2);
		var BTCPreisAPI="<span class=\"BTCPreismysql\">"+parseFloat(BTCPriceValue).toFixed(9)+"</span>";
		if(USDamount<1)USDamount=parseFloat(USDamount).toFixed(8);
		if(USDamount>1)USDamount=parseFloat(USDamount).toFixed(2);
		document.getElementById("cost").innerHTML = BTCPreisAPI;console.log("BuyHold BTCValue Mysql: "+parseFloat(BTCPriceValue).toFixed(9));
   	    document.getElementById("cost3").innerHTML = "Cost USD: "+USDamount+"<br>Coast BTC: "+parseFloat(BTCPriceValue).toFixed(9)+"<br>"+Symbol+": "+AmountCoinYouGet+""+BTCPreisAPI;
	}
	if(v1=="btc")
	{
		var USDPriceHidden=document.getElementById("usdpricehidden").innerHTML;
		var BTCPriceHidden=document.getElementById("btcpricehidden").innerHTML;
		document.getElementById("usdamountbh").value= "";
		document.getElementById("coinamountbh").value= "";
		var BTCPriceValue=document.getElementById("btcamountbh").value;
		if(BTCPriceValue<=0)BTCPriceValue=0;
		var USDamount=(BTCPriceValue/BTCPriceHidden)*USDPriceHidden;
		if(USDamount<=0)USDamount=0;
		var AmountCoinYouGet=parseFloat(BTCPriceValue/BTCPriceHidden);
		if(AmountCoinYouGet<1)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(9);
		if(AmountCoinYouGet>1)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(5);
		if(AmountCoinYouGet>100)AmountCoinYouGet=parseFloat(AmountCoinYouGet).toFixed(2);
		var BTCPreisAPI="<span class=\"BTCPreismysql\">"+parseFloat(BTCPriceValue).toFixed(9)+"</span>";
		if(USDamount<1)USDamount=parseFloat(USDamount).toFixed(8);
		if(USDamount>1)USDamount=parseFloat(USDamount).toFixed(2);
		document.getElementById("cost").innerHTML = BTCPreisAPI;console.log("BuyHold BTCValue Mysql: "+parseFloat(BTCPriceValue).toFixed(9));
		document.getElementById("cost3").innerHTML = "Cost USD: "+USDamount+"<br>Coast BTC: "+BTCPriceValue+"<br>"+Symbol+": "+AmountCoinYouGet+""+BTCPreisAPI;
	}
	if(v1=="coin")
	{
		var USDPriceHidden=document.getElementById("usdpricehidden").innerHTML;
		document.getElementById("usdamountbh").value= "";
		document.getElementById("btcamountbh").value= "";
		var BTCPriceHidden=document.getElementById("btcpricehidden").innerHTML;
		var Coinamount=document.getElementById("coinamountbh").value;
		if(Coinamount<=0)Coinamount=0;
		var BTCPriceValue=BTCPriceHidden*Coinamount;
		if(BTCPriceValue<=0)BTCPriceValue=0;
		var USDamount=(BTCPriceValue/BTCPriceHidden)*USDPriceHidden;
		if(USDamount<=0)USDamount=0;
		if(USDamount<1)USDamount=parseFloat(USDamount).toFixed(8);
		if(USDamount>1)USDamount=parseFloat(USDamount).toFixed(2);
		var BTCPreisAPI="<span class=\"BTCPreismysql\">"+parseFloat(BTCPriceValue).toFixed(9)+"</span>";
		document.getElementById("cost").innerHTML = BTCPreisAPI;console.log("BuyHold BTCValue Mysql: "+parseFloat(BTCPriceValue).toFixed(9));
		document.getElementById("cost3").innerHTML = "Cost USD: "+USDamount+"<br>Coast BTC: "+parseFloat(BTCPriceValue).toFixed(9)+"<br>"+Symbol+": "+Coinamount+""+BTCPreisAPI;
	}
	if(v1=="tpusdpricebh")
	{
		document.getElementById("tpusdvaluebh").value="";
		document.getElementById("tpbtcpricebh").value="";
	}
	else if(v1=="tpusdvaluebh")
	{
		document.getElementById("tpusdpricebh").value="";
		document.getElementById("tpbtcpricebh").value="";
	}
	else if(v1=="tpbtcpricebh")
	{
		document.getElementById("tpusdvaluebh").value="";
		document.getElementById("tpusdpricebh").value="";
	}
	if(v1=="slusdpricebh")
	{
		document.getElementById("slusdvaluebh").value="";
		document.getElementById("slbtcpricebh").value="";
	}
	else if(v1=="slusdvaluebh")
	{
		document.getElementById("slusdpricebh").value="";
		document.getElementById("slbtcpricebh").value="";
	}
	else if(v1=="slbtcpricebh")
	{
		document.getElementById("slusdvaluebh").value="";
		document.getElementById("slusdpricebh").value="";
	}
}






function ResetCheckboxesEntryPrice(v1="leer")
{
	if(document.getElementById("mrlimit").checked == false && document.getElementById("mrprice").checked == false)
	{
	  document.getElementById("mrlimit").checked = false;
	  document.getElementById("mrprice").checked = true;
	}
	if(v1!="leer")
	{
	  if(v1=="mrlimit")
	  {
		document.getElementById("mrlimit").checked = true;
	    document.getElementById("mrprice").checked = false;
	  }
	  if(v1=="mrprice")
	  {
		document.getElementById("mrlimit").checked = false;
	    document.getElementById("mrprice").checked = true;
	  }
	}
	if(document.getElementById("mrlimit").checked == false)
	{
		document.getElementById("usdlimitprice").disabled = true;
		document.getElementById("btclimitprice").disabled = true;
	}
	if(document.getElementById("mrlimit").checked == true)
	{
		document.getElementById("usdlimitprice").disabled = false;
		document.getElementById("btclimitprice").disabled = false;
	}
}




function ResetTP(v1)
{
	if(v1=="tpusdprice")
	{
		document.getElementById("tpusdvalue").value="";
		document.getElementById("tpbtcprice").value="";
	}
	else if(v1=="tpusdvalue")
	{
		document.getElementById("tpusdprice").value="";
		document.getElementById("tpbtcprice").value="";
	}
	else if(v1=="tpbtcprice")
	{
		document.getElementById("tpusdvalue").value="";
		document.getElementById("tpusdprice").value="";
	}
}






function ResetSL(v1)
{
	if(v1=="slusdprice")
	{
		document.getElementById("slusdvalue").value="";
		document.getElementById("slbtcprice").value="";
	}
	else if(v1=="slusdvalue")
	{
		document.getElementById("slusdprice").value="";
		document.getElementById("slbtcprice").value="";
	}
	else if(v1=="slbtcprice")
	{
		document.getElementById("slusdvalue").value="";
		document.getElementById("slusdprice").value="";
	}
}





function TradingCheckboxes(v1="leer", textfile="leer.txt", text="leer", id="leer")
{
	
 //--
 var Symbol = document.getElementById("myInput2").value;
 var n = Symbol.indexOf(" (")-2;
 Symbol = Symbol.substring(0, n);
 WriteTextIntoFile(textfile, text);
 if(id!="leer")
 {
   ShowExchanges(Symbol);
 }
}








var modal = document.getElementById('id01');
var modal2 = document.getElementById('id02');

window.onclick = function(event) 
{
    if (event.target == modal) {
        modal.style.display = "none";
    }
	if (event.target == modal2) {
		modal2.style.display = "none";
    }
}











function ReadTraderequests(typ="leer", symbol="leer")
{
	var d = new Date();var timestemp = d.getTime();
	//--
	var xhttp_readfile = new XMLHttpRequest();
    var url = "ReadTrade.php?typ="+typ+"&symbol="+symbol+"&timestemp="+timestemp;
    //--
	xhttp_readfile.onreadystatechange = function() 
    {
    if(xhttp_readfile.readyState == 4 && xhttp_readfile.status == 200) 
    {
		var RueckgabeReadTrade = this.responseText;
		
		
		if(RueckgabeReadTrade!="empty" &&  isJson(RueckgabeReadTrade)==true)
          {
			  var Einstellungen = JSON.parse(RueckgabeReadTrade);
			  var BTCPreisAPI="<span class=\"BTCPreismysql\">"+parseFloat(Einstellungen.Selection[0].btcpricemysql).toFixed(9)+"</span>";
			  document.getElementById("cost").innerHTML = BTCPreisAPI;console.log("BTCValue Mysql: "+parseFloat(Einstellungen.Selection[0].btcpricemysql).toFixed(9));
		  }
		
		
		if(RueckgabeReadTrade!="empty" && typ=="Signal")
		{
			if(isJson(this.responseText)==true)
            {
	           document.getElementById("tradesignal").style.display = "none";
			   document.getElementById("modifysignal").style.display = "block";
			   var Einstellungen = JSON.parse(RueckgabeReadTrade);
               
			   var Variable=Einstellungen.Selection[0].volumeusd;
			   if(Variable!=0)document.getElementById("usdamountsg").value = Variable;
			   
			   Variable=Einstellungen.Selection[0].volumebtc;
			   if(Variable!=0)document.getElementById("btcamountsg").value = Variable;
			   
			   Variable=Einstellungen.Selection[0].volumecoin;
			   if(Variable!=0)document.getElementById("coinamountsg").value = Variable;
			   
			   Variable=Einstellungen.Selection[0].tpusdprice;
			   if(Variable!=0)document.getElementById("tpusdpricesg").value = Variable;
			   
			   Variable=Einstellungen.Selection[0].tpusdvalue;
			   if(Variable!=0)document.getElementById("tpusdvaluesg").value = Variable;
			   
			   Variable=Einstellungen.Selection[0].tpbtcprice;
			   if(Variable!=0)document.getElementById("tpbtcpricesg").value = Variable; 
			   
			   Variable=Einstellungen.Selection[0].slusdprice;
			   if(Variable!=0)document.getElementById("slusdpricesg").value = Variable;
			   
			   Variable=Einstellungen.Selection[0].slusdvalue;
			   if(Variable!=0)document.getElementById("slusdvaluesg").value = Variable;
			   
			   Variable=Einstellungen.Selection[0].slbtcprice;
			   if(Variable!=0)document.getElementById("slbtcpricesg").value = Variable;
			   
			   if(Einstellungen.Selection[0].typ=="SignalBuy")
			     {
				   document.getElementById("onlybuy").checked = true;
				   document.getElementById("onlysell").checked = false;
				   document.getElementById("buyandsell").checked = false;
				 }
			   else 
			   if(Einstellungen.Selection[0].typ=="SignalSell")
			     {
				   document.getElementById("onlysell").checked = true;
				   document.getElementById("onlybuy").checked = false;
				   document.getElementById("buyandsell").checked = false;
				 }
			   else 
			   if(Einstellungen.Selection[0].typ=="SignalBuyAndSell")
			     { 
			       document.getElementById("buyandsell").checked = true;
				   document.getElementById("onlybuy").checked = false;
				   document.getElementById("onlysell").checked = false;
				 }
	        }
		}
		else if(typ=="Signal")
		{
		    document.getElementById("tradesignal").style.display = "block";
			document.getElementById("modifysignal").style.display = "none";
			document.getElementById("usdamountsg").value = "";
			document.getElementById("btcamountsg").value = "";
			document.getElementById("tpusdpricesg").value = "";
			document.getElementById("tpusdvaluesg").value = "";
			document.getElementById("tpbtcpricesg").value = ""; 
			document.getElementById("slusdpricesg").value = "";
			document.getElementById("slusdvaluesg").value = "";
			document.getElementById("slbtcpricesg").value = "";
		}




		
		
		if(RueckgabeReadTrade!="empty" && typ=="Buyandhold")
		{
			if(isJson(this.responseText)==true)
            {
	           document.getElementById("tradebuyhold").style.display = "none";
			   document.getElementById("modifybuyhold").style.display = "block";
			   var Einstellungen = JSON.parse(RueckgabeReadTrade);
               
			   var Variable=Einstellungen.Selection[0].volumeusd;
			   if(Variable!=0)document.getElementById("usdamountbh").value = Variable;
			   
			   Variable=Einstellungen.Selection[0].volumebtc;
			   if(Variable!=0)document.getElementById("btcamountbh").value = Variable;
			   
			   Variable=Einstellungen.Selection[0].volumecoin;
			   if(Variable!=0)document.getElementById("coinamountbh").value = Variable;
			   
			   Variable=Einstellungen.Selection[0].buyholdpercent;
			   if(Variable!=0)document.getElementById("buyholddistance").value = Variable;
			   
			   Variable=Einstellungen.Selection[0].maxtrades;
			   if(Variable!=0)document.getElementById("maxtradesbh").value = Variable;
			   
			   Variable=Einstellungen.Selection[0].tpusdprice;
			   if(Variable!=0)document.getElementById("tpusdpricebh").value = Variable;
			   
			   Variable=Einstellungen.Selection[0].tpusdvalue;
			   if(Variable!=0)document.getElementById("tpusdvaluebh").value = Variable;
			   
			   Variable=Einstellungen.Selection[0].tpbtcprice;
			   if(Variable!=0)document.getElementById("tpbtcpricebh").value = Variable; 
			   
			   Variable=Einstellungen.Selection[0].slusdprice;
			   if(Variable!=0)document.getElementById("slusdpricebh").value = Variable;
			   
			   Variable=Einstellungen.Selection[0].slusdvalue;
			   if(Variable!=0)document.getElementById("slusdvaluebh").value = Variable;
			   
			   Variable=Einstellungen.Selection[0].slbtcprice;
			   if(Variable!=0)document.getElementById("slbtcpricebh").value = Variable;
			   
			   if(Einstellungen.Selection[0].signalrichtung=="1")
			     {
				   document.getElementById("signalentrybh").checked = true;
				 }
				 
			   if(Einstellungen.Selection[0].tpsltraded==1)
			   {
                   document.getElementById("buyholdmodibuy").style.display = "none";
                   document.getElementById("buyholdmodibuy2").style.width = "100%";
			       document.getElementById("modifybuyhold").style.display = "none";
     			   document.getElementById("resetbuyhold").style.display = "block";				   
			   }
			   else
			   {
                   document.getElementById("buyholdmodibuy").style.display = "";
                   document.getElementById("buyholdmodibuy2").style.width = "";
			       document.getElementById("modifybuyhold").style.display = "";				   
			   }
				   
			   
	        }
		}
		else if(typ=="Buyandhold")
		{
		    document.getElementById("tradebuyhold").style.display = "block";
			document.getElementById("modifybuyhold").style.display = "none";
			document.getElementById("usdamountbh").value = "";
			document.getElementById("btcamountbh").value = "";
			document.getElementById("tpusdpricebh").value = "";
			document.getElementById("tpusdvaluebh").value = "";
			document.getElementById("tpbtcpricebh").value = ""; 
			document.getElementById("slusdpricebh").value = "";
			document.getElementById("slusdvaluebh").value = "";
			document.getElementById("slbtcpricebh").value = "";
		}
		
	}
	}
    xhttp_readfile.open("GET", url, true);
    xhttp_readfile.send();
}










function DeleteTraderequests(typ="leer", deletetr="leer")
{
    var Symbol=document.getElementById("myInput2").value;
	var n = Symbol.indexOf(" (")-2;
	Symbol = Symbol.substring(0, n); 
 
    
	var xhttp_readfile = new XMLHttpRequest();
    var url = "ReadTrade.php?typ="+typ+"&symbol="+Symbol+"&deletetr=1";
    xhttp_readfile.onreadystatechange = function() 
    {
    if(xhttp_readfile.readyState == 4 && xhttp_readfile.status == 200) 
    {
	  var RueckgabeDeleteTrade = this.responseText;
	  
	 
	  if(typ=="Signal" && RueckgabeDeleteTrade=="deleted")
	  {
		document.getElementById("tradesignal").style.display = "block";
		document.getElementById("modifysignal").style.display = "none";
		document.getElementById("usdamountsg").value = "";
		document.getElementById("btcamountsg").value = "";
		document.getElementById("tpusdpricesg").value = "";
		document.getElementById("tpusdvaluesg").value = "";
		document.getElementById("tpbtcpricesg").value = ""; 
		document.getElementById("slusdpricesg").value = "";
		document.getElementById("slusdvaluesg").value = "";
		document.getElementById("slbtcpricesg").value = "";
		document.getElementById("onlybuy").checked = true;
		document.getElementById("onlysell").checked = false;
		document.getElementById("buyandsell").checked = false;
		document.getElementById('deleted').className = 'validshow';
		var xhttpa = new XMLHttpRequest();
		xhttpa.onreadystatechange = function() 
		{
		  if(this.readyState == 4 && this.status == 200) 
			{
			  document.getElementById("AbonnementboxEntrys").innerHTML = this.responseText;
		      Pagination5();
			}
		};
		xhttpa.open("GET", "signalssubscriptions.php?timestmp="+timestemp+"&PaginationSeite5="+PaginationSeite5, true);
		xhttpa.send();
		
		setTimeout(function(){ DeletedShowValid(); }, 1000);
	  }
	 
	  if(typ=="Buyandhold" && RueckgabeDeleteTrade=="deleted")
	  {
		document.getElementById("tradebuyhold").style.display = "block";
		document.getElementById("modifybuyhold").style.display = "none";
		document.getElementById("resetbuyhold").style.display = "none";
		document.getElementById("buyholddistance").value = "";
		document.getElementById("maxtradesbh").value = "";
		document.getElementById("usdamountbh").value = "";
		document.getElementById("btcamountbh").value = "";
		document.getElementById("coinamountbh").value = "";
		document.getElementById("tpusdpricebh").value = "";
		document.getElementById("tpusdvaluebh").value = "";
		document.getElementById("tpbtcpricebh").value = ""; 
		document.getElementById("slusdpricebh").value = "";
		document.getElementById("slusdvaluebh").value = "";
		document.getElementById("slbtcpricebh").value = "";
		document.getElementById('deleted').className = 'validshow';
		setTimeout(function(){ DeletedShowValid(); }, 1000);
	  }
	}
	}
    xhttp_readfile.open("GET", url, true);
    xhttp_readfile.send();
}







function CoinNamenAufButtons()
{
 var Symbol=document.getElementById("myInput2").value;
 var n = Symbol.indexOf(" (")-2;
 Symbol = Symbol.substring(0, n);
 var y = document.getElementsByClassName("signalsymbol2");
 var i;
 for (i = 0; i < y.length; i++) 
 {
  y[i].innerHTML = Symbol;
 }
}



function openTab(evt, tabName) 
{
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) 
	{
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) 
	{
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
	
	//--
    var Symbol=document.getElementById("myInput2").value;
    var n = Symbol.indexOf(" (")-2;
    Symbol = Symbol.substring(0, n);
    //--

	if(tabName=="Market")
	  {
		 document.getElementById("MarketShowexchanges").innerHTML = "<p style=\"margin:10px\" id=\"exchangesauswahl\"></p>";
		 document.getElementById("SignalShowexchanges").innerHTML = "";
		 ShowExchanges(Symbol);
		 document.getElementById("cost2").innerHTML="";
	     document.getElementById("cost3").innerHTML="";
	  }
	if(tabName=="Signal")
	  {
		 ReadTraderequests('Signal', Symbol);//Modify Button
		 document.getElementById("MarketShowexchanges").innerHTML = "";
		 document.getElementById("SignalShowexchanges").innerHTML = "<p style=\"margin:10px\" id=\"exchangesauswahl\"></p>";
		 ShowExchanges(Symbol);
		 document.getElementById("cost").innerHTML="";
	     document.getElementById("cost3").innerHTML="";
	  }
	if(tabName=="BuyAndHold")
	  {
		 ReadTraderequests('Buyandhold', Symbol);//Modify Button
		 document.getElementById("MarketShowexchanges").innerHTML = "";
		 document.getElementById("SignalShowexchanges").innerHTML = "";
		 document.getElementById("BuyAndHoldShowexchanges").innerHTML = "<p style=\"margin:10px\" id=\"exchangesauswahl\"></p>";
		 ShowExchanges(Symbol,"leer");
		 document.getElementById("cost2").innerHTML="";
	     document.getElementById("cost").innerHTML="";
	  }
}

document.getElementById("defaultOpen").click();
</script>

</body>
</html>