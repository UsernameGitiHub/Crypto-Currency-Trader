<?php
  //+-----------------------------------------------------------+
  //| Datenbank Verbindung aufrufen                             |
  //+-----------------------------------------------------------+

       include('dbcon.php');
  

    $filename2="SubscribtedSignale.txt";
    $myfile2 = fopen($filename2, "w");
    $str = '{ "Signale":[ ';
    fwrite($myfile2, $str);

    $sql = "SELECT * FROM `tradingrequest` WHERE `sended`='0' AND `tradesignalnow`='0'";
    $result = mysqli_query($DatabasePointer,$sql);
    $i=0;

    while($row = mysqli_fetch_array($result))
         {
            //-- Datei
            if($i==0)$str = '  { "id":"'.$row['id'].'", "typ":"'.$row['typ'].'", "broker":"'.$row['broker'].'", "symbol":"'.$row['symbol'].'", "coin":"'.$row['coin'].'", "volumeusd":"'.$row['volumeusd'].'", "volumebtc":"'.$row['volumebtc'].'", "volumecoin":"'.$row['volumecoin'].'", "tpusdprice":"'.$row['tpusdprice'].'", "tpusdvalue":"'.$row['tpusdvalue'].'", "tpbtcprice":"'.$row['tpbtcprice'].'", "slusdprice":"'.$row['slusdprice'].'", "slusdvalue":"'.$row['slusdvalue'].'", "slbtcprice":"'.$row['slbtcprice'].'", "btcpricemysql":"'.$row['btcpricemysql'].'"  }'."\r\n";
            else     $str = ', { "id":"'.$row['id'].'", "typ":"'.$row['typ'].'", "broker":"'.$row['broker'].'", "symbol":"'.$row['symbol'].'", "coin":"'.$row['coin'].'", "volumeusd":"'.$row['volumeusd'].'", "volumebtc":"'.$row['volumebtc'].'", "volumecoin":"'.$row['volumecoin'].'", "tpusdprice":"'.$row['tpusdprice'].'", "tpusdvalue":"'.$row['tpusdvalue'].'", "tpbtcprice":"'.$row['tpbtcprice'].'", "slusdprice":"'.$row['slusdprice'].'", "slusdvalue":"'.$row['slusdvalue'].'", "slbtcprice":"'.$row['slbtcprice'].'", "btcpricemysql":"'.$row['btcpricemysql'].'"  }'."\r\n";
			fwrite($myfile2, $str);
            $i++; 
         }
             
    //-- Datei Signale
    $str =  ' ] }';
    fwrite($myfile2, $str);
    fclose($myfile2);
?>