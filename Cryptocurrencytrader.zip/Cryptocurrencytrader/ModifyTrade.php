<?php


  //+-----------------------------------------------------------+
  //| Datenbank Verbindung aufrufen                             |
  //+-----------------------------------------------------------+

     include('dbcon.php');


     $id=$_GET['id'];
	 
	 if(isset($_GET['buyhold'])==false)
	 {
	 if(isset($_GET['update']))
	 {
     $limitusdprice=$_GET['limitusdprice'];
     $limitbtcprice=$_GET['limitbtcprice'];
     $volumeusd=$_GET['volumeusd'];
     $volumebtc=$_GET['volumebtc'];
     $volumecoin=$_GET['volumecoin'];
     $btcpricemysql=$_GET['btcpricemysql'];if($btcpricemysql<=0)exit();
     $tpusdprice=$_GET['tpusdprice'];
     $tpusdvalue=$_GET['tpusdvalue'];
     $tpbtcprice=$_GET['tpbtcprice'];
     $slusdprice=$_GET['slusdprice'];
     $slusdvalue=$_GET['slusdvalue'];
     $slbtcprice=$_GET['slbtcprice'];

    	 
	 $sql="UPDATE ".$Database.".`tradingrequest` SET   `limitusdprice`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$limitusdprice))."',
													   `limitbtcprice`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$limitbtcprice))."',
													   `volumeusd`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$volumeusd))."',
													   `volumebtc`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$volumebtc))."',
													   `volumecoin`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$volumecoin))."',
													   `tpusdprice`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$tpusdprice))."',
													   `tpusdvalue`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$tpusdvalue))."',
													   `tpbtcprice`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$tpbtcprice))."',
													   `slusdprice`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$slusdprice))."',
													   `slusdvalue`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$slusdvalue))."', 
													   `slbtcprice`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$slbtcprice))."',
													   `btcpricemysql`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$btcpricemysql))."'
				                                 WHERE `id`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$id))."';";
					

                      if(!mysqli_query($DatabasePointer,$sql)) 
                        {
                          die('Updtae Traderequest Error: ' . mysqli_error($DatabasePointer)); 
                        } 
					  else echo 'updated';
	 }
	 if(isset($_GET['delete']))
	 {
		 if(isset($_GET['v1']) && $_GET['v1']=="nodelete")
		 {
			 $sql="UPDATE ".$Database.".`tradingrequest` SET  
													   `tpusdprice`='',
													   `tpusdvalue`='',
													   `tpbtcprice`='',
													   `slusdprice`='',
													   `slusdvalue`='', 
													   `slbtcprice`='',
													   `tpsltraded`='1'
				                                 WHERE `id`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$id))."';";
					

                      if(!mysqli_query($DatabasePointer,$sql)) 
                        {
                          die('Updtae Traderequest Error: ' . mysqli_error($DatabasePointer)); 
                        } 
					  else echo 'deleted';
		 }
		 else
		 {
		 $sql="DELETE FROM ".$Database.".`tradingrequest` WHERE `id`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$id))."';";
					

                      if(!mysqli_query($DatabasePointer,$sql)) 
                        {
                          die('DELETE Traderequest Error: ' . mysqli_error($DatabasePointer)); 
                        } 
					  else echo 'deleted';
		 }
	 }
	 }
	 else if(isset($_GET['buyhold']))  //--Update Buy And Hold Settings
	 {
		if(isset($_GET['update']))
		{
			 $buyholdpercent=$_GET['buyholdpercent'];
			 $volumeusd=$_GET['volumeusd'];
			 $volumebtc=$_GET['volumebtc'];
			 $volumecoin=$_GET['volumecoin'];
			 $btcpricemysql=$_GET['btcpricemysql'];if($btcpricemysql<=0)exit();
			 $tpusdprice=$_GET['tpusdprice'];
			 $tpusdvalue=$_GET['tpusdvalue'];
			 $tpbtcprice=$_GET['tpbtcprice'];
			 $slusdprice=$_GET['slusdprice'];
			 $slusdvalue=$_GET['slusdvalue'];
			 $slbtcprice=$_GET['slbtcprice'];

				 
			 $sql="UPDATE ".$Database.".`tradingrequest` SET   `volumeusd`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$volumeusd))."',
															   `volumebtc`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$volumebtc))."',
															   `volumecoin`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$volumecoin))."',
															   `buyholdpercent`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$buyholdpercent))."',
															   `tpusdprice`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$tpusdprice))."',
															   `tpusdvalue`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$tpusdvalue))."',
															   `tpbtcprice`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$tpbtcprice))."',
															   `slusdprice`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$slusdprice))."',
															   `slusdvalue`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$slusdvalue))."', 
															   `slbtcprice`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$slbtcprice))."',
													           `btcpricemysql`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$btcpricemysql))."',
													           `sended`='0',`result`=''
														 WHERE `id`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$id))."';";
			  if(!mysqli_query($DatabasePointer,$sql)) 
                {
                  die('Updtae Traderequest Error: ' . mysqli_error($DatabasePointer)); 
                } 
				else echo 'updated';
		}
	 }
?>