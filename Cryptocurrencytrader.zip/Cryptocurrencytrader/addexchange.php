<!DOCTYPE html>
<html>
<title>Crypto Currency Trader</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" href="favicon.ico" type="image/x-icon">
<link rel="stylesheet" href="styles.css?a=1516287909">
<script type="text/javascript">
function SaveData()
{
	  var xhttp1 = new XMLHttpRequest();
      xhttp1.onreadystatechange = function() 
      {
          if (this.readyState == 4 && this.status == 200) 
             {
               window.top.close();
             }
      };

      xhttp1.open("GET", "SaveAccounts.php?trbinkey="+document.getElementById("tradingbinanceapikey").value+"&trbinsec="+document.getElementById("tradingbinanceapisec").value, true);
      xhttp1.send();
}


</script>
<style>
input[type=text], select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type=submit] {
    width: 100%;
    background-color: deepskyblue;
    color: black;
    padding: 14px 20px;
    margin: 20px 8px 8px 0px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size:20px;
}

input[type=submit]:hover {
    background-color: blue;color:white;
}

.formulardiv {
    border-radius: 5px;
    border:1px solid gray;
    background-color: #99d9f7;
    padding: 20px;
    margin:20px 0 0 0;
}
</style>
</head>
<body>
<div style="border:0px solid gray;margin:20px;">
<h1 class="Kategorie1_Ueberschrift">Exchange Account Settings</h1>



<?php

  //+-----------------------------------------------------------+
  //| Datenbank Verbindung aufrufen                             |
  //+-----------------------------------------------------------+

     include('dbcon.php');

    $sql = "SELECT * FROM `accounts`";
    $result = mysqli_query($DatabasePointer,$sql);
    $row_cnt = mysqli_num_rows($result);

    $TradingKey=array();
    $TradingSec=array();
    $TradingEmail=array();
    $i=0;
	$TradingKey[$i]="";
    $TradingSec[$i]="";
    $TradingEmail[$i]="";

    while($row = mysqli_fetch_array($result))
         {
         if($row['exchange']=="Binance")
           {
            $i=0;
            $TradingKey[$i]=$row['trading_apikey'];
            $TradingSec[$i]=$row['trading_apisec'];
            $TradingEmail[$i]=$row['email'];
           }
         }//while


$i=0;
echo '
<h1 class="Kategorie1_Ueberschrift" style="background:white;border:none;margin:20px 0 0 0;padding-bottom:0;font-size:28px">Trading Account</h1>
<br>

<div class="formulardiv">
    <label for="tradingbinance"><span style="font-size:25px;font-weight:bold">Binance</span></label><br><br>
    API Key: <input type="text" id="tradingbinanceapikey" name="tradingbinanceapikey" value="'.$TradingKey[$i].'" placeholder="'; if($TradingKey[$i]!="") echo $TradingKey[$i]; else echo 'API Key..'; echo '">
    API Secret: <input type="text" id="tradingbinanceapisec" name="tradingbinanceapisec" value="'.$TradingSec[$i].'" placeholder="'; if($TradingSec[$i]!="") echo $TradingSec[$i]; else echo 'API Secret..'; echo '">
</div>';




?>



<input type="submit" onclick="SaveData()" value="Save changes and close this window">


</div>
</body>
</html>