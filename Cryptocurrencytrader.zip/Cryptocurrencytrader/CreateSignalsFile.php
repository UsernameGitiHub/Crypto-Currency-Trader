<?php
  //+-----------------------------------------------------------+
  //| Datenbank Verbindung aufrufen                             |
  //+-----------------------------------------------------------+

     include('dbcon.php');

	 
  //+------------------------------------------------------------------+
  //| Signale in Textdatei speichern                                   |
  //+------------------------------------------------------------------+

   //-- Datei Signale erstellen

    $filename2="Signale.txt";
    $myfile2 = fopen($filename2, "w");
    $str = '{ "Signale":[ ';
    fwrite($myfile2, $str);

    $sql = "SELECT `date`,`broker`,`coin`,`cmcid`,`name`,`timeframe`,`richtung`,`signalpower` FROM `signale` ORDER BY `signale`.`date` DESC";
    $result = mysqli_query($DatabasePointer,$sql);
    $i=0;

    while($row = mysqli_fetch_array($result))
         {
          if($row['timeframe']=="D1")
            {
               //-- Datei
               if($i==0)$str = '  { "timeframe":"'.$row['timeframe'].'", "coin":"'.$row['coin'].'", "cmcid":"'.$row['cmcid'].'", "name":"'.$row['name'].'", "broker":"'.$row['broker'].'", "richtung":"'.$row['richtung'].'", "signalpower":"'.$row['signalpower'].'"  }'."\r\n"; 
               else     $str = ', { "timeframe":"'.$row['timeframe'].'", "coin":"'.$row['coin'].'", "cmcid":"'.$row['cmcid'].'", "name":"'.$row['name'].'", "broker":"'.$row['broker'].'", "richtung":"'.$row['richtung'].'", "signalpower":"'.$row['signalpower'].'"  }'."\r\n"; 
               fwrite($myfile2, $str);
               $i++;
            }
         }

    //-- Datei Signale
    $str =  ' ] }';
    fwrite($myfile2, $str);
    fclose($myfile2);


	//--Alte Signale loeschen
	$loeschdate=time()-(24*3600*10);
	$sql="DELETE FROM ".$Database.".`signale` WHERE `date`<='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$loeschdate))."'";
    mysqli_query($DatabasePointer,$sql); 
    if($error = mysqli_error($DatabasePointer)) die('Error, Delete Signale query failed with:' . $error);
?>