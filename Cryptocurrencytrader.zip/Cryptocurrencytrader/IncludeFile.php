<?php
if($timeframe=="D1")
{

$AverageCandelMove=(($AverageCandelMove/$b)/2);
$Buyzone=$charthigh-(abs($charthigh-$chartlow)/2);
$Sellzone=$chartlow+(abs($charthigh-$chartlow)/2);
$signalpowerlong=0;
$signalpowershort=0;



$Low20Day=0;
$High20Day=0;
$indx=$b-1;
for($i=0; $i<20; $i++)
{
  if($highus[$indx][2]>=$High20Day && $highus[$indx][2]>0)$High20Day=$highus[$indx][2];
  if(($lowus[$indx][2]<=$Low20Day && $lowus[$indx][2]>0) || $Low20Day==0)$Low20Day=$lowus[$indx][2];
  $indx--;
}





$Buysignalfind=0;
if($lowus[$b-1][2]<=$Low20Day)
{
 $signalpowerlong++;
 $Buysignalfind=1;
}
if($closeus[$b-1][2]<=$Buyzone && $Buyzone>0)$signalpowerlong++;



$Sellsignalfind=0;
if($highus[$b-1][2]>=$High20Day)
{
 $signalpowershort++;
 $Sellsignalfind=1;
}
if($closeus[$b-1][2]>=$Sellzone && $Sellzone>0)$signalpowershort++;





if($Buysignalfind==1)
{

	
	$str=file_get_contents("SubscribtedSignale.txt");
	$SubscribtedSignale = json_decode($str, true);
	for($i=0; $i<count($SubscribtedSignale["Signale"]); $i++)
	{
		if($SubscribtedSignale["Signale"][$i]["coin"]==$Coinname && 
		  ($SubscribtedSignale["Signale"][$i]["typ"]=="SignalBuy" || $SubscribtedSignale["Signale"][$i]["typ"]=="SignalBuyAndSell"))
		{
			 $code=$dateus[$b-1][2]."_Signale".$Coinname;
			 $sql="INSERT INTO ".$Database.".`tradingrequest` (`code`,
														   `typ`,
														   `broker`,
														   `symbol`,
														   `coin`,
														   `market_or_limit`,
														   `limitusdprice`,
														   `limitbtcprice`,
														   `volumeusd`,
														   `volumebtc`,
														   `volumecoin`,
														   `buyholdpercent`,
														   `brokersarbitrage`,
														   `arbitragepercententry`,
														   `arbitragepercentexit`,
														   `tpusdprice`, 
														   `tpusdvalue`, 
														   `tpbtcprice`, 
														   `slusdprice`, 
														   `slusdvalue`, 
														   `slbtcprice`, 
														   `sended`,
														   `createdtimestamp`,
														   `btcpricemysql`,`tradesignalnow`,`signalrichtung`)
				VALUES 
					   ('".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$code))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["typ"]))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["broker"]))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["symbol"]))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["coin"]))."',
						'',
						'',
						'',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["volumeusd"]))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["volumebtc"]))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["volumecoin"]))."',
						'',
						'',
						'',
						'',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["tpusdprice"]))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["tpusdvalue"]))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["tpbtcprice"]))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["slusdprice"]))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["slusdvalue"]))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["slbtcprice"]))."',
						'0',
						'".time()."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["btcpricemysql"]))."',
						'1','1')

						ON DUPLICATE KEY UPDATE code=VALUES(code);";
						

						  if(!mysqli_query($DatabasePointer,$sql)) 
							{
							  die('Save Signal Traderequest Error: ' . mysqli_error($DatabasePointer)); 
							} 
						  else echo '<br>signal tradeing saved or updated if already traded<br>';
			break;
		}
	}



	$sql="UPDATE ".$Database.".`tradingrequest` SET `tradesignalnow`='1' WHERE `typ`='BuyAndHold' AND `coin`='".$Coinname."'";
    if(!mysqli_query($DatabasePointer,$sql)) 
	{
	 die('Update BuyandHold Signal Traderequest Error: ' . mysqli_error($DatabasePointer)); 
    } 
	
	
	
	
	

	 $Symbolname2=str_replace("btc","",$SymbolDownloaden);
	 $Symbolname2=str_replace("BTC","",$Symbolname2);
	 $Symbolname2=str_replace("_","",$Symbolname2);
	 
	 $signalcode=$Coinname."_".$timeframe;
	 $sql = "INSERT INTO ".$Database.".`signale` (`date`,`signalcode`,`broker`,`coin`,`cmcid`,`name`,`timeframe`,`richtung`,`signalpower`,`averagemove`,`buyzone`,`high`,`low`) 
			 VALUES
			 ('".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$dateus[$b-1][2]))."',
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$signalcode))."',
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$ExchangeName))."',
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$Symbolname2))."',
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$cmcid))."',
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$Coinname))."',
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$timeframe))."',
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,"long"))."', 
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$signalpowerlong))."', 
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$AverageCandelMove))."', 
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,number_format($Buyzone,15)))."',
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,number_format($charthigh,15)))."', 
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,number_format($chartlow,15)))."')
			  ON DUPLICATE KEY UPDATE signalcode=VALUES(signalcode)";
	  mysqli_query($DatabasePointer,$sql) or die('Insert Signal Error: ' . mysqli_error($DatabasePointer));
}

























if($Sellsignalfind==1)
{

	
	$str=file_get_contents("SubscribtedSignale.txt");
	$SubscribtedSignale = json_decode($str, true);
	for($i=0; $i<count($SubscribtedSignale["Signale"]); $i++)
	{
		if($SubscribtedSignale["Signale"][$i]["coin"]==$Coinname && 
		  ($SubscribtedSignale["Signale"][$i]["typ"]=="SignalSell" || $SubscribtedSignale["Signale"][$i]["typ"]=="SignalBuyAndSell"))
		{
			 $code=$dateus[$b-1][2]."_Signale".$Coinname;
			 $sql="INSERT INTO ".$Database.".`tradingrequest` (`code`,
														   `typ`,
														   `broker`,
														   `symbol`,
														   `coin`,
														   `market_or_limit`,
														   `limitusdprice`,
														   `limitbtcprice`,
														   `volumeusd`,
														   `volumebtc`,
														   `volumecoin`,
														   `buyholdpercent`,
														   `brokersarbitrage`,
														   `arbitragepercententry`,
														   `arbitragepercentexit`,
														   `tpusdprice`, 
														   `tpusdvalue`, 
														   `tpbtcprice`, 
														   `slusdprice`, 
														   `slusdvalue`, 
														   `slbtcprice`, 
														   `sended`,
														   `createdtimestamp`,
														   `btcpricemysql`,`tradesignalnow`,`signalrichtung`)
				VALUES 
					   ('".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$code))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["typ"]))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["broker"]))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["symbol"]))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["coin"]))."',
						'',
						'',
						'',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["volumeusd"]))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["volumebtc"]))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["volumecoin"]))."',
						'',
						'',
						'',
						'',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["tpusdprice"]))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["tpusdvalue"]))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["tpbtcprice"]))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["slusdprice"]))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["slusdvalue"]))."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["slbtcprice"]))."',
						'0',
						'".time()."',
						'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$SubscribtedSignale["Signale"][$i]["btcpricemysql"]))."',
						'1','2')

						ON DUPLICATE KEY UPDATE code=VALUES(code);";
						

						  if(!mysqli_query($DatabasePointer,$sql)) 
							{
							  die('Save Signal Traderequest Error: ' . mysqli_error($DatabasePointer)); 
							} 
						  else echo '<br>signal tradeing saved or updated if already traded<br>';
			break;
		}
	}


	
	
	
	 $Symbolname2=str_replace("btc","",$SymbolDownloaden);
	 $Symbolname2=str_replace("BTC","",$Symbolname2);
	 $Symbolname2=str_replace("_","",$Symbolname2);
	 
	 $signalcode=$Coinname."_".$timeframe;
	 $sql = "INSERT INTO ".$Database.".`signale` (`date`,`signalcode`,`broker`,`coin`,`cmcid`,`name`,`timeframe`,`richtung`,`signalpower`,`averagemove`,`buyzone`,`high`,`low`) 
			 VALUES
			 ('".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$dateus[$b-1][2]))."',
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$signalcode))."',
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$ExchangeName))."',
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$Symbolname2))."',
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$cmcid))."',
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$Coinname))."',
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$timeframe))."',
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,"short"))."', 
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$signalpowershort))."', 
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$AverageCandelMove))."', 
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,number_format($Sellzone,15)))."',
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,number_format($charthigh,15)))."', 
			  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,number_format($chartlow,15)))."')
			  ON DUPLICATE KEY UPDATE signalcode=VALUES(signalcode)";
	  mysqli_query($DatabasePointer,$sql) or die('Insert Signal Error: ' . mysqli_error($DatabasePointer));
}
}
?>