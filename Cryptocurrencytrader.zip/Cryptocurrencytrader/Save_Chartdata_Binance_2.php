<?php


  set_time_limit(0);

	function curl_get_file_contents($URL)
    {
        $c = curl_init();
        curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($c, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($c, CURLOPT_URL, $URL);
        $contents = curl_exec($c);
        curl_close($c);

        if ($contents) return $contents;
        else return FALSE;
    }
  
    $Backbars=450; //Maximal Anzahl Candelsticks

    $SymbolDownloaden="BTCUSDT";
    if(isset($_GET['symbol']))$SymbolDownloaden=$_GET['symbol'];
    if(isset($_GET['timeframe']))$TimeframeDownloaden=$_GET['timeframe']; else $TimeframeDownloaden="D1";

    function FormatStringToNumber($a)
    {
      $b=(float)str_replace(",","",$a);
      return($b);
    }

//----
if(strlen($SymbolDownloaden)>3 && $SymbolDownloaden!="undefined")
  {
   
    $tmf="";
    $CandelsPeriode=0;

    if($TimeframeDownloaden=="D1"){ $tmf="1d"; $CandelsPeriode=86400; }
    else
    if($TimeframeDownloaden=="H2"){ $tmf="2h"; $CandelsPeriode=7200; }
    else
    if($TimeframeDownloaden=="H4"){ $tmf="4h"; $CandelsPeriode=14400; }
    else
    if($TimeframeDownloaden=="M30"){ $tmf="30m"; $CandelsPeriode=1800; }


    //--

    $zeitstart=0;
    

    //--

    if($zeitstart<=0)$zeitstart=time()-($Backbars*$CandelsPeriode);
    $zeitende=time()+(240*3600);
    




    $url = "https://api.binance.com/api/v1/klines?symbol=".$SymbolDownloaden."&interval=".$tmf."&startTime=".$zeitstart."000&endTime=".$zeitende."000";
    $page = curl_get_file_contents($url);
    $page = json_decode($page,true);
    $NeusteKerze=0;
    $filename2="Textdateien_Charts_BTC/Binance_Chart_".$SymbolDownloaden.'_'.$TimeframeDownloaden.".txt";


    unset($highus);
    unset($lowus);
    unset($closeus);
    unset($openus);
    unset($dateus);

    $highus=array();
    $lowus=array();
    $closeus=array();
    $openus=array();
    $dateus=array();

//--
 
    if(count($page)>=1 && gettype($page)=="array") 
      {

         if($SymbolDownloaden=="BTCUSDT")
         {
          //-- Bitcoin Chartdatei
          $myfile2 = fopen($filename2, "w");
          $str = '{ "Chart":[ ';
          fwrite($myfile2, $str);
         }

        for($i=0; $i<count($page); $i++)
        {
               $date=substr($page[$i][0],0,10);

               $open=$page[$i][1];
               $high=$page[$i][2];
               $low=$page[$i][3];
               $close=$page[$i][4];
               
               if($date>$NeusteKerze || $NeusteKerze==0)$NeusteKerze=$date;
               $symdate=$SymbolDownloaden.'_'.$TimeframeDownloaden.'_'.$date;


             if($SymbolDownloaden=="BTCUSDT")
             {
               //--Textdatei erstellen code
               if($i==0)$str = '  { "timeframe":"'.$TimeframeDownloaden.'", "date":"'.$date.'", "open":"'.$open.'", "high":"'.$high.'", "low":"'.$low.'", "close":"'.$close.'"  }'."\r\n"; 
               else     $str = ', { "timeframe":"'.$TimeframeDownloaden.'", "date":"'.$date.'", "open":"'.$open.'", "high":"'.$high.'", "low":"'.$low.'", "close":"'.$close.'"  }'."\r\n"; 
               fwrite($myfile2, $str);
             }


            $dateus[$i][1]=$date;
            $highus[$i][1]=$high;
            $lowus[$i][1]=$low;
            $closeus[$i][1]=$close;
            $openus[$i][1]=$open;

            $dateus[$i][2]=0;
            $highus[$i][2]=0;
            $lowus[$i][2]=0;
            $closeus[$i][2]=0;
            $openus[$i][2]=0;
                    
        }//for


  if($SymbolDownloaden=="BTCUSDT")
  {
   //-- Charts speichern Datei
   $str =  ' ] }';
   fwrite($myfile2, $str);
   fclose($myfile2);
  }



    unset($bhigh);
    unset($blow);
    unset($bclose);
    unset($bopen);
    unset($bdate);

    $bhigh=array();
    $blow=array();
    $bclose=array();
    $bopen=array();
    $bdate=array();

    $bitcoinkurse="Textdateien_Charts_BTC/Binance_Chart_BTCUSDT_".$TimeframeDownloaden.".txt";

    if(file_exists($bitcoinkurse))
    {
      $differeneFilezeit=abs(filemtime($bitcoinkurse)-time());
      if($differeneFilezeit>350)unlink($bitcoinkurse);
      $url="http://".$_SERVER['SERVER_NAME'].''.$_SERVER['SCRIPT_NAME'];
      $url=str_replace("Save_Chartdata_Binance_2.php","Save_Chartdata_Binance.php",$url);
      $url=$url."?symbol=BTCUSDT&name=Bitcoin";
      file_get_contents($url);
    }

    if(file_exists($bitcoinkurse))
    {

    $page = file_get_contents($bitcoinkurse);
    $page = json_decode($page,true);
   
    for($i=0; $i<count($page["Chart"]); $i++)
    {
      $bdate[$i]=$page["Chart"][$i]["date"];
      $bhigh[$i]=$page["Chart"][$i]["high"];
      $blow[$i]=$page["Chart"][$i]["low"];
      $bclose[$i]=$page["Chart"][$i]["close"];
      $bopen[$i]=$page["Chart"][$i]["open"];
    }



    $charthigh=0;
    $chartlow=0;
    $AverageCandelMove=0;
    if(count($dateus)>5)
    {
    $b=0;
    for($i=0; $i<count($dateus); $i++)
       {
        for($i2=0; $i2<count($bdate); $i2++)
           {
             if( isset($dateus[$i][1]) )
             if($dateus[$i][1]==$bdate[$i2] && $dateus[$i][1]>0 && $bdate[$i2]>0)
             {
               $dateus[$b][2]=$bdate[$i2];
               $highus[$b][2]=$bhigh[$i2] * $highus[$i][1];
               $lowus[$b][2]=$blow[$i2] * $lowus[$i][1];
               $closeus[$b][2]=$bclose[$i2] * $closeus[$i][1];
               $openus[$b][2]=$bopen[$i2] * $openus[$i][1];

               if($SymbolDownloaden=="BTCUSDT")
               {
               $highus[$b][2]=$highus[$i][1];
               $lowus[$b][2]=$lowus[$i][1];
               $closeus[$b][2]=$closeus[$i][1];
               $openus[$b][2]=$openus[$i][1];
               }

               $b++;
               continue;
             }
           }
       }
     }

  

    }
    }










   
    $filenameus="Textdateien_Charts_USD/Binance_USDChart_".$SymbolDownloaden.'_'.$TimeframeDownloaden.".txt";
    $myfileus = fopen($filenameus, "w");
    $str = '{ "Chart":[ ';
    fwrite($myfileus, $str);
    $a=0;
    for($i=0; $i<count($dateus); $i++)
       {
        if($dateus[$i][2]>0)
          {
            $date=$dateus[$i][2];
            $open=$openus[$i][2];
            $high=$highus[$i][2];
            $low=$lowus[$i][2];
            $close=$closeus[$i][2];
                    
            //--Textdatei erstellen code
            if($a==0)$str = '  { "timeframe":"'.$TimeframeDownloaden.'", "date":"'.$date.'", "open":"'.$open.'", "high":"'.$high.'", "low":"'.$low.'", "close":"'.$close.'"  }'."\r\n"; 
            else     $str = ', { "timeframe":"'.$TimeframeDownloaden.'", "date":"'.$date.'", "open":"'.$open.'", "high":"'.$high.'", "low":"'.$low.'", "close":"'.$close.'"  }'."\r\n"; 
            fwrite($myfileus, $str);
            $a++;
           }
       }
    $str =  ' ] }';
    fwrite($myfileus, $str);
    fclose($myfileus);





      echo '[';
      $a=0;
      $b=0;
      for($i=0; $i<count($dateus); $i++)
       {
        if($dateus[$i][2]>0)
          {
            $date=$dateus[$i][2];
            $open=$openus[$i][2];
            $high=$highus[$i][2];
            $low=$lowus[$i][2];
            $close=$closeus[$i][2];

            $b++;
            if($a>0)echo ',';
            echo "[\"".$b."\", ".str_replace(",","",$high).", ".str_replace(",","",$open).", ".str_replace(",","",$close).", ".str_replace(",","",$low)."]
            ";
            $a++;
           }
       }
      echo ']';


}
?>