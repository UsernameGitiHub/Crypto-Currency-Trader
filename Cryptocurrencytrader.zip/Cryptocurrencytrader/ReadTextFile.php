<?php 
$filename=$_GET['file'];
$text="";
if(file_exists($filename)) 
  {
	  $myfile = fopen($filename, "r"); 
	  if(filesize($filename)>0)
	  {
	   $text=fread($myfile,filesize($filename));
	  }	  
	  fclose($myfile); }
echo $text;
?>