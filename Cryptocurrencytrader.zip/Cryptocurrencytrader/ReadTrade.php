<?php


  //+-----------------------------------------------------------+
  //| Datenbank Verbindung aufrufen                             |
  //+-----------------------------------------------------------+

     include('dbcon.php');

	if(isset($_GET['ReadBuyandHold'])==false)
	{
    if(isset($_GET['deletetr'])==false)
	{
		$typ=$_GET['typ'];
		$symbol=$_GET['symbol'];
		 
		if($typ=="Signal")
		{
		  $sql="Select * FROM ".$Database.".`tradingrequest` WHERE (`typ`='SignalBuy' OR `typ`='SignalSell' OR `typ`='SignalBuyAndSell')
														AND `coin`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$symbol))."'
														AND `tradesignalnow`='0'";
		}
		else 
		if($typ=="Buyandhold")
		{
		  $sql="Select * FROM ".$Database.".`tradingrequest` WHERE `typ`='BuyAndHold' AND `buyholdpercent`!='' 
														AND `coin`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$symbol))."'";
		}
		else 
		if($typ=="Arbitrage")
		{
		  $sql="Select * FROM ".$Database.".`tradingrequest` WHERE `typ`='Arbitrage' 
														AND `coin`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$symbol))."'";
		}

		$result = mysqli_query($DatabasePointer,$sql); 
		if($error = mysqli_error($DatabasePointer)) die('Error, Read Traderequest query failed with:' . $error);
		$rowcount=mysqli_num_rows($result);

		if($rowcount>0)
		{	
		$i=0;
		
		echo '{ "Selection":['; 
		
		while($row = mysqli_fetch_array($result))
			 {
				   if($i==0)echo '  { "typ":"'.$row['typ'].'", "broker":"'.$row['broker'].'", "coin":"'.$row['symbol'].'", "market_or_limit":"'.$row['market_or_limit'].'", "limitusdprice":"'.$row['limitusdprice'].'", "limitbtcprice":"'.$row['limitbtcprice'].'", "volumeusd":"'.$row['volumeusd'].'" , "volumebtc":"'.$row['volumebtc'].'" , "volumecoin":"'.$row['volumecoin'].'" , "buyholdpercent":"'.$row['buyholdpercent'].'" , "brokersarbitrage":"'.$row['brokersarbitrage'].'" , "arbitragepercententry":"'.$row['arbitragepercententry'].'", "arbitragepercentexit":"'.$row['arbitragepercentexit'].'", "tpusdprice":"'.$row['tpusdprice'].'", "tpusdvalue":"'.$row['tpusdvalue'].'", "tpbtcprice":"'.$row['tpbtcprice'].'", "slusdprice":"'.$row['slusdprice'].'", "slusdvalue":"'.$row['slusdvalue'].'", "slbtcprice":"'.$row['slbtcprice'].'", "btcpricemysql":"'.$row['btcpricemysql'].'", "tpsltraded":"'.$row['tpsltraded'].'", "signalrichtung":"'.$row['signalrichtung'].'", "maxtrades":"'.$row['maxtrades'].'"  }'."\r\n"; 
				   else     echo ', { "typ":"'.$row['typ'].'", "broker":"'.$row['broker'].'", "coin":"'.$row['symbol'].'", "market_or_limit":"'.$row['market_or_limit'].'", "limitusdprice":"'.$row['limitusdprice'].'", "limitbtcprice":"'.$row['limitbtcprice'].'", "volumeusd":"'.$row['volumeusd'].'" , "volumebtc":"'.$row['volumebtc'].'" , "volumecoin":"'.$row['volumecoin'].'" , "buyholdpercent":"'.$row['buyholdpercent'].'" , "brokersarbitrage":"'.$row['brokersarbitrage'].'" , "arbitragepercententry":"'.$row['arbitragepercententry'].'", "arbitragepercentexit":"'.$row['arbitragepercentexit'].'", "tpusdprice":"'.$row['tpusdprice'].'", "tpusdvalue":"'.$row['tpusdvalue'].'", "tpbtcprice":"'.$row['tpbtcprice'].'", "slusdprice":"'.$row['slusdprice'].'", "slusdvalue":"'.$row['slusdvalue'].'", "slbtcprice":"'.$row['slbtcprice'].'", "btcpricemysql":"'.$row['btcpricemysql'].'", "tpsltraded":"'.$row['tpsltraded'].'", "signalrichtung":"'.$row['signalrichtung'].'", "maxtrades":"'.$row['maxtrades'].'"  }'."\r\n"; 
				   $i++;
			 }
				 
		echo ' ] }';
		}
		else echo 'empty';
	}
	else
	{
		//delete
		$typ=$_GET['typ'];
		$symbol=$_GET['symbol'];
		$code="";
		
		if($typ=="Signal")
		{
		  $code="Signal_".$symbol;
		  $sql="DELETE FROM ".$Database.".`tradingrequest` WHERE `code`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$code))."'";
		}
		else 
		if($typ=="Buyandhold")
		{
		  $code="BuyAndHold_".$symbol;
		  $sql="DELETE FROM ".$Database.".`tradingrequest` WHERE `code`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$code))."'";
		}
		else 
		if($typ=="Arbitrage")
		{
		  $code="Arbitrage_".$symbol;
		  $sql="DELETE FROM ".$Database.".`tradingrequest` WHERE `code`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$code))."'";
		}
		
		$result = mysqli_query($DatabasePointer,$sql); 
		if($error = mysqli_error($DatabasePointer)) die('Error, Read Traderequest query failed with:' . $error);
		$rowcount=mysqli_affected_rows($DatabasePointer);
		if($rowcount>0)echo 'deleted';
		
		
		//--
		
		if($typ=="Arbitrage")
		{
			$sql="DELETE FROM ".$Database.".`tradingrequest` WHERE (`typ`='Arbitrage_Sell' OR `typ`='Arbitrage_Buy')
			                                                  AND (`sended`='0' OR `market_or_limit`='Startentry')
															  AND `coin`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$symbol))."'";
					
             if(!mysqli_query($DatabasePointer,$sql)) 
               {
                 die('DELETE Arbitrage Traderequest Error: ' . mysqli_error($DatabasePointer)); 
               }
		
		$name=$symbol;
		$filename="files/StartBTC".$name."Start.txt";if(file_exists($filename))unlink($filename);
		$filename="files/StartBTC".$name."Startfile.txt";if(file_exists($filename))unlink($filename);
		$filename="files/BuyBTC".$name."Entry.txt";if(file_exists($filename))unlink($filename);
		$filename="files/SellBTC".$name."Entry.txt";if(file_exists($filename))unlink($filename);
		$filename="files/BuyBTC".$name."Exit.txt";if(file_exists($filename))unlink($filename);
		$filename="files/SellBTC".$name."Exit.txt";if(file_exists($filename))unlink($filename);
		}

		
	}											
	}
	else if(isset($_GET['ReadBuyandHold']))
	{
		
		$Seite=0;if(isset($_GET['PaginationSeite2']))$Seite=$_GET['PaginationSeite2']; if($Seite<1)$Seite=1;
 
		$sql="Select `id`,`typ`,`buyholdpercent` FROM ".$Database.".`tradingrequest` WHERE `typ`='BuyAndHold' AND `buyholdpercent`!=''";
		$result = mysqli_query($DatabasePointer,$sql); 
		if($error = mysqli_error($DatabasePointer)) die('Error, Read Traderequest Anzahl Buy Hold query failed with:' . $error);
		$RowSeiten=mysqli_num_rows($result);
		 
		//--Startzahl fuer Limitangabe finden
		if($Seite==1)$start=0;
		else 
		$start=($Seite*5)-5;

		//--Buy and Hold Entrys zeigen
		$sql="Select `id`,`typ`,`broker`,`symbol`,`coin`,`volumebtc`,`volumeusd`,`volumecoin`,`buyholdpercent`,`tpbtcprice`,`tpusdprice`,`tpusdvalue`,`slbtcprice`,`slusdprice`,`slusdvalue`,`result`,`btcpricemysql`,`tpsltraded`,`buyholdbesitz`,`maxtrades`,`tradesgemachtbh` FROM ".$Database.".`tradingrequest` WHERE `typ`='BuyAndHold' AND `buyholdpercent`!='' ORDER BY `id` DESC LIMIT ".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$start)).",5";
		$result = mysqli_query($DatabasePointer,$sql); 
		if($error = mysqli_error($DatabasePointer)) die('Error, Read Traderequest query failed with:' . $error);
		$rowcount=mysqli_num_rows($result);

		if($rowcount>0)
		{
		   while($row = mysqli_fetch_array($result))
				 {
					 
					 $besitz="";
					 $tpsl="";
					 $maxtr="";
					 $tpsltraded=0;
					 if($row['tpsltraded']==1)
					 {
						 if($row['result']=="Close at Stoploss"){$tpsl='<span class="buyholdsl">&nbsp;</span>'; $tpsltraded=2;}
						 else
						 if($row['result']=="Close at Takeprofit"){$tpsl='<span class="buyholdtp">&nbsp;</span>'; $tpsltraded=1;}
					 }
					 if($row['result']=="Error volume to big" || $row['result']=="Error volume to small"){$tpsl='<span class="bherrorclose">&nbsp;</span>'; $tpsltraded=1;}
					 if($row['tradesgemachtbh']>=$row['maxtrades'])
					 {
						 $maxtr='<span class="maxtr">&nbsp;</span>';
					 }
					 if($row['buyholdbesitz']>0){$besitz=substr($row['buyholdbesitz'],0,10)."  ".$row['symbol']; }
					 else {$besitz="0 ".$row['symbol'];}
					 echo '
					  <p class="buyholdinfobox">
							<span class="buyholdentry">
							  '.$row['coin'].': '.$besitz.' '.$maxtr.' '.$tpsl.'
							  <span class="buyholdmodify" onclick="OpenTradePanel(\''.$row['coin'].'\',\'BuyHold\',\''.$row['broker'].'\')">&nbsp;</span>
							</span>
						</p>';
				 }
				 if($RowSeiten>5)
					{
					  $pages=ceil($RowSeiten/5);
					  if($Seite==1)
					  {
						  echo '<span id="tradereqnav2">
								   Page '.$Seite.' of '.$pages.'&nbsp;&nbsp;<span class="nextsitebutton" onclick="Pagination2(\'plus\')">&raquo;</span>
								</span>';
					  }
					  else if($Seite>1&&$Seite<$pages)
					  {
						  echo '<span id="tradereqnav2">
								   <span class="nextsitebutton" onclick="Pagination2(\'minus\')">&laquo;</span>&nbsp;&nbsp;Page '.$Seite.' of '.$pages.'&nbsp;&nbsp;<span class="nextsitebutton" onclick="Pagination2(\'plus\')">&raquo;</span>
								</span>';
					  }
					  else if($Seite==$pages)
					  {
						  echo '<span id="tradereqnav2">
								   <span class="nextsitebutton" onclick="Pagination2(\'minus\')">&laquo;</span>&nbsp;&nbsp;Page '.$Seite.' of '.$pages.'
								</span>';
					  }
					  echo '<span id="maxpages2">'.$pages.'</span>';
					}
		}
		else 
		{
			echo '<p style="border-radius:10px;background:blue;color:white;margin: 10px 0 0 0;padding:15px;text-align:center;font-size:20px">Actually No Buy And Hold Positions</p>';
		}
	}
?>