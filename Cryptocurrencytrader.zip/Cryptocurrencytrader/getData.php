<?php 


 //--
 $symbol="BTCUSDT";
 $timeframe="D1";
 $broker="Binance";
 $name="Bitcoin";
 if(isset($_GET['symbol']))$symbol=$_GET['symbol'];
 if(isset($_GET['timeframe']))$timeframe=$_GET['timeframe'];
 if(isset($_GET['broker']))$broker=$_GET['broker'];
 if(isset($_GET['name']))$name=$_GET['name'];



 //--
 $chartkurse="Textdateien_Charts_USD/".$broker."_USDChart_".$symbol."_".$timeframe.".txt";


 //-
 if(file_exists($chartkurse))
   {
    $differeneFilezeit=abs(filemtime($chartkurse)-time());
    if($differeneFilezeit>350)unlink($chartkurse);
   }


 if(file_exists($chartkurse))
   {
      echo '[';
      $page = file_get_contents($chartkurse);
      $page = json_decode($page,true);
      $a=0;
      for($i=0; $i<count($page["Chart"]); $i++)
      {
        if($a>0)echo ',';
        echo "[\"".$i."\", ".str_replace(",","",$page["Chart"][$i]["high"]).", ".str_replace(",","",$page["Chart"][$i]["open"]).", ".str_replace(",","",$page["Chart"][$i]["close"]).", ".str_replace(",","",$page["Chart"][$i]["low"])."]
        ";
        $a++;
      }
      echo ']';
    }
    
    else
    
    {
      if($broker=="Poloniex")
        {
         $url="http://".$_SERVER['SERVER_NAME'].''.$_SERVER['SCRIPT_NAME'];
         $url=str_replace("getData.php","Save_Chartdata_Poloniex_2.php",$url);
         $url=$url."?symbol=".$symbol."&timeframe=".$timeframe."&name=".$name;
         echo file_get_contents($url);
        }

      else

      if($broker=="Binance")
        {
         $url="http://".$_SERVER['SERVER_NAME'].''.$_SERVER['SCRIPT_NAME'];
         $url=str_replace("getData.php","Save_Chartdata_Binance_2.php",$url);
         $url=$url."?symbol=".$symbol."&timeframe=".$timeframe."&name=".$name;
         echo file_get_contents($url);
        }

      else

      if($broker=="Huobi")
        {
         $url="http://".$_SERVER['SERVER_NAME'].''.$_SERVER['SCRIPT_NAME'];
         $url=str_replace("getData.php","Save_Chartdata_Huobi_2.php",$url);
         $url=$url."?symbol=".$symbol."&timeframe=".$timeframe."&name=".$name;
         echo file_get_contents($url);
        }

      else

      if($broker=="HitBTC")
        {
         $url="http://".$_SERVER['SERVER_NAME'].''.$_SERVER['SCRIPT_NAME'];
         $url=str_replace("getData.php","Save_Chartdata_Hitbtc_2.php",$url);
         $url=$url."?symbol=".$symbol."&timeframe=".$timeframe."&name=".$name;
         echo file_get_contents($url);
        }
      else

      if($broker=="Okex")
        {
         $url="http://".$_SERVER['SERVER_NAME'].''.$_SERVER['SCRIPT_NAME'];
         $url=str_replace("getData.php","Save_Chartdata_Okex_2.php",$url);
         $url=$url."?symbol=".$symbol."&timeframe=".$timeframe."&name=".$name;
         echo file_get_contents($url);
        }
    }

?>