<?php
$file=$_GET['file'];
$file=str_replace(" ","-",$file);
$string = file_get_contents($file);
echo $string;
?>