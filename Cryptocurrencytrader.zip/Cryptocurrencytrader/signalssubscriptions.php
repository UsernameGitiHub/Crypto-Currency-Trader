<?php

  //+-----------------------------------------------------------+
  //| Datenbank Verbindung aufrufen                             |
  //+-----------------------------------------------------------+

      include('dbcon.php');

	 			
	  $Seite=0;if(isset($_GET['PaginationSeite5']))$Seite=$_GET['PaginationSeite5']; if($Seite<1)$Seite=1;
 
	  $sql="Select * FROM ".$Database.".`tradingrequest` WHERE (`typ`='SignalBuy' OR `typ`='SignalSell' OR `typ`='SignalBuyAndSell')  AND `tradesignalnow`='0'";
	  $result = mysqli_query($DatabasePointer,$sql); 
	  if($error = mysqli_error($DatabasePointer)) die('Error, Read Traderequest Signal Sub Anzahl query failed with:' . $error);
	  $RowSeiten=mysqli_num_rows($result);
	 
      //--Startzahl fuer Limitangabe finden
	  if($Seite==1)$start=0;
	  else 
	  $start=($Seite*8)-8;




     $sql="Select * FROM ".$Database.".`tradingrequest` WHERE (`typ`='SignalBuy' OR `typ`='SignalSell' OR `typ`='SignalBuyAndSell') AND `tradesignalnow`='0' ORDER BY `id` DESC LIMIT ".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$start)).",8";
     $result = mysqli_query($DatabasePointer,$sql); 
     if($error = mysqli_error($DatabasePointer)) die('Error, Read Signals Sub query failed with:' . $error);
     $i=0;

      while($row = mysqli_fetch_array($result))
	   {
				 
				 echo '<p class="buyholdinfobox">
						<span class="buyholdentry">
							'.$row['coin'].'
							<span class="buyholdmodify" onclick="OpenTradePanel(\''.$row['coin'].'\',\'Signal\')">&nbsp;</span>
						</span>
					   </p>';
				 
				 $i++;
	   }//while
	   if($RowSeiten>8)
	   {
			$pages=ceil($RowSeiten/8);
			if($Seite==1)
			{
				echo '<span id="tradereqnav5">
					    Page '.$Seite.' of '.$pages.'&nbsp;&nbsp;<span class="nextsitebutton2" onclick="Pagination5(\'plus\')">&raquo;</span>
					  </span>';
			}
			else if($Seite>1&&$Seite<$pages)
			{
				echo '<span id="tradereqnav5">
						<span class="nextsitebutton2" onclick="Pagination5(\'minus\')">&laquo;</span>&nbsp;&nbsp;Page '.$Seite.' of '.$pages.'&nbsp;&nbsp;<span class="nextsitebutton2" onclick="Pagination5(\'plus\')">&raquo;</span>
					  </span>';
			}
			else if($Seite==$pages)
			{
				echo '<span id="tradereqnav5">
					    <span class="nextsitebutton2" onclick="Pagination5(\'minus\')">&laquo;</span>&nbsp;&nbsp;Page '.$Seite.' of '.$pages.'
					  </span>';
			}
			echo '<span id="maxpages5">'.$pages.'</span>';
	    }
?>