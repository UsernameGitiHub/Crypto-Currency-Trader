<?php 
$filename=$_GET['file'];
if($filename!="leer.txt")
{
  $text=$_GET['text'];
  $myfile = fopen($filename, "w");
  fwrite($myfile, $text);
  fclose($myfile);
}
?>