<?php
  //+-----------------------------------------------------------+
  //| Datenbank Verbindung aufrufen                             |
  //+-----------------------------------------------------------+

     include('dbcon.php');

	if(isset($_GET['TraderequestDo'])&&true)
	{
	  //--Alle unausgefuehrten Auftraege
	  $sql="Select * FROM ".$Database.".`tradingrequest` WHERE (`sended`='0' AND `tradesignalnow`='1' AND `typ`!='Arbitrage') 
	                                                                        OR ((`tpusdprice`!='' OR 
																				 `tpusdvalue`!='' OR 
																				 `tpbtcprice`!='' OR
																				 `slusdprice`!='' OR 
																				 `slusdvalue`!='' OR 
																				 `slbtcprice`!=''   ) 
																				  AND `tpsltraded`='0'  
																				  AND `tradesignalnow`='1' 
																				  AND `typ`!='Arbitrage')
																				  
																				 ORDER BY `createdtimestamp` LIMIT 10";
	  $result = mysqli_query($DatabasePointer,$sql); 
	  if($error = mysqli_error($DatabasePointer)) die('Error, Read Traderequest query failed with:' . $error);
	  $rowcount=mysqli_num_rows($result);
	  $lastbroker=""; //Damit nicht zur gleichen Sekunde der gleiche broker mehr als ein auftrag bekommt
	  
	  //--

	  if($rowcount>0)
	  {
		$i=0;
		while($row = mysqli_fetch_array($result))
			 {
				 $err=strpos($row['result'],"Error",0);
				 if($err>=0 && $err!==false && $row['typ']!="BuyAndHold")
				 {
					 $sql="UPDATE ".$Database.".`tradingrequest` SET `tpsltraded`='1' WHERE `id`='".$row['id']."';";
					 if(!mysqli_query($DatabasePointer,$sql)) 
						{
						  die('Updtae Traderequest Error: ' . mysqli_error($DatabasePointer)); 
						}
						continue;
				 }
				 
			  //+-----------------------------------------------------------+
			  //|                                                           |
			  //+-----------------------------------------------------------+

			        $buyorsell="";
					$lastbuyprice="";
					$buyholdbesitz="";
					$buyholdprozent="";
					$tradesgemachtbh=0;
					$maxtrades=0;
					$volume="";
					$volumeeinheit="";
					$tp=0; $tpein="";
					$sl=0; $slein="";
					$tpordertype="";
					$url="";
					
					//--Takeprofit
					if($row['tpbtcprice']>0){$tp=$row['tpbtcprice']; $tpein="btc";}
					else
					if($row['tpusdvalue']>0){$tp=$row['tpusdvalue']; $tpein="win";}
					else
					if($row['tpusdprice']>0){$tp=$row['tpusdprice']; $tpein="usd";}
				
					//--Stoploss
					if($row['slbtcprice']>0){$sl=$row['slbtcprice']; $slein="btc";}
					else
					if($row['slusdvalue']>0){$sl=$row['slusdvalue']; $slein="win";}
					else
					if($row['slusdprice']>0){$sl=$row['slusdprice']; $slein="usd";}
					
					//--Long oder Short handeln Befehl speichern
					if($row['typ']=="MarketBuy" || $row['typ']=="MarketSell")
					{
						if($row['market_or_limit']=="marketprice")
						{
							if($row['typ']=="MarketBuy")$buyorsell="buy";
							else
							if($row['typ']=="MarketSell")$buyorsell="sell";
							$tpordertype=$buyorsell;
						}
						if($row['market_or_limit']=="limitprice")
						{
							if($row['typ']=="MarketBuy"){$buyorsell="buylimit"; $tpordertype="buy";}
							else
							if($row['typ']=="MarketSell"){$buyorsell="selllimit"; $tpordertype="sell";}
						}
						if($row['result']=="Successful")$buyorsell="tpsl";
						if($row['sended']=="1")$buyorsell="tpsl";
						
					}
					else
					if($row['typ']=="BuyAndHold")
					{
						$buyorsell="buyandhold";
						$lastbuyprice=$row['ausfuehrungsprice'];
						$buyholdprozent=$row['buyholdpercent'];
						$buyholdbesitz=$row['buyholdbesitz'];
						$maxtrades=$row['maxtrades'];
						$tradesgemachtbh=$row['tradesgemachtbh'];
					}
					else 
					if($row["typ"]=="SignalBuy" || $row["typ"]=="SignalSell" || $row["typ"]=="SignalBuyAndSell")
					{
						$buyorsell="";
						if($row['signalrichtung']==1)$buyorsell="buy";
						else
						if($row['signalrichtung']==2)$buyorsell="sell";
						$tpordertype=$buyorsell;
						if($row['result']=="Successful")$buyorsell="tpsl";
						if($row['sended']=="1")$buyorsell="tpsl";
					}
					//--
					$volume=$row['btcpricemysql']; //Das ist der btcprice der im tradeformular auch ausgerechnet wird
					//--
					$url.="?buyorsell=".$buyorsell."&volume=".$volume."&name=".$row['coin']."&id=".$row['id']."&limitusd=".$row['limitusdprice'];
					$url.="&limitbtc=".$row['limitbtcprice']."&tp=".$tp."&tpein=".$tpein."&tpordertype=".$tpordertype."&sl=".$sl."&slein=".$slein;
					$url.="&volumebtc=".$row['volumebtc']."&volumeusd=".$row['volumeusd']."&volumecoin=".$row['volumecoin']."&lastbuyprice=".$lastbuyprice;
					$url.="&buyholdbesitz=".$buyholdbesitz."&buyholdprozent=".$buyholdprozent."&maxtrades=".$maxtrades."&tradesgemachtbh=".$tradesgemachtbh;
					$url=str_replace(' ', '', $url);
					//--

					if($lastbroker!=$row['broker'])
					{
						//--
						$url2="http://".$_SERVER['SERVER_NAME'].''.$_SERVER['SCRIPT_NAME'];
						$fnm=strtolower($row['broker'])."api.php";
						$url=str_replace("ExchangesApis.php",$fnm,$url2)."".$url;
						//--
						$lastbroker=$row['broker'];
						echo $row['broker'].' ExchangesApi '.$row['typ'].' '.file_get_contents($url);	
						//--
					}


			 }//while
	  } else echo 'noentrys';
	}






    //+-----------------------------------------------------------+
    //| Read Balances                                             |
    //+-----------------------------------------------------------+

	if(isset($_GET['Balances']))
	{
		$str=file_get_contents("apis.txt");
		$Apis = json_decode($str, true);
			
			//--Tradingrequests durch gehen	    
			for($i=0; $i<count($Apis["Api"]); $i++)
			{
				if($Apis["Api"][$i]["exchange"]==$_GET['Exchange'])
				{
					if($Apis["Api"][$i]["tradingkey"]!="" && $Apis["Api"][$i]["tradingsec"]!="")
					{
						//--
						$url="http://".$_SERVER['SERVER_NAME'].''.$_SERVER['SCRIPT_NAME'];
						$fnm=strtolower($_GET['Exchange'])."api.php";
						$url=str_replace("ExchangesApis.php",$fnm,$url);
						//--
						$url.="?OpenTrades=1";
						echo file_get_contents($url);
					}
				}
			}
	}

	


    //+-----------------------------------------------------------+
    //| Read Pendingorders                                        |
    //+-----------------------------------------------------------+

	if(isset($_GET['Orders']))
	{
		$str=file_get_contents("apis.txt");
		$Apis = json_decode($str, true);
			
			//--Tradingrequests durch gehen	    
			for($i=0; $i<count($Apis["Api"]); $i++)
			{
				if($Apis["Api"][$i]["exchange"]==$_GET['Exchange'])
				{
					if($Apis["Api"][$i]["tradingkey"]!="" && $Apis["Api"][$i]["tradingsec"]!="")
					{
						//--
						$url="http://".$_SERVER['SERVER_NAME'].''.$_SERVER['SCRIPT_NAME'];
						$fnm=strtolower($_GET['Exchange'])."api.php";
						$url=str_replace("ExchangesApis.php",$fnm,$url);
						//--
						$url.="?OpenPendings=1";
						echo file_get_contents($url);
					}
				}
			}
	}



    //+-----------------------------------------------------------+
    //| Delete Pendingorder                                       |
    //+-----------------------------------------------------------+

	if(isset($_GET['DeletePending']))
	{
		//--
		$url="http://".$_SERVER['SERVER_NAME'].''.$_SERVER['SCRIPT_NAME'];
		$fnm=strtolower($_GET['broker'])."api.php";
		$url=str_replace("ExchangesApis.php",$fnm,$url);
		//--
		$url.="?DeletePending=".$_GET['DeletePending']."&nam=".$_GET['nam']."&priceeinh=".$_GET['priceeinh'];
		echo file_get_contents($url);
		
	}


	
	
	

	//+-----------------------------------------------------------+
    //| Show Traderequest History                                 |
    //+-----------------------------------------------------------+

	if(isset($_GET['TraderequestRead']))
	{
	  $Seite=$_GET['PaginationSeite'];
	 
	  $sql="Select `id`,`tradesignalnow`,`typ`,`buyholdpercent` FROM ".$Database.".`tradingrequest` WHERE `tradesignalnow`!='0' AND `typ`!='Arbitrage' AND (`buyholdpercent`='' OR `typ`!='BuyAndHold')";
	  $result = mysqli_query($DatabasePointer,$sql); 
	  if($error = mysqli_error($DatabasePointer)) die('Error, Read Traderequest Anzahl query failed with:' . $error);
	  $rowcount=mysqli_num_rows($result);
	 
	  //--Startzahl fuer Limitangabe finden
	  if($Seite==1)$start=0;
	  else $start=($Seite*3)-3;

	  //--
	  $sql="Select `id`,`broker`,`symbol`,`coin`,`typ`,`market_or_limit`,`limitbtcprice`,`limitusdprice`,`volumebtc`,`volumeusd`,`volumecoin`,`result`,`createdtimestamp`,`tradesignalnow`,`signalrichtung` FROM ".$Database.".`tradingrequest` WHERE `tradesignalnow`!='0' AND `typ`!='Arbitrage'  AND (`buyholdpercent`='' OR `typ`!='BuyAndHold') ORDER BY `id` DESC LIMIT ".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$start)).",3";
	  $result = mysqli_query($DatabasePointer,$sql); 
	  if($error = mysqli_error($DatabasePointer)) die('Error, Read Traderequest Entrys query failed with:' . $error);
	  $i=0;
	  if($rowcount>0)
	  {
		while($row = mysqli_fetch_array($result))
			 {
			   $volume=0; if($row["volumebtc"]>0)$volume=$row["volumebtc"].' BTC'; else if($row["volumeusd"]>0)$volume=$row["volumeusd"].' USD'; else if($row["volumecoin"]>0)$volume=$row["volumecoin"].' '.$row["symbol"];
			   $typ="";$typ2=""; 
						if($row["typ"]=="MarketBuy")
						  {
							  $typ="Market Order";
							  if($row["market_or_limit"]=="marketprice")$typ2="Buy at market price";
							  else
							  if($row["market_or_limit"]=="limitprice")
							  {
								  $typ="Market Order Limitprice";
								  if($row["limitbtcprice"]!="")$typ2="Buylimit at ".$row["limitbtcprice"]." BTC";
								  else
								  if($row["limitusdprice"]!="")$typ2="Buylimit at ".$row["limitusdprice"]." USD";
								  else $typ2="Buylimit no price given";
							  }
						  } 
						else
						if($row["typ"]=="MarketSell")
						  {
							  $typ="Market Order";
							  if($row["market_or_limit"]=="marketprice")$typ2="Sell at market price";
							  else
							  if($row["market_or_limit"]=="limitprice")
							  {
								  $typ="Market Order Limitprice";
								  if($row["limitbtcprice"]!="")$typ2="Selllimit at ".$row["limitbtcprice"]." BTC";
								  else
								  if($row["limitusdprice"]!="")$typ2="Selllimit at ".$row["limitusdprice"]." USD";
								  else $typ2="Selllimit no price given";
							  }
						  }
						else
						if($row["typ"]=="BuyAndHold")
						  {
							  $typ="Buy And Hold Order";
							  $typ2="Buy at market price";
							  
						  } 
						else
						if($row["typ"]=="SignalBuy" || $row["typ"]=="SignalSell" || $row["typ"]=="SignalBuyAndSell")
						  {
							  $typ="Signal Order";
							  if($row['signalrichtung']==1)$typ2="Buy at market price";
							  else
							  if($row['signalrichtung']==2)$typ2="Sell at market price";
						  }
						  
						  $requestresult=""; 
						  if($row["result"]=="" || $row["result"]=="Pending")
							{
								$requestresult='Pending awaiting result.</span><span class="tradeinfo5"></span>';
							}
						  else if($row["result"]=="Successful")
							{
								$requestresult='Successful traded.</span><span class="tradeinfo3"></span>';
							}
						  else if($row["result"]=="Close at Takeprofit")
							{
								$requestresult='Close at Takeprofit.</span><span class="tradeinfo3"></span>';
							}
						  else if($row["result"]=="Close at Stoploss")
							{
								$requestresult='Close at Stoploss.</span><span class="tradeinfo3"></span>';
							}
						  else if($row["result"]=="Error volume to small" || $row["result"]=="Error volume to big" || $row["result"]=="Error no limitprice")
							{
								$requestresult=$row["result"].'.</span><span class="tradeinfo4"></span>';
							}
						  else if($row["result"]=="Error Invalid currencyPair")
							{
								$requestresult=$row["result"].'.</span><span class="tradeinfo4"></span>';
							}
						  
			   $i++;
			   //$Nr=$i+(($Seite*3)-3);
			   $Nr=$row['id'];
			   $zeitabstand=abs(time()-$row['createdtimestamp']);
			   if($zeitabstand<=60)$datum=round($zeitabstand,0)." s. ago"; 
			   else 
			   if($zeitabstand<=3600)$datum=round($zeitabstand/60,0)." m. ago"; 
			   else 
			   if($zeitabstand>3600)$datum=round($zeitabstand/3600,0)." h. ago"; 
			   else 
			   if($zeitabstand>86400)$datum=round($zeitabstand/86400,0)." d. ago"; 
			   //--
			   echo '<span class="tradeinfobox">
					 <span class="tradeinfoubr">'.$typ.'  '.$datum.'<span class="tradereqnr">Trade ID: '.$Nr.'</span></span>
						<span class="tradeinfo">
								<span class="tradeinfo1">Exchange:</span>
								<span class="tradeinfo2">'.$row["broker"].'</span>
								<span class="clearfloat">&nbsp;</span>
								<span class="tradeinfo1">Currency:</span>
								<span class="tradeinfo2">'.$row["coin"].' ('.$row["symbol"].')</span>
								<span class="clearfloat">&nbsp;</span>
								<span class="tradeinfo1">Type:</span>
								<span class="tradeinfo2">'.$typ2.'</span>
								<span class="clearfloat">&nbsp;</span>
								<span class="tradeinfo1">Volume:</span>
								<span class="tradeinfo2">'.$volume.'</span>
								<span class="clearfloat">&nbsp;</span>
								<span class="tradeinfo1">Result:</span>
								<span class="tradeinfo2">'.$requestresult.'
								<span class="clearfloat">&nbsp;</span>
						</span>
					</span>';
			 }
			 
			if($rowcount>3)
			{
			  $pages=ceil($rowcount/3);
			  if($Seite==1)
			  {
				  echo '<span id="tradereqnav">
						   Page '.$Seite.' of '.$pages.'&nbsp;&nbsp;<span class="nextsitebutton" onclick="Pagination(\'plus\')">&raquo;</span>
						</span>';
			  }
			  else if($Seite>1&&$Seite<$pages)
			  {
				  echo '<span id="tradereqnav">
						   <span class="nextsitebutton" onclick="Pagination(\'minus\')">&laquo;</span>&nbsp;&nbsp;Page '.$Seite.' of '.$pages.'&nbsp;&nbsp;<span class="nextsitebutton" onclick="Pagination(\'plus\')">&raquo;</span>
						</span>';
			  }
			  else if($Seite==$pages)
			  {
				  echo '<span id="tradereqnav">
						   <span class="nextsitebutton" onclick="Pagination(\'minus\')">&laquo;</span>&nbsp;&nbsp;Page '.$Seite.' of '.$pages.'
						</span>';
			  }
			  echo '<span id="maxpages">'.$pages.'</span>';
			}
	  }
	}
?>