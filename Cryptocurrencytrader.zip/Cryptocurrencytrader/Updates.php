<?php


  set_time_limit(0);

  //+-----------------------------------------------------------+
  //| Datenbank Verbindung aufrufen                             |
  //+-----------------------------------------------------------+

     include('dbcon.php');

	function Coins_Token_Coinmarketcap_Speichern($url, $table, $Database, $DatabasePointer)
	{
		$content = file($url);
		$a=0;
		$b=0;
		$c=0;
		$coin="";
		$symbol="";
		$i2=0;

		$filename2=$table.".txt";
		$myfile2 = fopen($filename2, "w");
		$str = '{ "Coins":[ ';
		fwrite($myfile2, $str);

		for($i=0; $i<count($content); $i++)
		{
		 $pos = strpos($content[$i], "Active Markets");
 
		 if($pos>=0 && $pos!==false){$a=1;continue;}
		 if($a==1)
		   {
			 $pos = strpos($content[$i], "</table>");

			 if($pos>=0 && $pos!==false){$a=0;break;}

			 $pos = strpos($content[$i], "<table", $pos);

			 if($pos>=0 && $pos!==false){$b=1;continue;}
			 if($b==1)
			 {
			 $pos = strpos($content[$i], "<a", $pos);

			 if($pos>=0 && $pos!==false)
			 {
				if(strpos($content[$i], "name\">", $pos)>0)
				{
				
				$nr=strpos($content[$i], "currencies/", $pos)+11;
				$nr2=strpos($content[$i], "/", $nr);
				$lenght2=$nr2-$nr;
				$cmcid=substr($content[$i],$nr,$lenght2);

				$pos = strpos($content[$i], "name\">", $pos)+6;
				$pos2 = strpos($content[$i], "</a>", $pos);
				$lenght=$pos2-$pos;
				
				$str=substr($content[$i],$pos,$lenght);
				$coin=$str;
				$c=1;
				}//name>0
				if(strpos($content[$i], "_blank\">", $pos)>0 && $c==1)
				{
				$pos = strpos($content[$i], "_blank\">", $pos)+8;

				$pos2 = strpos($content[$i], "/", $pos);
				$lenght=$pos2-$pos;

				$str=substr($content[$i],$pos,$lenght);
				$symbol=$str;

			  
			

			  if($i2==0)$str = '  { "name":"'.$coin.'", "symbol":"'.$symbol.'", "cmcid":"'.$cmcid.'" }'."\r\n"; 
			  else      $str = ', { "name":"'.$coin.'", "symbol":"'.$symbol.'", "cmcid":"'.$cmcid.'" }'."\r\n"; 
			  fwrite($myfile2, $str);
			  $i2++;

				$Brokername="";
				if($table=="allcoins_binance")$Brokername="Binance";
				if($Brokername!="")
				{
					$sql = "INSERT INTO ".$Database.".`downloadliste_charts` (`broker`,`name`,`symbol`, `cmcid`) 
									  
						  VALUES 
								   
								 ('".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$Brokername))."',
								  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$coin))."',
								  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$symbol))."',
								  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$cmcid))."')
										
								  ON DUPLICATE KEY UPDATE broker=VALUES(broker),
														  name=VALUES(name),
														  symbol=VALUES(symbol),
														  cmcid=VALUES(cmcid)";

								  if(!mysqli_query($DatabasePointer,$sql)) 
									{
									  die('Save Coin Error: ' . mysqli_error($DatabasePointer)); 
									}
				}
		    
				$c=0;
				}//name>0
			 }//pos>0
			 }//$b==1
		   }//$a==1
		}//for

		//-- Datei Alle Coins
		$str =  ' ] }';
		fwrite($myfile2, $str);
		fclose($myfile2);
	}//function 




	$filename="LastUpdate1.txt";
	$zeit=0;
	if(file_exists($filename))
	{
	 $myfile = fopen($filename, "r");
	 if(filesize($filename)>0)$zeit=fread($myfile,filesize($filename));echo $zeit;
	 fclose($myfile);
	}
	if($zeit<time())
	{
		 $sql="SELECT * FROM `downloadliste_charts`";
		 $result = mysqli_query($DatabasePointer,$sql);
		 if($result !== FALSE)
		 {
		   echo "";
		 }
		 else
		 {
			 require_once('createtables.php');
		 }
		 
		 $myfile2 = fopen($filename, "w");
		 $str = time()+3600*24;
		 fwrite($myfile2, $str);
		 fclose($myfile2);
		 
		 Coins_Token_Coinmarketcap_Speichern('https://coinmarketcap.com/exchanges/binance/' , "allcoins_binance", $Database, $DatabasePointer);
		 
		 $filename = "Downloadliste_CoinsToken.txt";
		 $myfile = fopen($filename, "w");
		 $str = '{ "Coins":[ ';
		 fwrite($myfile, $str);

		 $sql="SELECT * FROM `downloadliste_charts`";
		 $result = mysqli_query($DatabasePointer,$sql) or die('Error1: ' . mysqli_error($DatabasePointer));
		 $i=0;

		 while($row = mysqli_fetch_array($result))
			  {
				 if($i==0)$str = '  { "broker":"'.$row['broker'].'", "name":"'.$row['name'].'", "symbol":"'.$row['symbol'].'", "cmcid":"'.$row['cmcid'].'" }'."\r\n"; 
				 else     $str = ', { "broker":"'.$row['broker'].'", "name":"'.$row['name'].'", "symbol":"'.$row['symbol'].'", "cmcid":"'.$row['cmcid'].'" }'."\r\n";
				 fwrite($myfile, $str);
				 $i++;
			  }

		 //--Datei downloadliste
		 $str =  ' ] }';
		 fwrite($myfile, $str);
		 fclose($myfile);
	}






  $filename="LastUpdate2.txt";
  $zeit=0;
  if(file_exists($filename))
  {
	 $myfile = fopen($filename, "r");
	 if(filesize($filename)>0)$zeit=fread($myfile,filesize($filename));
	 fclose($myfile);
  }
  if($zeit<time())
  {
    
    $myfile = fopen($filename, "w");
	$str = time()+3600; //3600 gleich 1 Stunde
	fwrite($myfile, $str);
	fclose($myfile);
		 


    $filename2="Signale.txt";
    $myfile2 = fopen($filename2, "w");
    $str = '{ "Signale":[ ';
    fwrite($myfile2, $str);

    $sql = "SELECT `date`,`broker`,`coin`,`cmcid`,`name`,`timeframe`,`richtung`,`signalpower` FROM `signale` ORDER BY `signale`.`date` DESC LIMIT 5000";
    $result = mysqli_query($DatabasePointer,$sql);
    $i=0;

    while($row = mysqli_fetch_array($result))
         {
          if($row['timeframe']=="D1" && $row['date']>=time()-(3600*150))
            {
               //-- Datei
               if($i==0)$str = '  { "timeframe":"'.$row['timeframe'].'", "coin":"'.$row['coin'].'", "cmcid":"'.$row['cmcid'].'", "name":"'.$row['name'].'", "broker":"'.$row['broker'].'", "richtung":"'.$row['richtung'].'", "signalpower":"'.$row['signalpower'].'"  }'."\r\n"; 
               else     $str = ', { "timeframe":"'.$row['timeframe'].'", "coin":"'.$row['coin'].'", "cmcid":"'.$row['cmcid'].'", "name":"'.$row['name'].'", "broker":"'.$row['broker'].'", "richtung":"'.$row['richtung'].'", "signalpower":"'.$row['signalpower'].'"  }'."\r\n"; 
               fwrite($myfile2, $str);
               $i++;
            } 
              
         }
             
  
    $str =  ' ] }';
    fwrite($myfile2, $str);
    fclose($myfile2);
	
	//--Alte Signale loeschen
	$loeschdate=time()-(24*3600*10);
	$sql="DELETE FROM ".$Database.".`signale` WHERE `date`<='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$loeschdate))."'";
    mysqli_query($DatabasePointer,$sql); 
    if($error = mysqli_error($DatabasePointer)) die('Error, Delete Signale query failed with:' . $error);

   }


?>