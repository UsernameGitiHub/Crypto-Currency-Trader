<?php

  //+-----------------------------------------------------------+
  //| Datenbank Verbindung aufrufen                             |
  //+-----------------------------------------------------------+

    include('dbcon.php');

    //--
    $Broker=array();
    $TradingKey=array();
    $TradingSec=array();


    //--
    $i=0;

   
	if(isset($_GET['trbinkey']))
	{
    $Broker[$i]="Binance";
    $TradingKey[$i]=$_GET['trbinkey'];
    $TradingSec[$i]=$_GET['trbinsec'];
	$i++;
	}
  
    //--
    //--
    for($i=0; $i<count($Broker); $i++)
    {
    if( 
	    $TradingKey[$i]!="" && $TradingSec[$i]!=""
	  )
	  {
              $sql = "INSERT INTO ".$Database.".`accounts` (`exchange`,
                                                            `trading_apikey`,
															`trading_apisec`
                                                           ) 
                          
              VALUES 
                       
                 ('".$Broker[$i]."',
                  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$TradingKey[$i]))."',
				  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$TradingSec[$i]))."',
				  '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$TradingEmail[$i]))."'
                 )
                            
                      ON DUPLICATE KEY UPDATE exchange=VALUES(exchange),
                                              trading_apikey=VALUES(trading_apikey),
                                              trading_apisec=VALUES(trading_apisec)";

                      if(!mysqli_query($DatabasePointer,$sql)) 
                        {
                          die('Save Accounts Error: ' . mysqli_error($DatabasePointer)); 
                        }
	    }
      }//for


 $sql="SELECT * FROM `accounts`";
 $result = mysqli_query($DatabasePointer,$sql) or die('Error1: ' . mysqli_error($DatabasePointer));
 $i=0;

 //-- Datei
 $filename2="Apis.txt";
 $myfile2 = fopen($filename2, "w");
 $str = '{ "Api":[ ';
 fwrite($myfile2, $str);

 while($row = mysqli_fetch_array($result))
      {
         if($i==0)$str= '  { "exchange":"'.$row['exchange'].'", "tradingkey":"'.$row['trading_apikey'].'", "tradingsec":"'.$row['trading_apisec'].'" }'."\r\n"; 
         else     $str= ', { "exchange":"'.$row['exchange'].'", "tradingkey":"'.$row['trading_apikey'].'", "tradingsec":"'.$row['trading_apisec'].'" }'."\r\n"; 
         fwrite($myfile2, $str);
         $i++;
      }

 //-- Datei
 $str =  ' ] }';
 fwrite($myfile2, $str);
 fclose($myfile2);

?>