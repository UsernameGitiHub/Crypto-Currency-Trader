<?php


  //+-----------------------------------------------------------+
  //| Datenbank Verbindung aufrufen                             |
  //+-----------------------------------------------------------+

     include('dbcon.php');


     $typ=$_GET['typ'];
     $broker=$_GET['broker'];
     $symbol=$_GET['symbol'];
     $coin=$_GET['coin'];
     $market_or_limit=$_GET['market_orLimit'];
     $limitusdprice=$_GET['limitusdprice'];
     $limitbtcprice=$_GET['limitbtcprice'];
     $volumeusd=$_GET['volumeusd'];
     $volumebtc=$_GET['volumebtc'];
     $volumecoin=$_GET['volumecoin'];
	 $btcpricemysql=$_GET['btcpricemysql'];
     $buyholdpercent=$_GET['buyholdpercent'];
     $maxtrades=$_GET['maxtrades'];
	 $brokersarbitrage=$_GET['brokersarbitrage'];
     $arbitragepercententry=$_GET['arbitragepercententry'];
     $arbitragepercentexit=$_GET['arbitragepercentexit'];
     $tpusdprice=$_GET['tpusdprice'];
     $tpusdvalue=$_GET['tpusdvalue'];
     $tpbtcprice=$_GET['tpbtcprice'];
     $slusdprice=$_GET['slusdprice'];
     $slusdvalue=$_GET['slusdvalue'];
     $slbtcprice=$_GET['slbtcprice'];
	 $tradesignalnow=1;
	 $signalrichtung=0;
	 
	 if($buyholdpercent<=0)$buyholdpercent=5;

	 
	 
	 if($volumeusd<=0 && $volumebtc<=0 && $volumecoin<=0)
	   {
		 echo "no volume";
		 exit();
	   }

	 $code="";
	 if(strpos($typ,"Market",0)!==false)$code='Market_'.$symbol.'_'.time();
	 else
	 if(strpos($typ,"Signal",0)!==false){$code='Signal_'.$coin; $tradesignalnow=0;}
     else
	 if(strpos($typ,"Hold",0)!==false){$code='BuyAndHold_'.$coin; if($_GET['SignalEntryBH']==1){$tradesignalnow=0;$signalrichtung=1;}}
     else
	 if(strpos($typ,"Arbitrage",0)!==false)$code='Arbitrage_'.$coin;

	 //--
     
	 $sended=0; if($typ=="Arbitrage")$sended=1;

	 if(strpos($typ,"Hold",0)!==false)
	 {
	 $sql="Select `typ`,`coin`,`buyholdbesitz` FROM ".$Database.".`tradingrequest` 
		                                                          WHERE `coin`='".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$coin))."'
		                                                          AND `typ`='BuyAndHold'";
	 $result = mysqli_query($DatabasePointer,$sql); 
	 if($error = mysqli_error($DatabasePointer)) die('Error, Read Arbitrage Traderequest Anzahl:' . $error);
	 if(mysqli_num_rows($result)>0)$tradesignalnow=1;
	 }


	 
	 $sql="INSERT INTO ".$Database.".`tradingrequest` (`code`,
	                                                   `typ`,
													   `broker`,
													   `symbol`,
													   `coin`,
													   `market_or_limit`,
													   `limitusdprice`,
													   `limitbtcprice`,
													   `volumeusd`,
													   `volumebtc`,
													   `volumecoin`,
													   `buyholdpercent`,
													   `brokersarbitrage`,
													   `arbitragepercententry`,
													   `arbitragepercentexit`,
													   `tpusdprice`, 
													   `tpusdvalue`, 
													   `tpbtcprice`, 
													   `slusdprice`, 
													   `slusdvalue`, 
													   `slbtcprice`, 
													   `sended`,
													   `createdtimestamp`,
													   `btcpricemysql`,`tradesignalnow`,`signalrichtung`,`maxtrades`)
													   
	    VALUES 
	               ('".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$code))."',
				    '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$typ))."',
                    '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$broker))."',
                    '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$symbol))."',
                    '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$coin))."',
					'".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$market_or_limit))."',
                    '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$limitusdprice))."',
                    '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$limitbtcprice))."',
                    '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$volumeusd))."',
                    '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$volumebtc))."',
                    '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$volumecoin))."',
                    '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$buyholdpercent))."',
                    '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$brokersarbitrage))."',
                    '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$arbitragepercententry))."',
                    '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$arbitragepercentexit))."',
                    '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$tpusdprice))."',
                    '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$tpusdvalue))."',
                    '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$tpbtcprice))."',
                    '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$slusdprice))."',
                    '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$slusdvalue))."',
                    '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$slbtcprice))."',
					'".$sended."',
					'".time()."',
                    '".htmlspecialchars(mysqli_real_escape_string($DatabasePointer,$btcpricemysql))."','".$tradesignalnow."','".$signalrichtung."','".$maxtrades."')

					ON DUPLICATE KEY UPDATE code=VALUES(code),
                                            typ=VALUES(typ),
                                            broker=VALUES(broker),
                                            symbol=VALUES(symbol),
                                            coin=VALUES(coin),
											market_or_limit=VALUES(market_or_limit),
										    limitusdprice=VALUES(limitusdprice),
											limitbtcprice=VALUES(limitbtcprice),
										    volumeusd=VALUES(volumeusd),
											volumebtc=VALUES(volumebtc),
											volumecoin=VALUES(volumecoin),
											buyholdpercent=VALUES(buyholdpercent),
											brokersarbitrage=VALUES(brokersarbitrage),
											arbitragepercententry=VALUES(arbitragepercententry),
											arbitragepercentexit=VALUES(arbitragepercentexit),
											tpusdprice=VALUES(tpusdprice),
										    tpusdvalue=VALUES(tpusdvalue),
											tpbtcprice=VALUES(tpbtcprice),
										    slusdprice=VALUES(slusdprice),
											slusdvalue=VALUES(slusdvalue),
										    slbtcprice=VALUES(slbtcprice),
										    btcpricemysql=VALUES(btcpricemysql),
										    tradesignalnow=VALUES(tradesignalnow),
										    signalrichtung=VALUES(signalrichtung),
										    maxtrades=VALUES(maxtrades);";
					

                      if(!mysqli_query($DatabasePointer,$sql)) 
                        {
                          die('Save Traderequest Error: ' . mysqli_error($DatabasePointer)); 
                        } 
					  else echo 'saved';
	
	
?>