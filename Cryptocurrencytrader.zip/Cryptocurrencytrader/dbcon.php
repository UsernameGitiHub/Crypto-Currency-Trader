<?php

  //+-----------------------------------------------------------+
  //| Datenbank Verbindung aufrufen                             |
  //+-----------------------------------------------------------+

    $DatabaseHost = "localhost";
    $DatabaseUser = "root";
    $DatabasePassword = "";
    $Database = "test";

    $DatabasePointer = mysqli_connect($DatabaseHost,$DatabaseUser,$DatabasePassword,$Database);
    
    if(mysqli_connect_errno($DatabasePointer))
    {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
?>