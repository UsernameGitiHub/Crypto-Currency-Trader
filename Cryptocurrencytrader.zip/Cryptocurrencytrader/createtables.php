<?php

  //+-----------------------------------------------------------+
  //| Datenbank Verbindung aufrufen                             |
  //+-----------------------------------------------------------+

    include('dbcon.php');
 
      $sql="CREATE TABLE `downloadliste_charts` (
		  `broker` varchar(250) NOT NULL,
		  `name` varchar(250) NOT NULL,
		  `symbol` varchar(250) NOT NULL,
		  `cmcid` varchar(250) NOT NULL,
		  `cap` varchar(100) NOT NULL,
		  `change7` varchar(100) NOT NULL,
		  `usdprice` varchar(100) NOT NULL
		  ) ENGINE=InnoDB DEFAULT CHARSET=latin1;";mysqli_query($DatabasePointer,$sql);

		  $sql="ALTER TABLE `downloadliste_charts`
		  ADD UNIQUE KEY `name` (`name`);";mysqli_query($DatabasePointer,$sql);

		  $sql="CREATE TABLE `signale` (
		  `id` int(11) NOT NULL,
		  `date` varchar(250) NOT NULL,
		  `signalcode` varchar(250) NOT NULL,
		  `broker` varchar(250) NOT NULL,
		  `coin` varchar(250) NOT NULL,
		  `cmcid` varchar(250) NOT NULL,
		  `name` varchar(250) NOT NULL,
		  `timeframe` varchar(250) NOT NULL,
		  `richtung` varchar(10) NOT NULL,
		  `signalpower` int(10) NOT NULL,
		  `averagemove` varchar(100) NOT NULL,
		  `buyzone` varchar(250) NOT NULL,
		  `high` varchar(100) NOT NULL,
		  `low` varchar(100) NOT NULL
		) ENGINE=InnoDB DEFAULT CHARSET=latin1;";mysqli_query($DatabasePointer,$sql);

		$sql="ALTER TABLE `signale`
		  ADD PRIMARY KEY (`id`),
		  ADD UNIQUE KEY `signalcode` (`signalcode`);";mysqli_query($DatabasePointer,$sql);

		$sql="ALTER TABLE `signale`
		  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;";mysqli_query($DatabasePointer,$sql);
		  
		  
		$sql="CREATE TABLE `accounts` (
		  `exchange` varchar(250) NOT NULL,
		  `trading_apikey` varchar(250) NOT NULL,
		  `trading_apisec` varchar(250) NOT NULL,
		  `email` varchar(250) NOT NULL
		) ENGINE=InnoDB DEFAULT CHARSET=latin1;";mysqli_query($DatabasePointer,$sql);

		$sql="ALTER TABLE `accounts`
		  ADD UNIQUE KEY `exchange` (`exchange`);";mysqli_query($DatabasePointer,$sql);



		$sql="CREATE TABLE `tradingrequest` (
		  `id` int(11) NOT NULL,
		  `code` varchar(250) NOT NULL,
		  `typ` varchar(100) NOT NULL,
		  `broker` varchar(100) NOT NULL,
		  `symbol` varchar(100) NOT NULL,
		  `coin` varchar(100) NOT NULL,
		  `market_or_limit` varchar(100) NOT NULL,
		  `limitusdprice` varchar(100) NOT NULL,
		  `limitbtcprice` varchar(100) NOT NULL,
		  `volumeusd` varchar(100) NOT NULL,
		  `volumebtc` varchar(100) NOT NULL,
		  `volumecoin` varchar(100) NOT NULL,
		  `buyholdpercent` varchar(100) NOT NULL,
		  `brokersarbitrage` text NOT NULL,
		  `arbitragepercententry` varchar(100) NOT NULL,
		  `arbitragepercentexit` varchar(100) NOT NULL,
		  `tpusdprice` varchar(100) NOT NULL,
		  `tpusdvalue` varchar(100) NOT NULL,
		  `tpbtcprice` varchar(100) NOT NULL,
		  `slusdprice` varchar(100) NOT NULL,
		  `slusdvalue` varchar(100) NOT NULL,
		  `slbtcprice` varchar(100) NOT NULL,
		  `sended` int(1) NOT NULL,
		  `result` varchar(250) NOT NULL,
		  `createdtimestamp` int(100) NOT NULL,
		  `btcpricemysql` varchar(100) NOT NULL,
		  `tpsltraded` int(1) NOT NULL DEFAULT '0',
		  `ausfuehrungsprice` varchar(100) NOT NULL,
		  `buyholdbesitz` varchar(100) NOT NULL,
		  `tradesignalnow` int(1) NOT NULL DEFAULT '1',
		  `signalrichtung` int(1) NOT NULL DEFAULT '0',
		  `maxtrades` int(100) NOT NULL,
		  `tradesgemachtbh` int(100) NOT NULL
		) ENGINE=InnoDB DEFAULT CHARSET=latin1;";mysqli_query($DatabasePointer,$sql);

		$sql="ALTER TABLE `tradingrequest`
		  ADD PRIMARY KEY (`id`),
		  ADD UNIQUE KEY `code` (`code`);";mysqli_query($DatabasePointer,$sql);

		$sql="ALTER TABLE `tradingrequest`
		  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;";mysqli_query($DatabasePointer,$sql);
?>